import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
    console.log('Seeding database...');

    // Create Categories
    const categoriesMap = {
        'Temple': 'Ancient temples and spiritual sites',
        'Fort': 'Historical forts and monuments',
        'Heritage': 'Heritage sites and cultural landmarks',
        'Craft': 'Traditional craft villages and artisans',
        'Food': 'Food and cultural experiences',
        'Park': 'Nature parks and gardens',
        'Shopping': 'Modern shopping and retail hubs',
        'Church': 'Historic churches and cathedrals',
        'Mosque': 'Grand and historic mosques'
    };

    const categories = {};
    for (const [name, description] of Object.entries(categoriesMap)) {
        categories[name] = await prisma.category.upsert({
            where: { name },
            update: {},
            create: { name, description },
        });
    }

    console.log('Categories created/updated.');

    // Create Destinations
    const destinations = [
        {
            id: 'dest-1',
            name: 'Charminar',
            description: 'The iconic monument of Hyderabad, built in 1591 by Muhammad Quli Qutb Shah.',
            latitude: 17.3616,
            longitude: 78.4747,
            categoryId: categories['Heritage'].id,
            imageUrl: 'https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=800',
        },
        {
            id: 'dest-2',
            name: 'Golconda Fort',
            description: 'A majestic fort complex that was the capital of the medieval sultanate.',
            latitude: 17.3833,
            longitude: 78.4011,
            categoryId: categories['Fort'].id,
            imageUrl: 'https://images.unsplash.com/photo-1604725333738-89423c4f0f9e?w=800',
        },
        {
            id: 'yadadri-1',
            name: 'Yadadri Lakshmi Narasimha Swamy Temple',
            description: 'A magnificent hillside temple and major pilgrimage site, recently renovated on a grand scale using black granite.',
            latitude: 17.5875,
            longitude: 78.9482,
            categoryId: categories['Temple'].id,
            imageUrl: 'https://plus.unsplash.com/premium_photo-1661963385126-11fa577925d3?q=80&w=1000',
        },
        {
            id: 'surendrapuri-1',
            name: 'Surendrapuri - Mythological Museum',
            description: 'A unique mythological theme park featuring full-sized replicas of most Hindu temples in India.',
            latitude: 17.5800,
            longitude: 78.9300,
            categoryId: categories['Temple'].id,
            imageUrl: 'https://images.unsplash.com/photo-1586618754080-135516049958?q=80&w=1000',
        },
        {
            id: 'kolanupaka-1',
            name: 'Kolanupaka Jain Temple',
            description: 'A 2000-year-old Jain shrine with exquisite architecture and a famous jade idol of Mahavira.',
            latitude: 17.6533,
            longitude: 79.1300,
            categoryId: categories['Temple'].id,
            imageUrl: 'https://images.unsplash.com/photo-1566915682737-3e97a7eed93b?q=80&w=1000',
        }
    ];

    for (const dest of destinations) {
        await prisma.destination.upsert({
            where: { id: dest.id },
            update: dest,
            create: dest,
        });
    }

    console.log('Destinations updated.');

    // Create Festivals
    const festivals = [
        {
            id: 'fest-1',
            name: 'Bonalu',
            description: 'A traditional Telangana festival offering food to the Mother Goddess.',
            date: new Date(new Date().getFullYear(), 6, 15),
            location: 'Hyderabad, Secunderabad',
            significance: 'Thanksgiving festival to the Mother Goddess.',
        },
        {
            id: 'fest-2',
            name: 'Bathukamma',
            description: 'A colorful flower festival celebrated by women in Telangana.',
            date: new Date(new Date().getFullYear(), 9, 1),
            location: 'Throughout Telangana',
            significance: 'Symbolizes the cultural identity of Telangana.',
        }
    ];

    for (const fest of festivals) {
        await prisma.festival.upsert({
            where: { id: fest.id },
            update: fest,
            create: fest,
        });
    }

    console.log('Festivals updated.');
    console.log('Database seeded successfully!');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
