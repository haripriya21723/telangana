/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fef3f2',
          100: '#fde4e1',
          200: '#fbcec8',
          300: '#f8aba3',
          400: '#f4796e',
          500: '#ee5546',
          600: '#dc3a2b',
          700: '#b82e21',
          800: '#982920',
          900: '#7e2821',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
