import {
  login as authLogin,
  registerUser,
  getCurrentUser,
  getTrails,
  getTrailById
} from '../utils/storage';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to simulate axios response structure
const mockResponse = (data) => Promise.resolve({ data });

// Auth API
export const authAPI = {
  register: async (userData) => {
    await delay(500);
    try {
      const user = registerUser(userData.name, userData.email, userData.password);
      return mockResponse({ user, token: 'mock-jwt-token' });
    } catch (error) {
      return Promise.reject({ response: { data: { message: error.message } } });
    }
  },
  login: async (credentials) => {
    await delay(500);
    const user = authLogin(credentials.email, credentials.password);
    if (user) {
      return mockResponse({ user, token: 'mock-jwt-token' });
    }
    return Promise.reject({ response: { status: 401, data: { message: 'Invalid credentials' } } });
  },
  getProfile: async () => {
    await delay(300);
    const user = getCurrentUser();
    return mockResponse({ user });
  },
  updatePreferences: async (data) => {
    await delay(300);
    return mockResponse({ success: true });
  },
};

// Destination API
export const destinationAPI = {
  getAll: async (params = {}) => {
    await delay(500);
    let trails = getTrails();

    // Filter by district if provided
    if (params.district) {
      trails = trails.filter(t => t.district === params.district);
    }

    // Filter by category if provided
    if (params.category) {
      trails = trails.filter(t => t.category === params.category);
    }

    // Apply limit
    if (params.limit) {
      trails = trails.slice(0, params.limit);
    }

    // Return as 'destinations' to match component expectation
    return mockResponse({ destinations: trails });
  },
  getById: async (id) => {
    await delay(300);
    const trail = getTrailById(id);
    return trail ? mockResponse(trail) : Promise.reject({ response: { status: 404 } });
  },
  getNearby: async () => {
    await delay(300);
    return mockResponse({ destinations: [] });
  },
};

// Story API
export const storyAPI = {
  getByDestination: async (id) => {
    await delay(300);
    const trail = getTrailById(id);
    // Return stories from the trail object itself if available, or empty
    // The initialData structure has 'stories' array in each trail
    const stories = trail?.stories?.map((content, index) => ({
      id: index,
      title: "Local Legend",
      content,
      author: "Community",
      likes: 12
    })) || [];
    return mockResponse({ stories });
  },
  getById: async (id) => {
    await delay(300);
    return mockResponse({ id, title: "Story", content: "Details..." });
  },
};

// Festival API
export const festivalAPI = {
  getAll: async () => {
    await delay(500);
    const trails = getTrails();
    const festivals = trails.filter(t => t.category === 'Seasonal Festivals');
    return mockResponse({ festivals });
  },
  getUpcoming: async () => {
    await delay(500);
    const trails = getTrails();
    const festivals = trails.filter(t => t.category === 'Seasonal Festivals').slice(0, 3);
    return mockResponse({ festivals });
  },
  getById: async (id) => {
    await delay(300);
    const festival = getTrailById(id);
    return festival ? mockResponse(festival) : Promise.reject({ response: { status: 404 } });
  },
};

// Itinerary API
export const itineraryAPI = {
  getAll: async () => {
    await delay(500);
    return mockResponse({ itineraries: [] });
  },
  getById: async (id) => {
    await delay(300);
    return mockResponse({ id, title: "Itinerary", days: [] });
  },
  create: async (data) => {
    await delay(500);
    return mockResponse({ ...data, id: Date.now() });
  },
  update: async (id, data) => mockResponse({ ...data, id }),
  delete: async (id) => mockResponse({ success: true }),
  generate: async () => mockResponse({ itinerary: { title: "AI Trip", days: [] } }),
};

// Category API
export const categoryAPI = {
  getAll: async () => {
    await delay(300);
    // Derive categories from trails
    const trails = getTrails();
    const categories = [...new Set(trails.map(t => t.category))].map((name, id) => ({
      id,
      name,
      image: trails.find(t => t.category === name)?.image,
      count: trails.filter(t => t.category === name).length
    }));
    return mockResponse({ categories });
  },
};

export default {
  authAPI,
  destinationAPI,
  storyAPI,
  festivalAPI,
  itineraryAPI,
  categoryAPI
};
