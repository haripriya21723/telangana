import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, MapPin, Filter, X, ArrowRight } from 'lucide-react';
import { getTrails } from '../utils/storage';

const CATEGORIES = [
    'All',
    'Temples',
    'Mosques',
    'Churches',
    'Hotels',
    'Parks',
    'Local Food',
    'Seasonal Festivals',
    'Local Experiences / Crafts' // Handling the space/slash
];

const Categories = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const initialCategory = searchParams.get('filter') || 'All';
    const initialSearch = searchParams.get('search') || '';

    const [trails, setTrails] = useState([]);
    const [filteredTrails, setFilteredTrails] = useState([]);
    const [activeCategory, setActiveCategory] = useState(initialCategory);
    const [searchQuery, setSearchQuery] = useState(initialSearch);

    useEffect(() => {
        const allTrails = getTrails();
        setTrails(allTrails);
    }, []);

    useEffect(() => {
        let result = trails;

        // Filter by Category
        if (activeCategory !== 'All') {
            result = result.filter(trail => trail.category.includes(activeCategory) || activeCategory.includes(trail.category));
        }

        // Filter by Search Query
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            result = result.filter(trail =>
                trail.name.toLowerCase().includes(query) ||
                trail.district.toLowerCase().includes(query) ||
                trail.category.toLowerCase().includes(query)
            );
        }

        setFilteredTrails(result);
    }, [trails, activeCategory, searchQuery]);

    // Update URL when category changes
    const handleCategoryChange = (category) => {
        setActiveCategory(category);
        if (category === 'All') {
            searchParams.delete('filter');
        } else {
            searchParams.set('filter', category);
        }
        setSearchParams(searchParams);
    };

    return (
        <div className="min-h-screen bg-gray-50 pb-20">
            {/* Header & Search */}
            <div className="bg-white shadow-sm border-b border-gray-100 sticky top-16 z-30">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                    <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                        <h1 className="text-2xl font-bold text-gray-900">Explore Trails</h1>

                        <div className="relative w-full md:w-96">
                            <input
                                type="text"
                                placeholder="Search trails, districts, or experiences..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all"
                            />
                            <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
                        </div>
                    </div>

                    {/* Category Chips */}
                    <div className="mt-6 flex overflow-x-auto pb-2 scrollbar-hide space-x-2">
                        {CATEGORIES.map((cat) => (
                            <button
                                key={cat}
                                onClick={() => handleCategoryChange(cat)}
                                className={`flex-shrink-0 px-5 py-2 rounded-full text-sm font-medium transition-all ${activeCategory === cat
                                    ? 'bg-gray-900 text-white shadow-md'
                                    : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                                    }`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Results Grid */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <p className="text-gray-500 mb-6">{filteredTrails.length} trails found</p>

                {filteredTrails.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        <AnimatePresence>
                            {filteredTrails.map((trail) => (
                                <motion.div
                                    layout
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.9 }}
                                    key={trail.id}
                                    className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition-shadow duration-300 overflow-hidden border border-gray-100 group"
                                >
                                    <div className="relative h-60 overflow-hidden">
                                        <img
                                            src={trail.image || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&q=80&w=800'}
                                            alt={trail.name}
                                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                        />
                                        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-800 border border-gray-200">
                                            {trail.category}
                                        </div>
                                    </div>

                                    <div className="p-5">
                                        <div className="flex items-center text-gray-500 text-xs font-medium uppercase tracking-wider mb-2">
                                            <MapPin size={14} className="mr-1 text-pink-500" />
                                            {trail.district}
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-900 mb-2 truncate">
                                            {trail.name}
                                        </h3>
                                        <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                                            {trail.shortDescription}
                                        </p>

                                        <Link
                                            to={`/trails/${trail.id}`}
                                            className="inline-flex items-center text-pink-600 font-semibold text-sm hover:text-pink-700 hover:underline"
                                        >
                                            View Details <ArrowRight size={16} className="ml-1" />
                                        </Link>
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    </div>
                ) : (
                    <div className="text-center py-20">
                        <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <Search className="text-gray-400" size={32} />
                        </div>
                        <h3 className="text-lg font-medium text-gray-900">No trails found</h3>
                        <p className="text-gray-500 mt-1">Try adjusting your search or category filter.</p>
                        <button
                            onClick={() => {
                                setSearchQuery('');
                                setActiveCategory('All');
                            }}
                            className="mt-4 text-pink-600 font-medium hover:text-pink-700"
                        >
                            Clear all filters
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Categories;
