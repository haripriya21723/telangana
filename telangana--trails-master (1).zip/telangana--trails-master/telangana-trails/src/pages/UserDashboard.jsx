import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getUserBookings } from '../utils/storage';
import { Link } from 'react-router-dom';
import { MapPin, Calendar, CheckCircle } from 'lucide-react';

const UserDashboard = () => {
    const { user } = useAuth();
    const [bookings, setBookings] = useState([]);

    useEffect(() => {
        if (user) {
            const userBookings = getUserBookings(user.id);
            setBookings(userBookings);
        }
    }, [user]);

    if (!user) return <div className="p-8 text-center">Please log in.</div>;

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="mb-10">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">My Journey</h1>
                <p className="text-gray-600">Welcome back, {user.name}</p>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Your Booked Trails</h2>

                {bookings.length > 0 ? (
                    <div className="space-y-6">
                        {bookings.map((booking) => (
                            <div key={booking.id} className="flex flex-col md:flex-row items-center bg-gray-50 rounded-xl p-4 md:p-6 gap-6">
                                <img
                                    src={booking.trail?.image}
                                    alt={booking.trail?.name}
                                    className="w-full md:w-32 h-32 object-cover rounded-lg"
                                />

                                <div className="flex-grow text-center md:text-left">
                                    <span className="text-xs font-bold text-pink-600 uppercase tracking-wider bg-pink-50 px-2 py-1 rounded-md mb-2 inline-block">
                                        {booking.trail?.category}
                                    </span>
                                    <h3 className="text-xl font-bold text-gray-900 mb-1">{booking.trail?.name}</h3>
                                    <div className="flex items-center justify-center md:justify-start text-gray-500 text-sm mb-2">
                                        <MapPin size={16} className="mr-1" />
                                        {booking.trail?.district}
                                    </div>
                                    <div className="flex items-center justify-center md:justify-start text-gray-500 text-sm">
                                        <Calendar size={16} className="mr-1" />
                                        Booked on {new Date(booking.date).toLocaleDateString()}
                                    </div>
                                </div>

                                <div className="flex flex-col items-center min-w-[120px]">
                                    <div className="flex items-center text-green-600 font-bold bg-green-50 px-3 py-1 rounded-full mb-3">
                                        <CheckCircle size={16} className="mr-2" />
                                        {booking.status}
                                    </div>
                                    <Link
                                        to={`/trails/${booking.trail?.id}`}
                                        className="text-sm font-semibold text-gray-600 hover:text-gray-900 underline"
                                    >
                                        View Details
                                    </Link>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12">
                        <p className="text-gray-500 mb-6">You haven't added any trails to your journey yet.</p>
                        <Link
                            to="/categories"
                            className="bg-pink-600 text-white px-6 py-2 rounded-full font-bold hover:bg-pink-700 transition-colors"
                        >
                            Start Exploring
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};

export default UserDashboard;
