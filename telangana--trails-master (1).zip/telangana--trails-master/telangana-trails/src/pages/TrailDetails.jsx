import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getTrailById, addBookings } from '../utils/storage';
import { useAuth } from '../context/AuthContext';
import { MapPin, Calendar, BookOpen, CheckCircle, ArrowLeft, Share2, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

const TrailDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();
    const [trail, setTrail] = useState(null);
    const [loading, setLoading] = useState(true);
    const [bookingStatus, setBookingStatus] = useState(null); // 'success', 'error'

    useEffect(() => {
        const data = getTrailById(id);
        if (data) {
            setTrail(data);
        }
        setLoading(false);
    }, [id]);

    const handleBook = () => {
        if (!user) {
            // Redirect to login with return url
            navigate('/login');
            return;
        }

        try {
            addBookings(user.id, [trail.id]);
            setBookingStatus('success');
            setTimeout(() => setBookingStatus(null), 3000);
        } catch (e) {
            console.error(e);
        }
    };

    if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
    if (!trail) return <div className="min-h-screen flex items-center justify-center">Trail not found.</div>;

    return (
        <div className="bg-white min-h-screen pb-20">
            {/* Hero Image */}
            <div className="relative h-[50vh] w-full">
                <img
                    src={trail.image || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&q=80&w=2000'}
                    alt={trail.name}
                    className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>

                <div className="absolute top-4 left-4">
                    <button onClick={() => navigate(-1)} className="p-2 bg-white/20 backdrop-blur-md text-white rounded-full hover:bg-white/30 transition-colors">
                        <ArrowLeft size={24} />
                    </button>
                </div>

                <div className="absolute bottom-0 left-0 w-full p-6 md:p-12">
                    <div className="max-w-7xl mx-auto">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <span className="inline-block px-3 py-1 bg-pink-600 text-white text-xs font-bold uppercase tracking-wider rounded-full mb-4">
                                {trail.category}
                            </span>
                            <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">{trail.name}</h1>
                            <div className="flex items-center text-gray-200">
                                <MapPin size={20} className="mr-2" />
                                <span className="text-lg">{trail.location || trail.district}</span>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Main Content */}
                <div className="lg:col-span-2 space-y-10">
                    <section>
                        <h2 className="text-2xl font-bold text-gray-900 mb-4">About this Trail</h2>
                        <p className="text-gray-600 text-lg leading-relaxed">
                            {trail.description}
                        </p>
                    </section>

                    {trail.stories && trail.stories.length > 0 && (
                        <section className="bg-amber-50 p-6 rounded-2xl border border-amber-100">
                            <h3 className="flex items-center text-xl font-bold text-amber-900 mb-4">
                                <BookOpen className="mr-2 text-amber-600" />
                                Stories & Folklore
                            </h3>
                            <ul className="space-y-4">
                                {trail.stories.map((story, idx) => (
                                    <li key={idx} className="flex items-start">
                                        <span className="text-amber-500 mr-2 text-xl">•</span>
                                        <p className="text-amber-800 italic">{story}</p>
                                    </li>
                                ))}
                            </ul>
                        </section>
                    )}

                    {/* AI Recommendation (Mock) */}
                    <section>
                        <h2 className="text-xl font-bold text-gray-900 mb-4">AI Itinerary Suggestion</h2>
                        <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
                            <p className="text-indigo-800">
                                <span className="font-bold">Afternoon Visit:</span> Best visited during sunset to capture the stunning architecture in golden light. Combine this trip with a local food walk in {trail.district} for a complete experience.
                            </p>
                        </div>
                    </section>
                </div>

                {/* Sidebar / Booking */}
                <div className="lg:col-span-1">
                    <div className="sticky top-24 bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
                        <h3 className="text-xl font-bold text-gray-900 mb-6">Plan Your Journey</h3>

                        <div className="space-y-4 mb-8">
                            <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                                <MapPin className="text-gray-400 mr-3" size={20} />
                                <div>
                                    <p className="text-xs text-gray-500 uppercase font-bold">Location</p>
                                    <p className="text-gray-900 font-medium">{trail.district}</p>
                                </div>
                            </div>
                            <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                                <Calendar className="text-gray-400 mr-3" size={20} />
                                <div>
                                    <p className="text-xs text-gray-500 uppercase font-bold">Best Time</p>
                                    <p className="text-gray-900 font-medium">{trail.bestTime || 'October - February'}</p>
                                </div>
                            </div>
                        </div>

                        {bookingStatus === 'success' ? (
                            <motion.div
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="bg-green-100 text-green-800 p-4 rounded-xl flex items-center justify-center font-bold mb-4"
                            >
                                <CheckCircle className="mr-2" /> Added to Journey
                            </motion.div>
                        ) : (
                            <button
                                onClick={handleBook}
                                className="w-full bg-gradient-to-r from-pink-600 to-orange-600 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-orange-500/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                            >
                                Add to My Journey
                            </button>
                        )}

                        <p className="text-xs text-gray-500 text-center mt-4">
                            Adding this trail creates a dummy booking in your dashboard.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TrailDetails;
