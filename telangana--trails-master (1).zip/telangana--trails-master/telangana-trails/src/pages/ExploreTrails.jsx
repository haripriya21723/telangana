import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { trailsAPI } from '../utils/api';

const ExploreTrails = () => {
  const [trails, setTrails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: '',
    district: '',
    search: '',
    popular: false,
    hiddenGem: false
  });

  useEffect(() => {
    fetchTrails();
  }, [filters]);

  const fetchTrails = async () => {
    try {
      setLoading(true);
      const response = await trailsAPI.getAll(filters);
      setTrails(response.data.trails);
    } catch (error) {
      console.error('Error fetching trails:', error);
    } finally {
      setLoading(false);
    }
  };

  const categories = [
    'temple',
    'fort',
    'festival',
    'cuisine',
    'handicraft',
    'heritage'
  ];

  const districts = [
    'Hyderabad',
    'Warangal',
    'Karimnagar',
    'Nizamabad',
    'Khammam',
    'Adilabad',
    'Medak',
    'Nalgonda',
    'Rangareddy',
    'Mahbubnagar'
  ];

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8 text-center">Explore Telangana Trails</h1>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <input
              type="text"
              placeholder="Search trails..."
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-telangana-orange"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
            <select
              value={filters.category}
              onChange={(e) => handleFilterChange('category', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-telangana-orange"
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">District</label>
            <select
              value={filters.district}
              onChange={(e) => handleFilterChange('district', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-telangana-orange"
            >
              <option value="">All Districts</option>
              {districts.map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center space-x-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={filters.popular}
                onChange={(e) => handleFilterChange('popular', e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm font-medium text-gray-700">Popular</span>
            </label>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={filters.hiddenGem}
                onChange={(e) => handleFilterChange('hiddenGem', e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm font-medium text-gray-700">Hidden Gems</span>
            </label>
          </div>
        </div>
      </div>

      {/* Trails Grid */}
      {loading ? (
        <div className="text-center py-12">
          <div className="text-lg">Loading trails...</div>
        </div>
      ) : trails.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-lg text-gray-600">No trails found. Try adjusting your filters.</div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trails.map((trail) => (
            <Link
              key={trail.id}
              to={`/trails/${trail.id}`}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition"
            >
              {trail.images && trail.images.length > 0 && (
                <img
                  src={trail.images[0]}
                  alt={trail.title}
                  className="w-full h-48 object-cover"
                />
              )}
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-telangana-orange font-semibold uppercase">
                    {trail.category}
                  </span>
                  {trail.averageRating > 0 && (
                    <span className="text-sm text-yellow-500">
                      ⭐ {trail.averageRating.toFixed(1)}
                    </span>
                  )}
                </div>
                <h3 className="text-xl font-bold mb-2">{trail.title}</h3>
                <p className="text-gray-600 text-sm mb-2">{trail.district}</p>
                <p className="text-gray-700 line-clamp-2">{trail.description}</p>
                {trail.isPopular && (
                  <span className="inline-block mt-2 px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">
                    Popular
                  </span>
                )}
                {trail.isHiddenGem && (
                  <span className="inline-block mt-2 ml-2 px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">
                    Hidden Gem
                  </span>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default ExploreTrails;
