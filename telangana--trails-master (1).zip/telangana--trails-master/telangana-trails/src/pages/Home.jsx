import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { destinationAPI, festivalAPI } from '../services/api';

export default function Home() {
  const [destinations, setDestinations] = useState([]);
  const [festivals, setFestivals] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [destRes, festRes] = await Promise.all([
          destinationAPI.getAll({ limit: 6 }),
          festivalAPI.getUpcoming(),
        ]);
        setDestinations(destRes.data.destinations || []);
        setFestivals(festRes.data.festivals || []);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary-600 to-primary-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-4">
              Telangana Trails
            </h1>
            <p className="text-2xl mb-8 text-primary-100">
              Don't Just Visit Telangana. Experience Its Soul.
            </p>
            <p className="text-lg mb-8 text-primary-200 max-w-2xl mx-auto">
              Discover the rich cultural heritage, ancient traditions, and hidden stories
              of Telangana through immersive cultural exploration.
            </p>
            <div className="space-x-4">
              <Link to="/categories" className="btn-primary bg-white text-primary-600 hover:bg-gray-100">
                Explore Destinations
              </Link>
              <Link to="/categories?filter=Seasonal%20Festivals" className="btn-secondary bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary-600">
                View Festivals
              </Link>
              <Link to="/categories?filter=Local%20Experiences%20%2F%20Crafts" className="btn-secondary bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary-600">
                Hidden Trails
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Why Telangana Trails?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Interactive Storytelling</h3>
              <p className="text-gray-600">
                Every destination has a story. Immerse yourself in the folklore, rituals, and history of Telangana.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">AI-Powered Itineraries</h3>
              <p className="text-gray-600">
                Get personalized travel plans based on your interests, whether you love temples, food, festivals, or forts.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-primary-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Festival Calendar</h3>
              <p className="text-gray-600">
                Never miss a cultural celebration. Get real-time updates on festivals, rituals, and their significance.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <h3 className="text-2xl font-semibold mb-4">Discover Hidden Gems</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Explore authentic local experiences, village traditions, and hidden trails that offer a deeper connection to Telangana's cultural heritage.
            </p>
            <Link to="/categories?filter=Local%20Experiences%20%2F%20Crafts" className="btn-primary inline-block">
              Explore Hidden Trails
            </Link>
          </div>
        </div>
      </section>


    </div>
  );
}
