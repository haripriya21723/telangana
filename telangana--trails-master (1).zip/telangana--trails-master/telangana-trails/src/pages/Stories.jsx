import { useState, useEffect } from 'react';
import { storiesAPI } from '../utils/api';
import { Link } from 'react-router-dom';

const Stories = () => {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetchStories();
  }, [filter]);

  const fetchStories = async () => {
    try {
      const params = filter ? { type: filter } : {};
      const response = await storiesAPI.getAll(params);
      setStories(response.data.stories);
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setLoading(false);
    }
  };

  const storyTypes = ['folklore', 'legend', 'history', 'craft'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8 text-center">Interactive Storytelling</h1>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Type</label>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="w-full md:w-64 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-telangana-orange"
        >
          <option value="">All Stories</option>
          {storyTypes.map((type) => (
            <option key={type} value={type}>
              {type.charAt(0).toUpperCase() + type.slice(1)}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="text-lg">Loading stories...</div>
        </div>
      ) : stories.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-lg text-gray-600">No stories found.</div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {stories.map((story) => (
            <div key={story.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition">
              <div className="flex items-center justify-between mb-3">
                <span className="px-3 py-1 bg-purple-100 text-purple-800 text-sm rounded">
                  {story.type}
                </span>
              </div>
              <h3 className="text-xl font-bold mb-3">{story.title}</h3>
              <p className="text-gray-700 mb-4 line-clamp-4">{story.content}</p>
              {story.trail && (
                <Link
                  to={`/trails/${story.trail.id}`}
                  className="text-telangana-orange hover:text-orange-600 text-sm font-medium"
                >
                  View Related Trail →
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Stories;
