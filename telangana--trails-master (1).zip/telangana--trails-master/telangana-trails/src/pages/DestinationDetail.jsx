import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { destinationAPI, storyAPI } from '../services/api';

export default function DestinationDetail() {
  const { id } = useParams();
  const [destination, setDestination] = useState(null);
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedStory, setSelectedStory] = useState(null);

  useEffect(() => {
    fetchDestination();
    fetchStories();
  }, [id]);

  const fetchDestination = async () => {
    try {
      const response = await destinationAPI.getById(id);
      setDestination(response.data.destination);
    } catch (error) {
      console.error('Error fetching destination:', error);
    }
  };

  const fetchStories = async () => {
    try {
      const response = await storyAPI.getByDestination(id);
      setStories(response.data.stories || []);
      if (response.data.stories && response.data.stories.length > 0) {
        setSelectedStory(response.data.stories[0]);
      }
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  if (!destination) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Destination not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/destinations" className="text-primary-600 hover:text-primary-700 mb-4 inline-block">
          ← Back to Destinations
        </Link>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          {destination.imageUrl && (
            <img
              src={destination.imageUrl}
              alt={destination.name}
              className="w-full h-96 object-cover"
            />
          )}
          
          <div className="p-8">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-4xl font-bold">{destination.name}</h1>
              {destination.category && (
                <span className="px-4 py-2 bg-primary-100 text-primary-700 rounded-full text-sm font-medium">
                  {destination.category.name}
                </span>
              )}
            </div>
            
            <p className="text-lg text-gray-700 mb-6">{destination.description}</p>

            {/* Location Info */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Location</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <span className="text-sm text-gray-500">Latitude</span>
                  <p className="font-medium">{destination.latitude}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Longitude</span>
                  <p className="font-medium">{destination.longitude}</p>
                </div>
              </div>
              {/* Map Link */}
              <a
                href={`https://www.google.com/maps?q=${destination.latitude},${destination.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-primary-600 hover:text-primary-700 font-medium"
              >
                <svg
                  className="w-5 h-5 mr-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
                View on Google Maps
              </a>
            </div>

            {/* Local Experiences (if hidden trail) */}
            {destination.isHiddenTrail && destination.localExperiences && (
              <div className="mb-8 p-6 bg-amber-50 border border-amber-200 rounded-lg">
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <span className="mr-2">✨</span>
                  Local Experiences
                </h3>
                <p className="text-gray-700 whitespace-pre-line">{destination.localExperiences}</p>
              </div>
            )}
          </div>
        </div>

        {/* Stories Section */}
        {stories.length > 0 && (
          <div className="mt-8">
            <h2 className="text-3xl font-bold mb-6">Cultural Stories</h2>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Story List */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow-md p-4">
                  <h3 className="font-semibold mb-4">Stories</h3>
                  <div className="space-y-2">
                    {stories.map((story) => (
                      <button
                        key={story.id}
                        onClick={() => setSelectedStory(story)}
                        className={`w-full text-left p-3 rounded-lg transition-colors ${
                          selectedStory?.id === story.id
                            ? 'bg-primary-100 text-primary-700'
                            : 'bg-gray-100 hover:bg-gray-200'
                        }`}
                      >
                        <div className="font-medium">{story.title}</div>
                        <div className="text-xs text-gray-500 mt-1">
                          {new Date(story.createdAt).toLocaleDateString()}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Selected Story Content */}
              {selectedStory && (
                <div className="lg:col-span-2">
                  <div className="bg-white rounded-lg shadow-md p-8">
                    <h3 className="text-2xl font-bold mb-4">{selectedStory.title}</h3>
                    
                    {selectedStory.imageUrl && (
                      <img
                        src={selectedStory.imageUrl}
                        alt={selectedStory.title}
                        className="w-full h-64 object-cover rounded-lg mb-6"
                      />
                    )}

                    <div className="prose max-w-none">
                      <div className="mb-6">
                        <h4 className="text-xl font-semibold mb-2">Story</h4>
                        <p className="text-gray-700 whitespace-pre-line">{selectedStory.content}</p>
                      </div>

                      {selectedStory.history && (
                        <div className="mb-6">
                          <h4 className="text-xl font-semibold mb-2">History</h4>
                          <p className="text-gray-700 whitespace-pre-line">{selectedStory.history}</p>
                        </div>
                      )}

                      {selectedStory.folklore && (
                        <div className="mb-6">
                          <h4 className="text-xl font-semibold mb-2">Folklore</h4>
                          <p className="text-gray-700 whitespace-pre-line">{selectedStory.folklore}</p>
                        </div>
                      )}

                      {selectedStory.rituals && (
                        <div className="mb-6">
                          <h4 className="text-xl font-semibold mb-2">Rituals & Traditions</h4>
                          <p className="text-gray-700 whitespace-pre-line">{selectedStory.rituals}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {stories.length === 0 && (
          <div className="mt-8 bg-white rounded-lg shadow-md p-8 text-center">
            <p className="text-gray-500">No stories available for this destination yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
