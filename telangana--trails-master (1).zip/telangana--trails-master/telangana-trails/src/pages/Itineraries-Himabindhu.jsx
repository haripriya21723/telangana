import { useState, useEffect } from 'react';
import { itinerariesAPI } from '../utils/api';
import { Link } from 'react-router-dom';

const Itineraries = () => {
  const [itineraries, setItineraries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    duration: 3,
    interests: [],
    startDate: '',
    endDate: ''
  });

  useEffect(() => {
    fetchItineraries();
  }, []);

  const fetchItineraries = async () => {
    try {
      const response = await itinerariesAPI.getMyItineraries();
      setItineraries(response.data.itineraries);
    } catch (error) {
      console.error('Error fetching itineraries:', error);
    } finally {
      setLoading(false);
    }
  };

  const interestsOptions = [
    'heritage',
    'food',
    'festivals',
    'spirituality',
    'local culture',
    'handicrafts'
  ];

  const handleGenerate = async (e) => {
    e.preventDefault();
    try {
      const response = await itinerariesAPI.generate(formData);
      setItineraries([response.data.itinerary, ...itineraries]);
      setShowForm(false);
      setFormData({
        duration: 3,
        interests: [],
        startDate: '',
        endDate: ''
      });
    } catch (error) {
      console.error('Error generating itinerary:', error);
      alert('Failed to generate itinerary');
    }
  };

  const toggleInterest = (interest) => {
    setFormData((prev) => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter((i) => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold">My Itineraries</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-telangana-orange text-white px-6 py-3 rounded-lg hover:bg-orange-600"
        >
          {showForm ? 'Cancel' : '+ Create New Itinerary'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">Generate AI-Powered Itinerary</h2>
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Duration (days)
              </label>
              <input
                type="number"
                min="1"
                max="14"
                value={formData.duration}
                onChange={(e) =>
                  setFormData({ ...formData, duration: parseInt(e.target.value) })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Interests (select all that apply)
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {interestsOptions.map((interest) => (
                  <label key={interest} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.interests.includes(interest)}
                      onChange={() => toggleInterest(interest)}
                      className="mr-2"
                    />
                    <span className="text-sm capitalize">{interest}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date (optional)
                </label>
                <input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date (optional)
                </label>
                <input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={formData.interests.length === 0}
              className="bg-telangana-orange text-white px-6 py-3 rounded-lg hover:bg-orange-600 disabled:opacity-50"
            >
              Generate Itinerary
            </button>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12">
          <div className="text-lg">Loading itineraries...</div>
        </div>
      ) : itineraries.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-md p-8">
          <p className="text-lg text-gray-600 mb-4">You don't have any itineraries yet.</p>
          <button
            onClick={() => setShowForm(true)}
            className="bg-telangana-orange text-white px-6 py-3 rounded-lg hover:bg-orange-600"
          >
            Create Your First Itinerary
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {itineraries.map((itinerary) => (
            <div key={itinerary.id} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">{itinerary.title}</h2>
                {itinerary.isAIGenerated && (
                  <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded">
                    AI Generated
                  </span>
                )}
              </div>
              <p className="text-gray-600 mb-4">
                Duration: {itinerary.duration} day{itinerary.duration > 1 ? 's' : ''}
              </p>
              {itinerary.interests && itinerary.interests.length > 0 && (
                <div className="mb-4">
                  <span className="text-sm font-medium text-gray-700">Interests: </span>
                  {itinerary.interests.map((interest, idx) => (
                    <span
                      key={idx}
                      className="inline-block px-2 py-1 bg-gray-100 text-gray-700 text-sm rounded mr-2"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              )}
              {itinerary.trails && itinerary.trails.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Trails:</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {itinerary.trails.map((trail, idx) => (
                      <Link
                        key={idx}
                        to={`/trails/${trail.id}`}
                        className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">
                            Day {trail.dayNumber} - Stop {trail.orderInDay}
                          </span>
                        </div>
                        <h4 className="font-semibold text-lg">{trail.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{trail.district}</p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Itineraries;
