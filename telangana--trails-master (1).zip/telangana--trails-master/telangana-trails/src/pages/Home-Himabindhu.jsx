import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, MapPin, Star } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { getTrails } from '../utils/storage';

const CATEGORIES = [
  { name: 'Temples', image: 'https://images.unsplash.com/photo-1627894403616-8f24458316df?q=80&w=800&auto=format&fit=crop', color: 'from-orange-400 to-red-500' },
  { name: 'Mosques', image: 'https://images.unsplash.com/photo-1574109594098-9cd3588241d7?q=80&w=800&auto=format&fit=crop', color: 'from-green-400 to-emerald-600' },
  { name: 'Churches', image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Medak_cathedral.jpg/800px-Medak_cathedral.jpg', color: 'from-blue-400 to-indigo-500' },
  { name: 'Gardens', image: 'https://images.unsplash.com/photo-1596716075677-628f87428f52?auto=format&fit=crop&q=80&w=800', color: 'from-lime-400 to-green-500' }, // Generic garden
  { name: 'Local Food', image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=800', color: 'from-yellow-400 to-orange-500' },
  { name: 'Crafts', image: 'https://images.unsplash.com/photo-1606293926075-69a00dbfde81?auto=format&fit=crop&q=80&w=800', color: 'from-pink-400 to-rose-500' },
];

const Home = () => {
  const [featuredTrails, setFeaturedTrails] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const trails = getTrails();
    setFeaturedTrails(trails.slice(0, 3)); // Show first 3 as featured
  }, []);

  const handleCategoryClick = (category) => {
    navigate(`/categories?filter=${category}`);
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1626014902809-f38b00695627?q=80&w=2000&auto=format&fit=crop"
            alt="Telangana Heritage"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/40 to-transparent"></div>
        </div>

        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight"
          >
            Experience the Soul of <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-orange-400">
              Telangana
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-gray-200 mb-10 max-w-2xl mx-auto"
          >
            Discover ancient temples, vibrant festivals, and hidden cultural gems in the heart of the Deccan.
          </motion.p>

          <motion.button
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            onClick={() => navigate('/categories')}
            className="bg-gradient-to-r from-pink-600 to-orange-600 text-white px-8 py-4 rounded-full text-lg font-bold shadow-2xl hover:shadow-orange-500/50 transition-all flex items-center mx-auto gap-2"
          >
            Start Exploring <ArrowRight size={20} />
          </motion.button>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Curated Collections</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Browse through our carefully selected categories to find your perfect cultural experience.</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {CATEGORIES.map((cat, index) => (
              <motion.div
                key={cat.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleCategoryClick(cat.name)}
                className="group cursor-pointer relative rounded-2xl overflow-hidden aspect-[4/5] shadow-lg hover:shadow-xl transition-shadow"
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent">
                  <div className="absolute bottom-0 w-full p-4">
                    <h3 className="text-white font-bold text-lg text-center">{cat.name}</h3>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Trails */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Popular Trails</h2>
              <p className="text-gray-600">Most loved destinations by fellow travelers</p>
            </div>
            <Link to="/categories" className="hidden md:flex items-center text-pink-600 font-semibold hover:text-pink-700">
              View All <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredTrails.map((trail) => (
              <motion.div
                key={trail.id}
                whileHover={{ y: -10 }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 group"
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={trail.image}
                    alt={trail.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-800 uppercase tracking-wider">
                    {trail.category}
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex items-center text-pink-500 text-sm font-medium mb-2">
                    <MapPin size={16} className="mr-1" />
                    {trail.district}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-pink-600 transition-colors">
                    {trail.name}
                  </h3>
                  <p className="text-gray-600 text-sm line-clamp-2 mb-4">
                    {trail.shortDescription}
                  </p>

                  <Link
                    to={`/trails/${trail.id}`}
                    className="block w-full text-center bg-gray-50 hover:bg-gray-100 text-gray-900 font-semibold py-3 rounded-xl transition-colors"
                  >
                    View Details
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-8 text-center md:hidden">
            <Link to="/categories" className="inline-flex items-center text-pink-600 font-semibold hover:text-pink-700">
              View All <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
