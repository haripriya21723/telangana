import { useState, useEffect } from 'react';
import { festivalAPI } from '../services/api';

export default function Festivals() {
  const [festivals, setFestivals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, upcoming, this-month

  useEffect(() => {
    fetchFestivals();
  }, [filter]);

  const fetchFestivals = async () => {
    setLoading(true);
    try {
      let response;
      if (filter === 'upcoming') {
        response = await festivalAPI.getUpcoming();
      } else {
        const params = {};
        if (filter === 'this-month') {
          const now = new Date();
          params.month = now.getMonth() + 1;
          params.year = now.getFullYear();
        }
        response = await festivalAPI.getAll(params);
      }
      setFestivals(response.data.festivals || []);
    } catch (error) {
      console.error('Error fetching festivals:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const isUpcoming = (dateString) => {
    return new Date(dateString) >= new Date();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Festivals & Rituals</h1>
          <p className="text-gray-600">
            Discover the vibrant festivals and cultural celebrations of Telangana
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="mb-8 flex space-x-4 border-b">
          <button
            onClick={() => setFilter('all')}
            className={`pb-4 px-4 font-medium ${
              filter === 'all'
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            All Festivals
          </button>
          <button
            onClick={() => setFilter('upcoming')}
            className={`pb-4 px-4 font-medium ${
              filter === 'upcoming'
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setFilter('this-month')}
            className={`pb-4 px-4 font-medium ${
              filter === 'this-month'
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            This Month
          </button>
        </div>

        {/* Festivals Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-xl">Loading festivals...</div>
          </div>
        ) : festivals.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-xl text-gray-500">No festivals found</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {festivals.map((festival) => (
              <div
                key={festival.id}
                className={`card ${isUpcoming(festival.date) ? 'border-l-4 border-primary-500' : ''}`}
              >
                {festival.imageUrl && (
                  <img
                    src={festival.imageUrl}
                    alt={festival.name}
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                )}
                
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-semibold">{festival.name}</h3>
                  {isUpcoming(festival.date) && (
                    <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">
                      Upcoming
                    </span>
                  )}
                </div>

                <div className="mb-4">
                  <div className="text-sm text-gray-500 mb-1">
                    <span className="font-medium">Date:</span> {formatDate(festival.date)}
                  </div>
                  <div className="text-sm text-gray-500">
                    <span className="font-medium">Location:</span> {festival.location}
                  </div>
                </div>

                <p className="text-gray-700 text-sm mb-4 line-clamp-3">
                  {festival.description}
                </p>

                <div className="mb-4">
                  <h4 className="font-semibold text-sm mb-2">Significance</h4>
                  <p className="text-sm text-gray-600">{festival.significance}</p>
                </div>

                {festival.dos && (
                  <div className="mb-4">
                    <h4 className="font-semibold text-sm mb-2 text-green-700">Do's</h4>
                    <p className="text-sm text-gray-600">{festival.dos}</p>
                  </div>
                )}

                {festival.donts && (
                  <div>
                    <h4 className="font-semibold text-sm mb-2 text-red-700">Don'ts</h4>
                    <p className="text-sm text-gray-600">{festival.donts}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
