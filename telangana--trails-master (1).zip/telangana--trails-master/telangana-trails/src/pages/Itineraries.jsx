import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ProtectedRoute from '../components/ProtectedRoute';
import { itineraryAPI, destinationAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

function ItinerariesContent() {
  const { user } = useAuth();
  const [itineraries, setItineraries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showGenerateForm, setShowGenerateForm] = useState(false);
  const [preferences, setPreferences] = useState({
    categories: [],
    days: 3,
  });

  useEffect(() => {
    fetchItineraries();
  }, []);

  const fetchItineraries = async () => {
    setLoading(true);
    try {
      const response = await itineraryAPI.getAll();
      setItineraries(response.data.itineraries || []);
    } catch (error) {
      console.error('Error fetching itineraries:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await itineraryAPI.generate({
        preferences,
        days: preferences.days,
      });
      await fetchItineraries();
      setShowGenerateForm(false);
    } catch (error) {
      console.error('Error generating itinerary:', error);
      alert('Failed to generate itinerary. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this itinerary?')) {
      return;
    }

    try {
      await itineraryAPI.delete(id);
      await fetchItineraries();
    } catch (error) {
      console.error('Error deleting itinerary:', error);
      alert('Failed to delete itinerary');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-bold mb-2">My Itineraries</h1>
            <p className="text-gray-600">
              Your personalized travel plans for exploring Telangana
            </p>
          </div>
          <button
            onClick={() => setShowGenerateForm(!showGenerateForm)}
            className="btn-primary"
          >
            {showGenerateForm ? 'Cancel' : 'Generate New Itinerary'}
          </button>
        </div>

        {/* Generate Form */}
        {showGenerateForm && (
          <div className="card mb-8">
            <h2 className="text-2xl font-bold mb-4">Generate AI-Powered Itinerary</h2>
            <form onSubmit={handleGenerate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Number of Days</label>
                <input
                  type="number"
                  min="1"
                  max="14"
                  value={preferences.days}
                  onChange={(e) => setPreferences({ ...preferences, days: parseInt(e.target.value) })}
                  className="input-field"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Interests (Select multiple)</label>
                <div className="space-y-2">
                  {['Temple', 'Fort', 'Heritage', 'Craft', 'Food', 'Festival'].map((cat) => (
                    <label key={cat} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={preferences.categories.includes(cat)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setPreferences({
                              ...preferences,
                              categories: [...preferences.categories, cat],
                            });
                          } else {
                            setPreferences({
                              ...preferences,
                              categories: preferences.categories.filter((c) => c !== cat),
                            });
                          }
                        }}
                        className="rounded"
                      />
                      <span>{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={preferences.includeHiddenTrails !== false}
                    onChange={(e) => {
                      setPreferences({
                        ...preferences,
                        includeHiddenTrails: e.target.checked,
                      });
                    }}
                    className="rounded"
                  />
                  <span>Include Hidden Trails & Local Experiences</span>
                </label>
              </div>

              <button type="submit" className="btn-primary" disabled={loading}>
                {loading ? 'Generating...' : 'Generate Itinerary'}
              </button>
            </form>
          </div>
        )}

        {/* Itineraries List */}
        {loading && itineraries.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-xl">Loading itineraries...</div>
          </div>
        ) : itineraries.length === 0 ? (
          <div className="card text-center py-12">
            <p className="text-gray-500 mb-4">No itineraries yet.</p>
            <button
              onClick={() => setShowGenerateForm(true)}
              className="btn-primary"
            >
              Create Your First Itinerary
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {itineraries.map((itinerary) => (
              <div key={itinerary.id} className="card">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{itinerary.name}</h3>
                    {itinerary.description && (
                      <p className="text-gray-600 text-sm">{itinerary.description}</p>
                    )}
                  </div>
                  <button
                    onClick={() => handleDelete(itinerary.id)}
                    className="text-red-600 hover:text-red-700 text-sm"
                  >
                    Delete
                  </button>
                </div>

                <div className="mb-4">
                  <p className="text-sm text-gray-500 mb-2">
                    Created: {new Date(itinerary.createdAt).toLocaleDateString()}
                  </p>
                  <p className="text-sm font-medium">
                    {Array.isArray(itinerary.destinations) 
                      ? `${itinerary.destinations.length} destinations`
                      : 'No destinations'}
                  </p>
                </div>

                {/* Display destinations - handle both old and new format */}
                {itinerary.destinations && (
                  <div className="space-y-3">
                    {itinerary.destinations.days ? (
                      // New format with days
                      <>
                        <h4 className="font-medium text-sm mb-2">
                          {itinerary.destinations.totalDestinations} destinations across {itinerary.destinations.days.length} days
                        </h4>
                        {itinerary.destinations.days.map((dayPlan) => (
                          <div key={dayPlan.day} className="bg-gray-50 rounded p-3">
                            <h5 className="font-medium text-xs text-gray-700 mb-2">
                              Day {dayPlan.day}
                            </h5>
                            <ul className="space-y-1">
                              {dayPlan.destinations.map((dest, idx) => (
                                <li key={idx} className="text-sm text-gray-600">
                                  • {dest.name}
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </>
                    ) : (
                      // Old format (array)
                      <>
                        <h4 className="font-medium text-sm">Destinations:</h4>
                        <ul className="space-y-1">
                          {(Array.isArray(itinerary.destinations) ? itinerary.destinations : []).slice(0, 3).map((dest, index) => (
                            <li key={index} className="text-sm text-gray-600">
                              • {dest.name || `Destination ${index + 1}`}
                            </li>
                          ))}
                          {Array.isArray(itinerary.destinations) && itinerary.destinations.length > 3 && (
                            <li className="text-sm text-gray-500">
                              + {itinerary.destinations.length - 3} more
                            </li>
                          )}
                        </ul>
                      </>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Itineraries() {
  return (
    <ProtectedRoute>
      <ItinerariesContent />
    </ProtectedRoute>
  );
}
