import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { destinationAPI, categoryAPI } from '../services/api';

export default function Destinations() {
  const [destinations, setDestinations] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [userLocation, setUserLocation] = useState(null);
  const [nearbyDestinations, setNearbyDestinations] = useState([]);
  const [showNearby, setShowNearby] = useState(false);
  const [locationError, setLocationError] = useState(null);

  useEffect(() => {
    fetchCategories();
    fetchDestinations();
  }, [category, search]);

  useEffect(() => {
    if (showNearby && userLocation) {
      fetchNearbyDestinations();
    }
  }, [showNearby, userLocation]);

  const fetchCategories = async () => {
    try {
      const response = await categoryAPI.getAll();
      setCategories(response.data.categories || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchDestinations = async () => {
    setLoading(true);
    try {
      const params = {};
      if (category) params.category = category;
      if (search) params.search = search;
      
      const response = await destinationAPI.getAll(params);
      setDestinations(response.data.destinations || []);
    } catch (error) {
      console.error('Error fetching destinations:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser');
      return;
    }

    setLocationError(null);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ latitude, longitude });
        setShowNearby(true);
      },
      (error) => {
        setLocationError('Unable to retrieve your location. Please enable location services.');
        console.error('Geolocation error:', error);
      }
    );
  };

  const fetchNearbyDestinations = async () => {
    if (!userLocation) return;
    
    try {
      const response = await destinationAPI.getNearby(
        userLocation.latitude,
        userLocation.longitude,
        50 // 50km radius
      );
      setNearbyDestinations(response.data.destinations || []);
    } catch (error) {
      console.error('Error fetching nearby destinations:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Explore Destinations</h1>
          <p className="text-gray-600">
            Discover the cultural heritage and stories of Telangana
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <input
              type="text"
              placeholder="Search destinations..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-field flex-1"
            />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="input-field md:w-48"
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.name}>
                  {cat.name}
                </option>
              ))}
            </select>
            <button
              onClick={getCurrentLocation}
              className="btn-primary whitespace-nowrap"
              title="Find destinations near you"
            >
              📍 Find Nearby
            </button>
          </div>

          {/* Location Error */}
          {locationError && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
              {locationError}
            </div>
          )}

          {/* Nearby Destinations Section */}
          {showNearby && userLocation && (
            <div className="bg-primary-50 border border-primary-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-primary-800">
                    📍 Destinations Near You (within 50km)
                  </h3>
                  <p className="text-sm text-primary-600">
                    Location: {userLocation.latitude.toFixed(4)}, {userLocation.longitude.toFixed(4)}
                  </p>
                </div>
                <button
                  onClick={() => {
                    setShowNearby(false);
                    setNearbyDestinations([]);
                  }}
                  className="text-primary-600 hover:text-primary-800 text-sm"
                >
                  Close
                </button>
              </div>
              {nearbyDestinations.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {nearbyDestinations.map((destination) => (
                    <Link
                      key={destination.id}
                      to={`/destinations/${destination.id}`}
                      className="bg-white p-4 rounded-lg shadow hover:shadow-md transition-shadow"
                    >
                      <h4 className="font-semibold mb-1">{destination.name}</h4>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {destination.description}
                      </p>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-600">
                  No destinations found within 50km. Try exploring all destinations instead.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Destinations Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-xl">Loading destinations...</div>
          </div>
        ) : destinations.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-xl text-gray-500">No destinations found</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map((destination) => (
              <Link
                key={destination.id}
                to={`/destinations/${destination.id}`}
                className="card hover:shadow-xl transition-shadow"
              >
                {destination.imageUrl && (
                  <img
                    src={destination.imageUrl}
                    alt={destination.name}
                    className="w-full h-56 object-cover rounded-lg mb-4"
                  />
                )}
                <h3 className="text-2xl font-semibold mb-2">{destination.name}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                  {destination.description}
                </p>
                {destination.category && (
                  <span className="inline-block px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-xs font-medium">
                    {destination.category.name}
                  </span>
                )}
                {destination.stories && destination.stories.length > 0 && (
                  <div className="mt-4 text-sm text-gray-500">
                    {destination.stories.length} {destination.stories.length === 1 ? 'story' : 'stories'} available
                  </div>
                )}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
