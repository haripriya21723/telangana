import { useState, useEffect } from 'react';
import { festivalsAPI } from '../utils/api';
import { Link } from 'react-router-dom';

const Festivals = () => {
  const [festivals, setFestivals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUpcoming, setShowUpcoming] = useState(true);

  useEffect(() => {
    fetchFestivals();
  }, [showUpcoming]);

  const fetchFestivals = async () => {
    try {
      const response = await festivalsAPI.getAll({
        upcoming: showUpcoming.toString()
      });
      setFestivals(response.data.festivals);
    } catch (error) {
      console.error('Error fetching festivals:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold">Telangana Festivals & Rituals</h1>
        <button
          onClick={() => setShowUpcoming(!showUpcoming)}
          className="bg-telangana-orange text-white px-4 py-2 rounded-md hover:bg-orange-600"
        >
          {showUpcoming ? 'Show All' : 'Show Upcoming Only'}
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="text-lg">Loading festivals...</div>
        </div>
      ) : festivals.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-lg text-gray-600">No festivals found.</div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {festivals.map((festival) => (
            <div key={festival.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              {festival.images && festival.images.length > 0 && (
                <img
                  src={festival.images[0]}
                  alt={festival.name}
                  className="w-full h-48 object-cover"
                />
              )}
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{festival.name}</h3>
                <p className="text-gray-600 text-sm mb-3">
                  {new Date(festival.startDate).toLocaleDateString()} -{' '}
                  {new Date(festival.endDate).toLocaleDateString()}
                </p>
                <p className="text-gray-700 line-clamp-3 mb-4">{festival.description}</p>
                {festival.trail && (
                  <Link
                    to={`/trails/${festival.trail.id}`}
                    className="text-telangana-orange hover:text-orange-600 text-sm font-medium"
                  >
                    View Related Trail →
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Festivals;
