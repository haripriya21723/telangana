import { useState, useEffect } from 'react';
import { adminAPI, trailsAPI } from '../../utils/api';

const AdminTrails = () => {
  const [trails, setTrails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTrail, setEditingTrail] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    category: 'temple',
    district: '',
    description: '',
    history: '',
    legends: '',
    rituals: '',
    images: [],
    videos: [],
    latitude: '',
    longitude: '',
    isPopular: false,
    isHiddenGem: false
  });

  useEffect(() => {
    fetchTrails();
  }, []);

  const fetchTrails = async () => {
    try {
      const response = await trailsAPI.getAll({});
      setTrails(response.data.trails);
    } catch (error) {
      console.error('Error fetching trails:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        latitude: formData.latitude ? parseFloat(formData.latitude) : null,
        longitude: formData.longitude ? parseFloat(formData.longitude) : null
      };

      if (editingTrail) {
        await adminAPI.updateTrail(editingTrail.id, data);
      } else {
        await adminAPI.createTrail(data);
      }

      resetForm();
      fetchTrails();
    } catch (error) {
      console.error('Error saving trail:', error);
      alert('Failed to save trail');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this trail?')) return;

    try {
      await adminAPI.deleteTrail(id);
      fetchTrails();
    } catch (error) {
      console.error('Error deleting trail:', error);
      alert('Failed to delete trail');
    }
  };

  const handleEdit = (trail) => {
    setEditingTrail(trail);
    setFormData({
      title: trail.title,
      category: trail.category,
      district: trail.district,
      description: trail.description,
      history: trail.history || '',
      legends: trail.legends || '',
      rituals: trail.rituals || '',
      images: trail.images || [],
      videos: trail.videos || [],
      latitude: trail.latitude || '',
      longitude: trail.longitude || '',
      isPopular: trail.isPopular || false,
      isHiddenGem: trail.isHiddenGem || false
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      category: 'temple',
      district: '',
      description: '',
      history: '',
      legends: '',
      rituals: '',
      images: [],
      videos: [],
      latitude: '',
      longitude: '',
      isPopular: false,
      isHiddenGem: false
    });
    setEditingTrail(null);
    setShowForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold">Manage Trails</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-telangana-orange text-white px-6 py-3 rounded-lg hover:bg-orange-600"
        >
          {showForm ? 'Cancel' : '+ Add New Trail'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">
            {editingTrail ? 'Edit Trail' : 'Create New Trail'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Title *</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                >
                  <option value="temple">Temple</option>
                  <option value="fort">Fort</option>
                  <option value="festival">Festival</option>
                  <option value="cuisine">Cuisine</option>
                  <option value="handicraft">Handicraft</option>
                  <option value="heritage">Heritage</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">District *</label>
                <input
                  type="text"
                  value={formData.district}
                  onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Images (URLs, comma-separated)</label>
                <input
                  type="text"
                  value={formData.images.join(', ')}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      images: e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description *</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows="4"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">History</label>
              <textarea
                value={formData.history}
                onChange={(e) => setFormData({ ...formData, history: e.target.value })}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Legends</label>
              <textarea
                value={formData.legends}
                onChange={(e) => setFormData({ ...formData, legends: e.target.value })}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Rituals</label>
              <textarea
                value={formData.rituals}
                onChange={(e) => setFormData({ ...formData, rituals: e.target.value })}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Latitude</label>
                <input
                  type="number"
                  step="any"
                  value={formData.latitude}
                  onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Longitude</label>
                <input
                  type="number"
                  step="any"
                  value={formData.longitude}
                  onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.isPopular}
                  onChange={(e) => setFormData({ ...formData, isPopular: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Popular</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.isHiddenGem}
                  onChange={(e) => setFormData({ ...formData, isHiddenGem: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Hidden Gem</span>
              </label>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="bg-telangana-orange text-white px-6 py-2 rounded-md hover:bg-orange-600"
              >
                {editingTrail ? 'Update' : 'Create'} Trail
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12">Loading trails...</div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Title
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Category
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  District
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {trails.map((trail) => (
                <tr key={trail.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{trail.title}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                      {trail.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {trail.district}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleEdit(trail)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(trail.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminTrails;
