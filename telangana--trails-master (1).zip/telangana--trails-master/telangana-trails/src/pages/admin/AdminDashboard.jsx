import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link
          to="/admin/trails"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition"
        >
          <div className="text-4xl mb-4">🗺️</div>
          <h2 className="text-2xl font-bold mb-2">Manage Trails</h2>
          <p className="text-gray-600">Add, edit, or delete trails and destinations</p>
        </Link>

        <Link
          to="/admin/festivals"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition"
        >
          <div className="text-4xl mb-4">🎉</div>
          <h2 className="text-2xl font-bold mb-2">Manage Festivals</h2>
          <p className="text-gray-600">Add and update festivals and events</p>
        </Link>

        <Link
          to="/admin/stories"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition"
        >
          <div className="text-4xl mb-4">📖</div>
          <h2 className="text-2xl font-bold mb-2">Manage Stories</h2>
          <p className="text-gray-600">Add folklore, legends, and cultural stories</p>
        </Link>

        <Link
          to="/admin/users"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition"
        >
          <div className="text-4xl mb-4">👥</div>
          <h2 className="text-2xl font-bold mb-2">User Management</h2>
          <p className="text-gray-600">View and manage user accounts</p>
        </Link>

        <Link
          to="/admin/analytics"
          className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition"
        >
          <div className="text-4xl mb-4">📊</div>
          <h2 className="text-2xl font-bold mb-2">Analytics</h2>
          <p className="text-gray-600">View insights and statistics</p>
        </Link>
      </div>
    </div>
  );
};

export default AdminDashboard;
