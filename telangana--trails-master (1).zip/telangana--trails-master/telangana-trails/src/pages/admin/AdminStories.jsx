import { useState, useEffect } from 'react';
import { adminAPI, storiesAPI, trailsAPI } from '../../utils/api';

const AdminStories = () => {
  const [stories, setStories] = useState([]);
  const [trails, setTrails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingStory, setEditingStory] = useState(null);
  const [formData, setFormData] = useState({
    trailId: '',
    title: '',
    content: '',
    type: 'folklore',
    mediaUrls: [],
    audioUrl: '',
    videoUrl: ''
  });

  useEffect(() => {
    fetchStories();
    fetchTrails();
  }, []);

  const fetchStories = async () => {
    try {
      const response = await storiesAPI.getAll({});
      setStories(response.data.stories);
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTrails = async () => {
    try {
      const response = await trailsAPI.getAll({});
      setTrails(response.data.trails);
    } catch (error) {
      console.error('Error fetching trails:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        trailId: parseInt(formData.trailId)
      };

      if (editingStory) {
        await adminAPI.updateStory(editingStory.id, data);
      } else {
        await adminAPI.createStory(data);
      }

      resetForm();
      fetchStories();
    } catch (error) {
      console.error('Error saving story:', error);
      alert('Failed to save story');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this story?')) return;

    try {
      await adminAPI.deleteStory(id);
      fetchStories();
    } catch (error) {
      console.error('Error deleting story:', error);
      alert('Failed to delete story');
    }
  };

  const handleEdit = (story) => {
    setEditingStory(story);
    setFormData({
      trailId: story.trailId.toString(),
      title: story.title,
      content: story.content,
      type: story.type,
      mediaUrls: story.mediaUrls || [],
      audioUrl: story.audioUrl || '',
      videoUrl: story.videoUrl || ''
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      trailId: '',
      title: '',
      content: '',
      type: 'folklore',
      mediaUrls: [],
      audioUrl: '',
      videoUrl: ''
    });
    setEditingStory(null);
    setShowForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold">Manage Stories</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-telangana-orange text-white px-6 py-3 rounded-lg hover:bg-orange-600"
        >
          {showForm ? 'Cancel' : '+ Add New Story'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">
            {editingStory ? 'Edit Story' : 'Create New Story'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Trail *</label>
                <select
                  value={formData.trailId}
                  onChange={(e) => setFormData({ ...formData, trailId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                >
                  <option value="">Select a trail</option>
                  {trails.map((trail) => (
                    <option key={trail.id} value={trail.id}>
                      {trail.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Type *</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                >
                  <option value="folklore">Folklore</option>
                  <option value="legend">Legend</option>
                  <option value="history">History</option>
                  <option value="craft">Craft</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Content *</label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                rows="8"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Media URLs (comma-separated)</label>
              <input
                type="text"
                value={formData.mediaUrls.join(', ')}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    mediaUrls: e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Audio URL</label>
                <input
                  type="url"
                  value={formData.audioUrl}
                  onChange={(e) => setFormData({ ...formData, audioUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Video URL</label>
                <input
                  type="url"
                  value={formData.videoUrl}
                  onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="bg-telangana-orange text-white px-6 py-2 rounded-md hover:bg-orange-600"
              >
                {editingStory ? 'Update' : 'Create'} Story
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12">Loading stories...</div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Title
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Trail
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {stories.map((story) => (
                <tr key={story.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{story.title}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                      {story.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {story.trail ? story.trail.title : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleEdit(story)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(story.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminStories;
