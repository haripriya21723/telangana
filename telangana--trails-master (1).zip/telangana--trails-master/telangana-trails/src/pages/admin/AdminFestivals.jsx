import { useState, useEffect } from 'react';
import { adminAPI, festivalsAPI } from '../../utils/api';
import { trailsAPI } from '../../utils/api';

const AdminFestivals = () => {
  const [festivals, setFestivals] = useState([]);
  const [trails, setTrails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingFestival, setEditingFestival] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    startDate: '',
    endDate: '',
    description: '',
    participationTips: '',
    culturalSignificance: '',
    images: [],
    trailId: ''
  });

  useEffect(() => {
    fetchFestivals();
    fetchTrails();
  }, []);

  const fetchFestivals = async () => {
    try {
      const response = await festivalsAPI.getAll({});
      setFestivals(response.data.festivals);
    } catch (error) {
      console.error('Error fetching festivals:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTrails = async () => {
    try {
      const response = await trailsAPI.getAll({});
      setTrails(response.data.trails);
    } catch (error) {
      console.error('Error fetching trails:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        trailId: formData.trailId ? parseInt(formData.trailId) : null
      };

      if (editingFestival) {
        await adminAPI.updateFestival(editingFestival.id, data);
      } else {
        await adminAPI.createFestival(data);
      }

      resetForm();
      fetchFestivals();
    } catch (error) {
      console.error('Error saving festival:', error);
      alert('Failed to save festival');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this festival?')) return;

    try {
      await adminAPI.deleteFestival(id);
      fetchFestivals();
    } catch (error) {
      console.error('Error deleting festival:', error);
      alert('Failed to delete festival');
    }
  };

  const handleEdit = (festival) => {
    setEditingFestival(festival);
    setFormData({
      name: festival.name,
      startDate: festival.startDate.split('T')[0],
      endDate: festival.endDate.split('T')[0],
      description: festival.description,
      participationTips: festival.participationTips || '',
      culturalSignificance: festival.culturalSignificance || '',
      images: festival.images || [],
      trailId: festival.trailId ? festival.trailId.toString() : ''
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      startDate: '',
      endDate: '',
      description: '',
      participationTips: '',
      culturalSignificance: '',
      images: [],
      trailId: ''
    });
    setEditingFestival(null);
    setShowForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-4xl font-bold">Manage Festivals</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="bg-telangana-orange text-white px-6 py-3 rounded-lg hover:bg-orange-600"
        >
          {showForm ? 'Cancel' : '+ Add New Festival'}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">
            {editingFestival ? 'Edit Festival' : 'Create New Festival'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Name *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Related Trail (optional)</label>
                <select
                  value={formData.trailId}
                  onChange={(e) => setFormData({ ...formData, trailId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  <option value="">None</option>
                  {trails.map((trail) => (
                    <option key={trail.id} value={trail.id}>
                      {trail.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Start Date *</label>
                <input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">End Date *</label>
                <input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description *</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows="4"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Participation Tips</label>
              <textarea
                value={formData.participationTips}
                onChange={(e) => setFormData({ ...formData, participationTips: e.target.value })}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Cultural Significance</label>
              <textarea
                value={formData.culturalSignificance}
                onChange={(e) => setFormData({ ...formData, culturalSignificance: e.target.value })}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Images (URLs, comma-separated)</label>
              <input
                type="text"
                value={formData.images.join(', ')}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    images: e.target.value.split(',').map((s) => s.trim()).filter(Boolean)
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="bg-telangana-orange text-white px-6 py-2 rounded-md hover:bg-orange-600"
              >
                {editingFestival ? 'Update' : 'Create'} Festival
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {loading ? (
        <div className="text-center py-12">Loading festivals...</div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dates
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Related Trail
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {festivals.map((festival) => (
                <tr key={festival.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{festival.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(festival.startDate).toLocaleDateString()} -{' '}
                    {new Date(festival.endDate).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {festival.trail ? festival.trail.title : 'None'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleEdit(festival)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(festival.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default AdminFestivals;
