import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { destinationAPI } from '../services/api';

export default function HiddenTrails() {
  const [destinations, setDestinations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHiddenTrails();
  }, []);

  const fetchHiddenTrails = async () => {
    setLoading(true);
    try {
      const response = await destinationAPI.getAll({ hiddenTrails: 'true' });
      setDestinations(response.data.destinations || []);
    } catch (error) {
      console.error('Error fetching hidden trails:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Hidden Trails & Local Experiences</h1>
          <p className="text-gray-600 text-lg">
            Discover authentic, non-commercial experiences and hidden gems of Telangana
          </p>
          <p className="text-gray-500 mt-2">
            Explore village traditions, local crafts, traditional food, and cultural practices
            that offer a deeper connection to Telangana's heritage.
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="text-xl">Loading hidden trails...</div>
          </div>
        ) : destinations.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-md p-8">
            <svg
              className="mx-auto h-16 w-16 text-gray-400 mb-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
              />
            </svg>
            <h3 className="text-xl font-semibold mb-2">No Hidden Trails Found</h3>
            <p className="text-gray-500">
              Check back soon for curated hidden experiences and local cultural gems.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map((destination) => (
              <Link
                key={destination.id}
                to={`/destinations/${destination.id}`}
                className="card hover:shadow-xl transition-shadow border-l-4 border-primary-500"
              >
                {destination.imageUrl && (
                  <img
                    src={destination.imageUrl}
                    alt={destination.name}
                    className="w-full h-56 object-cover rounded-lg mb-4"
                  />
                )}
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-2xl font-semibold">{destination.name}</h3>
                  <span className="px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs font-medium">
                    Hidden Trail
                  </span>
                </div>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                  {destination.description}
                </p>
                {destination.localExperiences && (
                  <div className="mb-4 p-3 bg-primary-50 rounded-lg">
                    <h4 className="font-semibold text-sm text-primary-700 mb-1">
                      Local Experiences:
                    </h4>
                    <p className="text-sm text-gray-700">{destination.localExperiences}</p>
                  </div>
                )}
                {destination.category && (
                  <span className="inline-block px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-xs font-medium">
                    {destination.category.name}
                  </span>
                )}
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
