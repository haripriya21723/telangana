import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getAdminStats, getTrails, addTrail, deleteTrail, updateTrail, getBookings } from '../utils/storage';
import { Trash2, Edit, Plus, Users, Map, BookOpen, X, Check } from 'lucide-react';

const AdminDashboard = () => {
    const { user } = useAuth();
    const [stats, setStats] = useState({ totalUsers: 0, totalBookings: 0, totalTrails: 0 });
    const [trails, setTrails] = useState([]);
    const [bookings, setBookings] = useState([]);
    const [activeTab, setActiveTab] = useState('overview'); // overview, trails, bookings
    const [isEditing, setIsEditing] = useState(false);
    const [currentTrail, setCurrentTrail] = useState(null);

    // Form State
    const [formData, setFormData] = useState({
        name: '',
        category: 'Temples',
        district: '',
        image: '',
        shortDescription: '',
        description: '',
        location: ''
    });

    const refreshData = () => {
        setStats(getAdminStats());
        setTrails(getTrails());
        setBookings(getBookings());
    };

    useEffect(() => {
        refreshData();
    }, []);

    const handleDelete = (id) => {
        if (window.confirm('Are you sure you want to delete this trail?')) {
            deleteTrail(id);
            refreshData();
        }
    };

    const handlEditClick = (trail) => {
        setCurrentTrail(trail);
        setFormData(trail);
        setIsEditing(true);
    };

    const handleAddNewClick = () => {
        setCurrentTrail(null);
        setFormData({
            name: '',
            category: 'Temples',
            district: '',
            image: '',
            shortDescription: '',
            description: '',
            location: ''
        });
        setIsEditing(true);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (currentTrail) {
            updateTrail(currentTrail.id, formData);
        } else {
            addTrail(formData);
        }
        setIsEditing(false);
        refreshData();
    };

    if (!user || user.role !== 'admin') return <div className="p-8">Access Denied</div>;

    return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="flex justify-between items-center mb-10">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
                    <p className="text-gray-600">Manage trails, users, and bookings</p>
                </div>
                <div className="bg-pink-100 text-pink-800 px-4 py-2 rounded-lg font-bold">
                    Admin Mode
                </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-gray-200 mb-8 overflow-x-auto">
                <button
                    onClick={() => setActiveTab('overview')}
                    className={`pb-4 px-6 font-medium text-sm transition-colors whitespace-nowrap ${activeTab === 'overview' ? 'border-b-2 border-pink-500 text-pink-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    Overview
                </button>
                <button
                    onClick={() => setActiveTab('trails')}
                    className={`pb-4 px-6 font-medium text-sm transition-colors whitespace-nowrap ${activeTab === 'trails' ? 'border-b-2 border-pink-500 text-pink-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    Manage Trails
                </button>
                <button
                    onClick={() => setActiveTab('bookings')}
                    className={`pb-4 px-6 font-medium text-sm transition-colors whitespace-nowrap ${activeTab === 'bookings' ? 'border-b-2 border-pink-500 text-pink-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    All Bookings
                </button>
            </div>

            {/* Stats Cards & User Activity */}
            {activeTab === 'overview' && (
                <div className="animate-fade-in">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
                            <div className="p-4 bg-blue-50 text-blue-600 rounded-full mr-4">
                                <Users size={24} />
                            </div>
                            <div>
                                <p className="text-gray-500 text-sm font-medium">Total Users</p>
                                <h3 className="text-2xl font-bold text-gray-900">{stats.totalUsers}</h3>
                            </div>
                        </div>
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
                            <div className="p-4 bg-green-50 text-green-600 rounded-full mr-4">
                                <BookOpen size={24} />
                            </div>
                            <div>
                                <p className="text-gray-500 text-sm font-medium">Total Bookings</p>
                                <h3 className="text-2xl font-bold text-gray-900">{stats.totalBookings}</h3>
                            </div>
                        </div>
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
                            <div className="p-4 bg-purple-50 text-purple-600 rounded-full mr-4">
                                <Map size={24} />
                            </div>
                            <div>
                                <p className="text-gray-500 text-sm font-medium">Total Trails</p>
                                <h3 className="text-2xl font-bold text-gray-900">{stats.totalTrails}</h3>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
                        <h3 className="text-lg font-bold text-gray-900 mb-4">Bookings per User</h3>
                        <div className="overflow-x-auto">
                            <table className="min-w-full text-sm">
                                <thead>
                                    <tr className="bg-gray-50 text-left">
                                        <th className="px-4 py-3 rounded-l-lg font-medium text-gray-500">User ID</th>
                                        <th className="px-4 py-3 font-medium text-gray-500">Bookings Count</th>
                                        <th className="px-4 py-3 rounded-r-lg font-medium text-gray-500 w-full">Activity Bar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {Object.entries(stats.ordersPerUser || {}).map(([userId, count]) => (
                                        <tr key={userId} className="border-b border-gray-100 last:border-0">
                                            <td className="px-4 py-3 font-medium">User #{userId}</td>
                                            <td className="px-4 py-3 font-bold text-gray-900">{count}</td>
                                            <td className="px-4 py-3">
                                                <div className="h-2 bg-gray-100 rounded-full w-full max-w-xs overflow-hidden">
                                                    <div
                                                        className="h-full bg-pink-500 rounded-full"
                                                        style={{ width: `${Math.min((count / stats.totalBookings) * 100, 100)}%` }}
                                                    ></div>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                    {Object.keys(stats.ordersPerUser || {}).length === 0 && (
                                        <tr>
                                            <td colSpan="3" className="px-4 py-3 text-center text-gray-500">No bookings yet.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {/* Content Area */}
            {activeTab === 'trails' && (
                <div className="animate-fade-in">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-gray-900">All Trails</h2>
                        <button
                            onClick={handleAddNewClick}
                            className="bg-gray-900 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-800 flex items-center"
                        >
                            <Plus size={18} className="mr-2" /> Add Trail
                        </button>
                    </div>

                    {isEditing && (
                        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                            <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-8 relative animate-in zoom-in-95 duration-200">
                                <button
                                    onClick={() => setIsEditing(false)}
                                    className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
                                >
                                    <X size={24} />
                                </button>
                                <h3 className="text-2xl font-bold mb-6">{currentTrail ? 'Edit Trail' : 'Add New Trail'}</h3>

                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                                            <input
                                                type="text"
                                                required
                                                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
                                                value={formData.name}
                                                onChange={e => setFormData({ ...formData, name: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                                            <select
                                                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
                                                value={formData.category}
                                                onChange={e => setFormData({ ...formData, category: e.target.value })}
                                            >
                                                <option>Temples</option>
                                                <option>Mosques</option>
                                                <option>Churches</option>
                                                <option>Gardens</option>
                                                <option>Parks</option>
                                                <option>Local Food</option>
                                                <option>Seasonal Festivals</option>
                                                <option>Local Experiences / Crafts</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">District / Location</label>
                                            <input
                                                type="text"
                                                required
                                                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
                                                value={formData.district}
                                                onChange={e => setFormData({ ...formData, district: e.target.value })}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Image URL</label>
                                            <input
                                                type="url"
                                                required
                                                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
                                                value={formData.image}
                                                onChange={e => setFormData({ ...formData, image: e.target.value })}
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Short Description</label>
                                        <input
                                            type="text"
                                            required
                                            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
                                            value={formData.shortDescription}
                                            onChange={e => setFormData({ ...formData, shortDescription: e.target.value })}
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Detailed Description</label>
                                        <textarea
                                            rows="4"
                                            required
                                            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:outline-none"
                                            value={formData.description}
                                            onChange={e => setFormData({ ...formData, description: e.target.value })}
                                        ></textarea>
                                    </div>

                                    <div className="flex justify-end pt-4">
                                        <button
                                            type="button"
                                            onClick={() => setIsEditing(false)}
                                            className="mr-3 text-gray-600 font-medium hover:text-gray-900"
                                        >
                                            Cancel
                                        </button>
                                        <button
                                            type="submit"
                                            className="bg-gradient-to-r from-pink-600 to-orange-600 text-white px-6 py-2 rounded-lg font-bold"
                                        >
                                            Save Trail
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    )}

                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trail</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {trails.map((trail) => (
                                    <tr key={trail.id} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center">
                                                <div className="h-10 w-10 flex-shrink-0">
                                                    <img className="h-10 w-10 rounded-full object-cover" src={trail.image} alt="" />
                                                </div>
                                                <div className="ml-4">
                                                    <div className="text-sm font-medium text-gray-900">{trail.name}</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                {trail.category}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {trail.district}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <button onClick={() => handlEditClick(trail)} className="text-indigo-600 hover:text-indigo-900 mr-4">
                                                <Edit size={18} />
                                            </button>
                                            <button onClick={() => handleDelete(trail.id)} className="text-red-600 hover:text-red-900">
                                                <Trash2 size={18} />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'bookings' && (
                <div className="animate-fade-in">
                    <h2 className="text-xl font-bold text-gray-900 mb-6">All Bookings</h2>
                    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Booking ID</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User ID</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trail ID</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {bookings.map((booking) => (
                                    <tr key={booking.id} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">#{Math.floor(booking.id)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">user_{booking.userId}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">trail_{booking.trailId}</td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                {booking.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                            {booking.date ? new Date(booking.date).toLocaleDateString() : 'N/A'}
                                        </td>
                                    </tr>
                                ))}
                                {bookings.length === 0 && (
                                    <tr>
                                        <td colSpan="5" className="px-6 py-8 text-center text-gray-500">No bookings found.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminDashboard;
