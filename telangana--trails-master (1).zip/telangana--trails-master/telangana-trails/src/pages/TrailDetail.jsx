import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { trailsAPI, reviewsAPI } from '../utils/api';
import { useAuth } from '../context/AuthContext';

const TrailDetail = () => {
  const { id } = useParams();
  const { isAuthenticated } = useAuth();
  const [trail, setTrail] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewForm, setReviewForm] = useState({
    rating: 5,
    comment: ''
  });
  const [showReviewForm, setShowReviewForm] = useState(false);

  useEffect(() => {
    fetchTrail();
    fetchReviews();
  }, [id]);

  const fetchTrail = async () => {
    try {
      const response = await trailsAPI.getById(id);
      setTrail(response.data.trail);
    } catch (error) {
      console.error('Error fetching trail:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async () => {
    try {
      const response = await reviewsAPI.getByTrail(id);
      setReviews(response.data.reviews);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    try {
      await reviewsAPI.create({
        trailId: parseInt(id),
        ...reviewForm
      });
      setReviewForm({ rating: 5, comment: '' });
      setShowReviewForm(false);
      fetchReviews();
      fetchTrail();
    } catch (error) {
      console.error('Error submitting review:', error);
      alert('Failed to submit review');
    }
  };

  const handleActivity = async (action) => {
    if (!isAuthenticated) {
      alert('Please login to bookmark or track visits');
      return;
    }
    try {
      await trailsAPI.trackActivity(id, action);
      alert(`${action === 'visited' ? 'Visit' : 'Bookmark'} recorded!`);
    } catch (error) {
      console.error('Error recording activity:', error);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
        <div className="text-lg">Loading trail details...</div>
      </div>
    );
  }

  if (!trail) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
        <div className="text-lg text-red-600">Trail not found</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Image */}
      {trail.images && trail.images.length > 0 && (
        <div className="mb-8 rounded-lg overflow-hidden">
          <img
            src={trail.images[0]}
            alt={trail.title}
            className="w-full h-96 object-cover"
          />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-sm text-telangana-orange font-semibold uppercase">
                  {trail.category}
                </span>
                <h1 className="text-4xl font-bold mt-2">{trail.title}</h1>
                <p className="text-gray-600 mt-2">{trail.district}</p>
              </div>
              {trail.averageRating > 0 && (
                <div className="text-right">
                  <div className="text-3xl font-bold text-yellow-500">
                    ⭐ {trail.averageRating.toFixed(1)}
                  </div>
                  <div className="text-sm text-gray-600">{trail.totalReviews} reviews</div>
                </div>
              )}
            </div>

            <p className="text-lg text-gray-700 mb-6">{trail.description}</p>

            {trail.history && (
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-3">History</h2>
                <p className="text-gray-700">{trail.history}</p>
              </div>
            )}

            {trail.legends && (
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-3">Legends & Folklore</h2>
                <p className="text-gray-700">{trail.legends}</p>
              </div>
            )}

            {trail.rituals && (
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-3">Rituals & Traditions</h2>
                <p className="text-gray-700">{trail.rituals}</p>
              </div>
            )}

            {/* Image Gallery */}
            {trail.images && trail.images.length > 1 && (
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-3">Gallery</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {trail.images.slice(1).map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`${trail.title} ${idx + 2}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Stories */}
            {trail.stories && trail.stories.length > 0 && (
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-3">Stories</h2>
                <div className="space-y-4">
                  {trail.stories.map((story) => (
                    <div key={story.id} className="bg-gray-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-lg mb-2">{story.title}</h3>
                      <p className="text-gray-700">{story.content}</p>
                      <span className="text-sm text-gray-500 mt-2 block">
                        Type: {story.type}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Festivals */}
            {trail.festivals && trail.festivals.length > 0 && (
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-3">Upcoming Festivals</h2>
                <div className="space-y-4">
                  {trail.festivals.map((festival) => (
                    <div key={festival.id} className="bg-yellow-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-lg mb-2">{festival.name}</h3>
                      <p className="text-gray-700 mb-2">{festival.description}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(festival.startDate).toLocaleDateString()} -{' '}
                        {new Date(festival.endDate).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Reviews Section */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">Reviews</h2>
                {isAuthenticated && (
                  <button
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="bg-telangana-orange text-white px-4 py-2 rounded-md hover:bg-orange-600"
                  >
                    Write Review
                  </button>
                )}
              </div>

              {showReviewForm && isAuthenticated && (
                <form onSubmit={handleSubmitReview} className="bg-gray-50 p-4 rounded-lg mb-4">
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rating
                    </label>
                    <select
                      value={reviewForm.rating}
                      onChange={(e) =>
                        setReviewForm({ ...reviewForm, rating: parseInt(e.target.value) })
                      }
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      {[5, 4, 3, 2, 1].map((r) => (
                        <option key={r} value={r}>
                          {r} {r === 1 ? 'star' : 'stars'}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Comment
                    </label>
                    <textarea
                      value={reviewForm.comment}
                      onChange={(e) =>
                        setReviewForm({ ...reviewForm, comment: e.target.value })
                      }
                      rows="4"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      placeholder="Share your experience..."
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="bg-telangana-orange text-white px-4 py-2 rounded-md hover:bg-orange-600"
                    >
                      Submit Review
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowReviewForm(false)}
                      className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              <div className="space-y-4">
                {reviews.length === 0 ? (
                  <p className="text-gray-600">No reviews yet. Be the first to review!</p>
                ) : (
                  reviews.map((review) => (
                    <div key={review.id} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span className="font-semibold">
                            {review.user.firstName} {review.user.lastName}
                          </span>
                          <span className="text-yellow-500 ml-2">
                            {'⭐'.repeat(review.rating)}
                          </span>
                        </div>
                        <span className="text-sm text-gray-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      {review.comment && <p className="text-gray-700">{review.comment}</p>}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-20">
            <h3 className="text-xl font-bold mb-4">Quick Actions</h3>
            {isAuthenticated ? (
              <div className="space-y-3">
                <button
                  onClick={() => handleActivity('bookmarked')}
                  className="w-full bg-telangana-orange text-white px-4 py-2 rounded-md hover:bg-orange-600"
                >
                  📌 Bookmark Trail
                </button>
                <button
                  onClick={() => handleActivity('visited')}
                  className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
                >
                  ✅ Mark as Visited
                </button>
              </div>
            ) : (
              <p className="text-gray-600 mb-4">Login to bookmark or track visits</p>
            )}
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h4 className="font-semibold mb-2">Statistics</h4>
              <p className="text-sm text-gray-600">Total Visits: {trail.totalVisits || 0}</p>
              <p className="text-sm text-gray-600">Total Reviews: {trail.totalReviews || 0}</p>
              {trail.isPopular && (
                <span className="inline-block mt-2 px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">
                  Popular Destination
                </span>
              )}
              {trail.isHiddenGem && (
                <span className="inline-block mt-2 px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">
                  Hidden Gem
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrailDetail;
