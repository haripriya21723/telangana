import React, { createContext, useContext, useState, useEffect } from 'react';
import { getCurrentUser, login as loginService, logout as logoutService, registerUser } from '../utils/storage';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = getCurrentUser();
    if (storedUser) {
      setUser(storedUser);
    }
    setLoading(false);
  }, []);

  const login = (email, password, isAdmin) => {
    const loggedUser = loginService(email, password, isAdmin);
    if (loggedUser) {
      setUser({ ...loggedUser, role: isAdmin ? 'admin' : 'user' });
      return true;
    }
    return false;
  };

  const register = (name, email, password) => {
    try {
      const newUser = registerUser(name, email, password);
      // Auto login after register? Or just return true.
      // Let's auto login
      loginService(email, password);
      setUser(newUser);
      return true;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const logout = () => {
    logoutService();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, register, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
