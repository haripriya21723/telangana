import axios from 'axios';

const API_BASE_URL = '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add token to requests if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me')
};

// Trails API
export const trailsAPI = {
  getAll: (params) => api.get('/trails', { params }),
  getById: (id) => api.get(`/trails/${id}`),
  trackActivity: (id, action) => api.post(`/trails/${id}/activity`, { action })
};

// Festivals API
export const festivalsAPI = {
  getAll: (params) => api.get('/festivals', { params }),
  getById: (id) => api.get(`/festivals/${id}`)
};

// Stories API
export const storiesAPI = {
  getAll: (params) => api.get('/stories', { params }),
  getById: (id) => api.get(`/stories/${id}`)
};

// Reviews API
export const reviewsAPI = {
  getByTrail: (trailId) => api.get(`/reviews/trail/${trailId}`),
  create: (data) => api.post('/reviews', data),
  update: (id, data) => api.put(`/reviews/${id}`, data),
  delete: (id) => api.delete(`/reviews/${id}`)
};

// Itineraries API
export const itinerariesAPI = {
  generate: (data) => api.post('/itineraries/generate', data),
  getMyItineraries: () => api.get('/itineraries/my-itineraries'),
  getById: (id) => api.get(`/itineraries/${id}`)
};

// Admin API
export const adminAPI = {
  getUsers: () => api.get('/admin/users'),
  getAnalytics: () => api.get('/admin/analytics'),
  createTrail: (data) => api.post('/admin/trails', data),
  updateTrail: (id, data) => api.put(`/admin/trails/${id}`, data),
  deleteTrail: (id) => api.delete(`/admin/trails/${id}`),
  createFestival: (data) => api.post('/admin/festivals', data),
  updateFestival: (id, data) => api.put(`/admin/festivals/${id}`, data),
  deleteFestival: (id) => api.delete(`/admin/festivals/${id}`),
  createStory: (data) => api.post('/admin/stories', data),
  updateStory: (id, data) => api.put(`/admin/stories/${id}`, data),
  deleteStory: (id) => api.delete(`/admin/stories/${id}`),
  getActivities: () => api.get('/admin/activities'),
  getReviews: () => api.get('/admin/reviews')
};

export default api;
