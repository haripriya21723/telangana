import { initialUsers, initialAdmins, initialTrails, initialBookings } from '../data/initialData';

const KEYS = {
    USERS: 'tt_users',
    ADMINS: 'tt_admins',
    TRAILS: 'tt_trails',
    BOOKINGS: 'tt_bookings',
    CURRENT_USER: 'tt_current_user',
};

// Initialize data if not present
export const initializeData = () => {
    if (!localStorage.getItem(KEYS.USERS)) {
        localStorage.setItem(KEYS.USERS, JSON.stringify(initialUsers));
    }
    if (!localStorage.getItem(KEYS.ADMINS)) {
        localStorage.setItem(KEYS.ADMINS, JSON.stringify(initialAdmins));
    }

    // Smart merge for Trails to ensure updates are seen
    // Smart merge for Trails to ensure updates are seen
    let storedTrails = JSON.parse(localStorage.getItem(KEYS.TRAILS) || '[]');
    let trailsUpdated = false;

    // 1. Update or Add trails from initialData
    initialTrails.forEach(initialTrail => {
        const existingIndex = storedTrails.findIndex(t => t.id === initialTrail.id);
        if (existingIndex === -1) {
            storedTrails.push(initialTrail);
            trailsUpdated = true;
        } else {
            // Force update static data to ensure fixes propagate
            if (JSON.stringify(storedTrails[existingIndex]) !== JSON.stringify(initialTrail)) {
                storedTrails[existingIndex] = initialTrail;
                trailsUpdated = true;
            }
        }
    });

    // 2. Remove stale static trails (ID < 1000000) that are no longer in initialTrails
    const initialIds = new Set(initialTrails.map(t => t.id));
    const originalLength = storedTrails.length;
    storedTrails = storedTrails.filter(t => {
        // Keep if it's a user-created trail (large ID, assuming > 1,000,000)
        if (t.id > 1000000) return true;
        // Keep if it exists in the current initialTrails
        return initialIds.has(t.id);
    });

    if (storedTrails.length !== originalLength) {
        trailsUpdated = true;
    }

    if (trailsUpdated || storedTrails.length === 0) {
        localStorage.setItem(KEYS.TRAILS, JSON.stringify(storedTrails));
    }

    if (!localStorage.getItem(KEYS.BOOKINGS)) {
        localStorage.setItem(KEYS.BOOKINGS, JSON.stringify(initialBookings));
    }
};

// Helper to get data
const getJSON = (key) => {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
};

const setJSON = (key, data) => {
    localStorage.setItem(key, JSON.stringify(data));
};

// Auth
export const login = (email, password, isAdmin = false) => {
    const users = isAdmin ? getJSON(KEYS.ADMINS) : getJSON(KEYS.USERS);
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify({ ...user, role: isAdmin ? 'admin' : 'user' }));
        return user;
    }
    return null;
};

export const logout = () => {
    localStorage.removeItem(KEYS.CURRENT_USER);
};

export const getCurrentUser = () => {
    return getJSON(KEYS.CURRENT_USER);
};

export const registerUser = (name, email, password) => {
    const users = getJSON(KEYS.USERS);
    if (users.find(u => u.email === email)) {
        throw new Error('User already exists');
    }
    const newUser = { id: Date.now(), name, email, password, role: 'user' };
    users.push(newUser);
    setJSON(KEYS.USERS, users);
    return newUser;
};

// Trails
export const getTrails = () => getJSON(KEYS.TRAILS);

export const getTrailById = (id) => {
    const trails = getJSON(KEYS.TRAILS);
    return trails.find(t => t.id === Number(id));
};

export const addTrail = (trail) => {
    const trails = getJSON(KEYS.TRAILS);
    const newTrail = { ...trail, id: Date.now() };
    trails.push(newTrail);
    setJSON(KEYS.TRAILS, trails);
    return newTrail;
};

export const updateTrail = (id, updates) => {
    let trails = getJSON(KEYS.TRAILS);
    trails = trails.map(t => t.id === Number(id) ? { ...t, ...updates } : t);
    setJSON(KEYS.TRAILS, trails);
};

export const deleteTrail = (id) => {
    let trails = getJSON(KEYS.TRAILS);
    trails = trails.filter(t => t.id !== Number(id));
    setJSON(KEYS.TRAILS, trails);
};

// Bookings
export const getBookings = () => getJSON(KEYS.BOOKINGS);

export const addBookings = (userId, trailIds) => {
    const bookings = getJSON(KEYS.BOOKINGS);
    const newBookings = trailIds.map(trailId => ({
        id: Date.now() + Math.random(),
        userId,
        trailId,
        status: 'Confirmed',
        date: new Date().toISOString()
    }));
    const updatedBookings = [...bookings, ...newBookings];
    setJSON(KEYS.BOOKINGS, updatedBookings);
    return newBookings;
};

export const getUserBookings = (userId) => {
    const bookings = getJSON(KEYS.BOOKINGS);
    const trails = getJSON(KEYS.TRAILS);
    return bookings
        .filter(b => b.userId === userId)
        .map(b => {
            const trail = trails.find(t => t.id === b.trailId);
            return { ...b, trail };
        });
};

// Admin Stats
export const getAdminStats = () => {
    const users = getJSON(KEYS.USERS);
    const bookings = getJSON(KEYS.BOOKINGS);
    const trails = getJSON(KEYS.TRAILS);

    // Orders per user
    const ordersPerUser = {};
    bookings.forEach(b => {
        ordersPerUser[b.userId] = (ordersPerUser[b.userId] || 0) + 1;
    });

    return {
        totalUsers: users.length,
        totalBookings: bookings.length,
        totalTrails: trails.length,
        ordersPerUser
    };
};
