export const initialUsers = [
  {
    id: 1,
    name: "Himabindu",
    email: "hima@kprit.ac.in",
    password: "password123", // storing plain text for dummy purpose as requested
    role: "user"
  },
  {
    id: 2,
    name: "Sai Kumar",
    email: "sai@kprit.ac.in",
    password: "password123",
    role: "user"
  }
];

export const initialAdmins = [
  {
    id: 1,
    name: "Admin User",
    email: "admin@kprit.ac.in",
    password: "adminpassword",
    role: "admin"
  }
];

export const initialTrails = [
  {
    id: 1,
    name: "Charminar",
    category: "Mosques",
    district: "Hyderabad",
    image: "https://tse4.mm.bing.net/th/id/OIP.Q685jcZbZxA0uuT2PlDw0AHaL4?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "The iconic monument of Hyderabad.",
    description: "Built in 1591, Charminar is a monument and mosque located in Hyderabad, Telangana, India. The landmark has become globally known as a symbol of Hyderabad and is listed among the most recognized structures in India.",
    location: "Charminar Rd, Char Kaman, Ghansi Bazaar, Hyderabad",
    bestTime: "October - February",
    stories: [
      "Legend says there is a secret tunnel connecting Charminar to Golconda Fort.",
      "Built to commemorate the end of a deadly plague."
    ]
  },
  {
    id: 2,
    name: "Thousand Pillar Temple",
    category: "Temples",
    district: "Warangal",
    image: "https://tse2.mm.bing.net/th/id/OIP.h_geBlC2iMxdi6uD1sAL_gHaDU?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "A masterpiece of Kakatiya architecture.",
    description: "The Thousand Pillar Temple is a historic Hindu temple located in Hanamkonda, Telangana. It is dedicated to Lord Shiva, Vishnu and Surya.",
    location: "Hanamkonda, Warangal",
    bestTime: "October - March",
    stories: [
      "The temple is built in th star-shaped architecture style of the Kakatiya dynasty."
    ]
  },
  {
    id: 3,
    name: "Medak Church",
    category: "Churches",
    district: "Medak",
    image: "https://th.bing.com/th/id/R.aa1da3da46df9c8728499444b1391fbd?rik=k75dFbr4ane7AA&riu=http%3a%2f%2fwww.sheilakumar.in%2fwp-content%2fuploads%2f2013%2f02%2fMedak-Church-Cathedral-11.jpg&ehk=YgnaUQITXaVypVu3zz7Vp3i6d9pBjSXSnCAJUUvmNiY%3d&risl=&pid=ImgRaw&r=0",
    shortDescription: "One of the largest churches in Asia.",
    description: "Medak Cathedral is the seat of the Bishop in Medak for the Church of South India. The cathedral is one of the largest in Asia and the second largest in the world after the Vatican.",
    location: "Medak",
    bestTime: "September - March",
    stories: [
      "The stained glass windows tell the story of the Bible."
    ]
  },
  {
    id: 4,
    name: "NTR Gardens",
    category: "Parks",
    district: "Hyderabad",
    image: "https://tse1.mm.bing.net/th/id/OIP._1HksMMqbGyygBMFTahiwQAAAA?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "A small urban park adjacent to Hussain Sagar lake.",
    description: "NTR Gardens is a small urban park open to the public of 36 acres adjacent to Hussain Sagar lake in Hyderabad, India.",
    location: "Tank Bund Rd, Hyderabad",
    bestTime: "October - February",
    stories: []
  },
  {
    id: 5,
    name: "Hyderabadi Biryani Festival",
    category: "Local Food",
    district: "Hyderabad",
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=1000&auto=format&fit=crop",
    shortDescription: "Experience the authentic taste of Hyderabad.",
    description: "A seasonal festival celebrating the world-famous Hyderabadi Biryani with varieties from different legendary kitchens.",
    location: "Parade Grounds, Hyderabad",
    bestTime: "October - February",
    stories: [
      "The recipe is said to have originated in the kitchens of the Nizam."
    ]
  },
  {
    id: 6,
    name: "Bathukamma",
    category: "Seasonal Festivals",
    district: "Telangana",
    image: "https://tse3.mm.bing.net/th/id/OIP.ENKCyyGM6QoqMy4lWVb38QHaEK?rs=1&pid=ImgDetMain&o=7&rm=3", // Placeholder or general festival image
    shortDescription: "The floral festival of Telangana.",
    description: "Bathukamma is a floral festival celebrated predominantly in Telangana and some parts of Andhra Pradesh. Every year this festival is celebrated as per Sathavahana calendar for nine days.",
    location: "Statewide",
    bestTime: "September - October",
    stories: [
      "Represents cultural spirit of Telangana."
    ]
  },
  {
    id: 8,
    name: "Sri Anantha Padmanabha Swamy Temple",
    category: "Temples",
    district: "Vikarabad",
    image: "/anantha-padmanabha.png",
    shortDescription: "Ancient Vishnu temple in Ananthagiri Hills.",
    description: "Located in the dense forests of Ananthagiri Hills, this ancient temple is dedicated to Lord Vishnu. It is believed to be installed by Sage Markandeya in the Dwapara Yuga. The Ananthagiri hills are also the birthplace of the Musi River.\n\nTimings: 7:30 AM – 8:00 PM\nOfferings: Flowers, coconuts, lamps",
    location: "Ananthagiri Hills, Vikarabad",
    bestTime: "June - February",
    stories: [
      "Believed to be installed by Sage Markandeya.",
      "Religious link to the origin of the Musi River."
    ]
  },
  {
    id: 9,
    name: "Sri Bugga Ramalingeshwara Swamy Temple",
    category: "Temples",
    district: "Vikarabad",
    image: "/bugga-ramalingeshwara.png",
    shortDescription: "Historic Shiva shrine in a serene forest setting.",
    description: "Located about 6-7 km from Vikarabad, this Shiva temple is known for its serene, forested setting. It is a spiritual spot blending natural beauty with worship.\n\nTimings: Daily Morning & Evening",
    location: "Bugga Rameshwaram Village",
    bestTime: "June - February",
    stories: [
      "Known for its proximity to the Musi river origin."
    ]
  },
  {
    id: 10,
    name: "Velchal Lakshmi Narasimha Swamy Temple",
    category: "Temples",
    district: "Vikarabad",
    image: "/velchal-narasimha.png",
    shortDescription: "Significant local temple for village worship.",
    description: "A cherished local temple in Velchal Village dedicated to Lord Lakshmi Narasimha Swamy. It is a hub for village devotion and festival celebrations.",
    location: "Velchal Village, Vikarabad",
    bestTime: "June - February",
    stories: [
      "Built through community efforts."
    ]
  },
  {
    id: 11,
    name: "St. Jude’s Shrine",
    category: "Churches",
    district: "Vikarabad",
    image: "https://th.bing.com/th/id/OIP.PFKFVv2vfs8Oi8pniiIvQgHaE2?o=7rm=3&rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Dedicated to St. Jude Thaddeus, blessed in 1973.",
    description: "Built after 1970, this shrine holds a relic of St. Jude from Rome. It is a peaceful place for prayer and reflection.\n\nTimings: Sunday Mass 9:00 AM – 11:00 AM\nServices: Weekly prayer meetings available.\n\nNearby Hospital: Government & private clinics in Vikarabad Town.\nNearby Police Station: Vikarabad Police Station.",
    location: "Vikarabad Town",
    bestTime: "June - February",
    stories: [
      "Holds a relic of St. Jude brought from Rome.",
      "Feast celebrated on the last Sunday of October."
    ]
  },
  {
    id: 12,
    name: "Local Mosques of Vikarabad",
    category: "Mosques",
    district: "Vikarabad",
    image: "/vikarabad-masjid.png",
    shortDescription: "Community prayer centers in Vikarabad Town.",
    description: "Vikarabad has several active mosques serving the community, offering a place for daily prayers and Friday congregations. They are central to the local Islamic culture.\n\nTimings: Five daily prayers; Jumu'ah (Friday) ~ 12:30 PM\n\nNearby Services: Served by Vikarabad Town hospitals and police station.",
    location: "Vikarabad Town (Central Localities)",
    bestTime: "June - February",
    stories: [
      "Center for community gatherings during Eid festivals."
    ]
  },
  {
    id: 13,
    name: "Vikarabad Lake",
    category: "Parks",
    district: "Vikarabad",
    image: "https://tse3.mm.bing.net/th/id/OIP.KMMHKYn9bu1tb12zHjlpxwHaEb?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Scenic lakeside spot for morning and evening walks.",
    description: "A favorite spot for locals to unwind, enjoy nature, and watch the sunset. Excellent for photography and family walks.\n\nTimings: Sunrise – Sunset\n\nNearby Services: Town hospitals & police in vicinity.",
    location: "Vikarabad Town",
    bestTime: "June - February",
    stories: [
      "Popular local spot for sunset views."
    ]
  },
  {
    id: 14,
    name: "Kotpally Reservoir",
    category: "Parks",
    district: "Vikarabad",
    image: "https://i.pinimg.com/736x/ec/c7/1e/ecc71e914e649b06c1b4d2778a22ea71.jpg",
    shortDescription: "Scenic picnic spot famous for fresh water kayaking.",
    description: "Located about 15km from Vikarabad, Kotpally Reservoir is a calm water body surrounded by hills. It offers kayaking, boating, and lush picnic spots.\n\nActivities: Kayaking, Boating, Picnicking\n\nNearby Hospital/Police: Vikarabad town services.",
    location: "Kotpally, Vikarabad",
    bestTime: "June - February",
    stories: [
      "A major project that doubles as a tourist recreation hub."
    ]
  },
  {
    id: 15,
    name: "Vikarabad Markets & Cuisine",
    category: "Local Food",
    district: "Vikarabad",
    image: "https://images.unsplash.com/photo-1606471191009-63994c53433b?q=80&w=1000&auto=format&fit=crop",
    shortDescription: "Authentic Telangana snacks and local shopping.",
    description: "Explore the local markets for fresh produce, pooja items, and handicrafts. Don't miss the local cuisine featuring spicy curries, biryani, and mirchi bajji.\n\nHighlights: Mirchi Bajji, Tea Stalls, Local Handycrafts\n\nNearby Hospital: Government Hospital, Vikarabad.\nNearby Police Station: Vikarabad Police Station.",
    location: "Vikarabad Town Market",
    bestTime: "June - February",
    stories: [
      "The best place to experience the daily life of Vikarabad locals."
    ]
  },
  {
    id: 16,
    name: "Yadadri (Yadagiri Gutta) Sri Lakshmi Narasimha Swamy Temple",
    category: "Temples",
    district: "Yadadri Bhuvanagiri",
    image: "/yadadri-1.jpg",
    shortDescription: "Ancient cave temple - one of the most important Vaishnava shrines in South India.",
    description: "Ancient cave temple associated with Yada Maharishi. One of the most important Vaishnava shrines in South India. Recently developed into a world-class temple complex.\n\nLocation: Yadadri Bhuvanagiri District, Telangana (~60 km from Hyderabad)\n\nTimings: 4:00 AM – 9:30 PM (Darshan slots vary by seva)\n\nDeity: Lord Lakshmi Narasimha Swamy\nOfferings: Laddus, flowers, coconuts, tulasi\n\nTransport:\n• Road: TSRTC buses from Hyderabad (MGBS/JBS)\n• Rail: Raigir / Bhuvanagiri stations\n• Ropeway & internal temple transport available\n\nDress Code: Traditional & modest attire mandatory\n\nNearby Attractions: Yadadri Lake, Surendrapuri, Bhongir Fort\n\nBest Time: Early morning, weekdays\nCrowd: Very high on weekends & festivals",
    location: "Yadadri Bhuvanagiri District, ~60 km from Hyderabad",
    bestTime: "October - March (Early morning, weekdays)",
    stories: [
      "Ancient cave temple associated with Yada Maharishi",
      "One of the most important Vaishnava shrines in South India",
      "Recently developed into a world-class temple complex"
    ]
  },
  {
    id: 17,
    name: "Kulpakji (Kolanu Pak) Jain Temple – Warangal",
    category: "Temples",
    district: "Yadadri Bhuvanagiri",
    image: "/yadadri-2.jpg",
    shortDescription: "Over 2,000 years old - one of the few Jain temples with living Jain monks.",
    description: "Over 2,000 years old. One of the few Jain temples with living Jain monks. Features rare idol made of jade stone.\n\nLocation: Kulpak (Kolanupaka), Jangaon District, Telangana (~80 km from Hyderabad)\n\nTimings: 5:00 AM – 8:00 PM\n\nDeity: Lord Adinatha, Neminatha & Mahavira (Jain Tirthankaras)\nOfferings: Rice, fruits (strictly no flowers or sweets)\n\nTransport:\n• Road: Buses from Hyderabad & Warangal\n• Rail: Jangaon station (nearest)\n\nDress & Rituals: Very strict modest dressing. Silence & Jain rituals observed\n\nNearby Attractions: Jain Museum, local heritage village\n\nBest Time: Morning hours\nCrowd: Moderate, peaceful atmosphere",
    location: "Kulpak (Kolanupaka), Jangaon District, ~80 km from Hyderabad",
    bestTime: "October - March (Morning hours)",
    stories: [
      "Over 2,000 years old",
      "One of the few Jain temples with living Jain monks",
      "Features rare idol made of jade stone"
    ]
  },
  {
    id: 46,
    name: "Swarnagiri Venkateswara Swamy Temple (Yadadri)",
    category: "Temples",
    district: "Yadadri Bhuvanagiri",
    image: "/yadadri-3.jpg",
    shortDescription: "Newly developed hill temple inspired by Tirumala Tirupati architecture.",
    description: "Newly developed hill temple inspired by Tirumala Tirupati architecture. Known for peaceful environment & golden gopuram concept.\n\nLocation: Near Yadadri Temple, Bhuvanagiri District\n\nTimings: 6:00 AM – 8:00 PM\n\nDeity: Lord Venkateswara Swamy\nOfferings: Laddus, coconuts, flowers\n\nTransport: Road - Easily accessible from Yadadri. Autos & temple transport available\n\nDress Code: Traditional dress preferred\n\nNearby Attractions: Yadadri Temple, Surendrapuri\n\nBest Time: Early morning & evening\nCrowd: Moderate",
    location: "Near Yadadri Temple, Bhuvanagiri District",
    bestTime: "October - February (Early morning & evening)",
    stories: [
      "Newly developed hill temple",
      "Inspired by Tirumala Tirupati architecture",
      "Known for peaceful environment & golden gopuram concept"
    ]
  },
  {
    id: 19,
    name: "Sri Ranganayaka Swamy Temple",
    category: "Temples",
    district: "Wanaparthy",
    image: "/ranganayaka-swamy-1.jpg",
    shortDescription: "A magnificent 18th-century Vijayanagara style temple.",
    description: "Located in Srirangapur Village, approximately 12 km from Wanaparthy Town, this temple is a masterpiece of 18th-century architecture. Built by the Rajas of Wanaparthy Samsthanam, it reflects the grandeur of the Vijayanagara style and was inspired by the world-famous Sri Ranganathaswamy Temple in Srirangam.\n\nDeity & Significance:\nThe temple is dedicated to Lord Ranganayaka Swamy (Lord Vishnu). It stands as a major Vaishnava pilgrimage center in Telangana.\n\nVisitor Information:\n- Timings: 06:00 AM – 01:00 PM & 04:00 PM – 08:00 PM\n- Best Time: December to February.\n- Dress Code: Traditional & modest attire (Dhoti/Saree preferred).\n- Transport: TSRTC buses, autos, and private taxis available.",
    location: "Sri Rangapur Village, Pebbair Mandal, Wanaparthy District",
    bestTime: "December - February",
    stories: [
      "Inspired by the architectural marvel of Srirangam.",
      "A symbol of the Wanaparthy Samsthanam's devotion and patronage."
    ]
  },
  {
    id: 20,
    name: "Sri Venkateswara Swamy Temple",
    category: "Temples",
    district: "Wanaparthy",
    image: "/venkateswara-swamy.jpg",
    shortDescription: "A serene spiritual hub in the heart of Wanaparthy.",
    description: "Nestled in the Maremmakunta area of Wanaparthy Town, this temple dedicated to Lord Venkateswara Swamy is a central point of devotion for local residents. Known for its peaceful atmosphere, it provides a perfect setting for daily prayers and meditation.\n\nVisitor Information:\n- Timings: 06:00 AM onwards (Open for morning and evening darshan)\n- Offerings: Tulsi leaves, laddus, and lamps are commonly offered by devotees.\n- Accessibility: Easily reachable by auto or bus from the town center.",
    location: "Maremmakunta Area, Wanaparthy Town",
    bestTime: "December - February",
    stories: [
      "One of the most visited temples by local devotees for weekend prayers.",
      "Renowned for its meticulously performed daily poojas."
    ]
  },
  {
    id: 21,
    name: "Shirdi Sai Baba Temple",
    category: "Temples",
    district: "Wanaparthy",
    image: "/sai-baba-wanaparthy.jpg", // User uploaded image
    shortDescription: "A peaceful spiritual haven dedicated to Shirdi Sai Baba.",
    description: "Located within the residential clusters of Wanaparthy Town, the Shirdi Sai Baba Temple is a hub of community faith. It features a beautiful white marble statue of Sai Baba and is particularly known for its vibrant Thursday celebrations and daily aartis that draw people from all walks of life.\n\nVisitor Information:\n- Timings: 05:30 AM – 08:30 PM\n- Special Events: Thursday special poojas and community meals (Annadhanam).\n- Atmosphere: Peaceful and meditative.",
    location: "Wanaparthy Town (Residential Areas)",
    bestTime: "December - February",
    stories: [
      "A place where community bonds are strengthened through shared devotion.",
      "Popular for the soothing evening aarti sessions."
    ]
  },
  {
    id: 22,
    name: "Calvary Town Church",
    category: "Churches",
    district: "Wanaparthy",
    image: "https://th.bing.com/th/id/OIP.w9iTWEdhnT3BVMp1Xr5kXwHaEK?w=292&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7", // Realistic church
    shortDescription: "A prominent landmark for the Christian community in Wanaparthy.",
    description: "One of the largest and most well-known churches in the heart of Wanaparthy Town. Known for its modern architecture and vibrant Sunday services, it serves as a central point for spiritual gatherings and community service.\n\nVisitor Information:\n- Timings: 09:00 AM – 01:00 PM (Sundays)\n- Atmosphere: Welcoming and lively during services.",
    location: "Town Center, Wanaparthy",
    bestTime: "December - February",
    stories: [
      "Known for its extensive charitable activities in the local district."
    ]
  },
  {
    id: 23,
    name: "Emmanuel M.B. Church",
    category: "Churches",
    district: "Wanaparthy",
    image: "https://th.bing.com/th/id/OIP.sUk5u0Y0L2mCRjjHxo05EQHaE8?w=253&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7", // Historic church feel
    shortDescription: "A historic community church with a rich heritage.",
    description: "Located on the Tadiparthy-Chennur Road, this church has a long-standing history in the region. It is known for its traditional liturgical services and its role in local education and social welfare.\n\nVisitor Information:\n- Services: Fridays and Sundays\n- Location: Accessible from the main town highway.",
    location: "Tadiparthy Road, Wanaparthy",
    bestTime: "December - February",
    stories: [
      "One of the oldest Christian missionary foundations in the district."
    ]
  },
  {
    id: 24,
    name: "Madina Masjid",
    category: "Mosques",
    district: "Wanaparthy",
    image: "https://files.yappe.in/place/small/madina-masjid-9457555.webp", // Grand masjid architecture
    shortDescription: "A grand and historic mosque in the heart of the town.",
    description: "Situated on Kothakota Road, Madina Masjid is one of the most significant Islamic centers in Wanaparthy. Its elegant architecture and large prayer hall accommodate hundreds of devotees during Jumu'ah (Friday) prayers.\n\nVisitor Information:\n- Timings: Open for five daily prayers.\n- Features: Traditional Islamic calligraphy and peaceful courtyard.",
    location: "Kothakota Road, Wanaparthy",
    bestTime: "December - February",
    stories: [
      "A central hub for community gatherings during Eid festivals."
    ]
  },
  {
    id: 25,
    name: "Aqsa Masjid",
    category: "Mosques",
    district: "Wanaparthy",
    image: "https://archive.siasat.com/wp-content/uploads/2021/01/wanaparthy.jpg", // Serene masjid atmosphere
    shortDescription: "A beautiful mosque known for its serene atmosphere.",
    description: "Located in Vengal Rao Nagar, Aqsa Masjid is admired for its clean, white architecture and tranquil surroundings. It is a preferred spot for those seeking a quiet place for prayer and reflection.\n\nVisitor Information:\n- Location: Residential area of Vengal Rao Nagar.\n- Atmosphere: Intimate and spiritual.",
    location: "Vengal Rao Nagar, Wanaparthy",
    bestTime: "December - February",
    stories: [
      "Known for its well-maintained architecture and community focus."
    ]
  },
  {
    id: 26,
    name: "Wanaparthy Eco Park",
    category: "Parks",
    district: "Wanaparthy",
    image: "https://i.ytimg.com/vi/-h07Ww6AHWc/maxresdefault.jpg",
    shortDescription: "A lush green initiative by the Forest Department.",
    description: "The Wanaparthy Eco Park is a premier destination for nature lovers. Managed by the Forest Department, it features diverse plant species, walking trails, and educational signage about local flora and fauna. It's an ideal spot for morning walks and family outings.\n\nVisitor Information:\n- Timings: 06:00 AM – 10:00 AM & 04:00 PM – 07:00 PM\n- Best for: Bird watching and photography.",
    location: "Town Outskirts, Wanaparthy",
    bestTime: "September - February",
    stories: [
      "Developed to promote environmental awareness among local youth."
    ]
  },
  {
    id: 27,
    name: "NTR Central Park",
    category: "Parks",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1000&auto=format&fit=crop",
    shortDescription: "A popular family recreation hub in the town center.",
    description: "NTR Central Park is the heart of recreational activities in Wanaparthy Town. With children's play areas, manicured lawns, and musical fountains, it is the most visited evening destination for families and tourists alike.\n\nVisitor Information:\n- Highlights: Children's play zone, jogging track, and evening lighting.\n- Crowd: High on weekends.",
    location: "Town Center, Wanaparthy",
    bestTime: "December - February",
    stories: [
      "A favorite spot for local cultural festivals and community events."
    ]
  },
  {
    id: 28,
    name: "Sky 7 Multi Cuisine Restaurant",
    category: "Local Food",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80",
    shortDescription: "A premium multi-cuisine dining experience.",
    description: "Rated 4.7/5, Sky 7 is known for its elegant design and cozy ambiance. It offers a diverse menu ranging from classic favorites to contemporary dishes, making it the perfect spot for family dinners and special occasions.\n\nVisitor Information:\n- Timings: 7:00 AM – 11:30 PM\n- Special Cuisine: North Indian, Chinese, and Continental fusion.",
    location: "Opposite Kota Maisamma Temple Lane, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "Known for the best fine-dining ambiance in Wanaparthy.",
      "A variety of cuisines under one roof."
    ]
  },
  {
    id: 29,
    name: "Telugu Aromas Biryanis and Pulavs",
    category: "Local Food",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?q=80",
    shortDescription: "Where tradition meets innovation in every bite.",
    description: "A culinary haven rated 4.4/5, Telugu Aromas is famous for its authentic spicy Pulavs and Biryanis. The restaurant uses quality ingredients to bring out the traditional flavors of Telugu cuisine.\n\nFood Highlights:\n- Must Try: Natu Kodi Pulav, Chicken Joint Biryani, Soya Keema Biryani, Paneer Kurkure.\n- Timings: 12:00 PM – 11:30 PM.",
    location: "Near Rajeev Chowk, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "Famous for its fiery and authentic Natu Kodi Pulav.",
      "A favorite spot for spice lovers."
    ]
  },
  {
    id: 61,
    name: "Vivaha Bhojanambu",
    category: "Local Food",
    district: "Wanaparthy",
    image: "https://vivahabhojanambu.co.in/wp-content/uploads/2020/12/logo-1.png",
    description: "Rated 4.2/5, this restaurant offers a 'homely taste' with terrific service in a calm atmosphere. It specializes in traditional bhojanam (thalis) and spicy non-veg starters.\n\nFood Highlights:\n- Specialties: Rajugari Bhojanam, Natu Kodi Biryani, Guthivankaya Pulao.\n- Timings: 11:00 AM – 11:00 PM.",
    location: "Opposite New Bus Stand, Near Sudha Nursing Home, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "Offers the grand 'Rajugari Bhojanam' feast.",
      "Known for its polite staff and traditional hospitality."
    ]
  },
  {
    id: 62,
    name: "Taj Mandi Restaurant",
    category: "Local Food",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1512058564366-18510be2db19?q=80",
    shortDescription: "The destination for authentic Mandi and Kunafa.",
    description: "A top-rated spot (4.2/5) for Arabian and Hyderabadi cuisine lovers. Famous for its communal Mandi dining experience and the sweet treat Kunafa.\n\nFood Highlights:\n- Specialties: Special Mandi, Juicy Mutton Mandi, Kunafa, Kebabs.\n- Timings: 11:00 AM – 12:00 AM.",
    location: "Old Bus Stand, Chandapur, Raigadda, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "One of the few places serving authentic Kunafa in the district.",
      "Open late night for food lovers."
    ]
  },
  {
    id: 63,
    name: "Akshaya Family Restaurant",
    category: "Local Food",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80",
    shortDescription: "A perfect family dining spot with a diverse menu.",
    description: "Rated 4.0/5, Akshaya is a well-established family restaurant offering a mix of North Indian, South Indian, and Chinese cuisines. It is known for its consistent taste and family-friendly environment.\n\nFood Highlights:\n- Favorites: Chicken Biryani, Paneer Butter Masala, Ginger Veg Curry.\n- Timings: 12:00 PM – 4:30 PM & 6:30 PM – 11:00 PM.",
    location: "Pebbair Road, Beside Rural Police Station, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "A go-to spot for family gatherings and celebrations.",
      "Conveniently located near the MLA Camp Office."
    ]
  },
  {
    id: 64,
    name: "Srirangapur Jatara",
    category: "Seasonal Festivals",
    district: "Wanaparthy",
    image: "https://2.bp.blogspot.com/-gYtHtiXvQjE/WJXbuZQWprI/AAAAAAAACoA/7Y2BXcbABZwU2Dsz1qQHRZO8QhnPAo7AQCLcB/s1600/peddagattu-jathara.jpg",
    shortDescription: "A grand 15-day pilgrimage festival.",
    description: "Celebrated at the historic Sri Ranganayaka Swamy Temple, this 15-day Jatara draws devotees from Karnataka, Maharashtra, and beyond. It is one of the most significant religious gatherings in the district.\n\nHighlights:\n- Rathotsavam (Chariot procession).\n- Cultural performances and local fairs.",
    location: "Srirangapur Village, Wanaparthy",
    bestTime: "March",
    stories: [
      "Showcases the rich cultural heritage of the Wanaparthy Samsthanam.",
      "Devotees believe the deity fulfills sincere wishes."
    ]
  },
  {
    id: 67,
    name: "Hotel Haritha (Wanaparthy)",
    category: "Hotels",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?q=80",
    shortDescription: "Government-run hotel offering a comfortable stay.",
    description: "Operated by Telangana Tourism, Hotel Haritha offers spacious AC and Non-AC rooms with a restaurant serving authentic local cuisine. It is known as a 'home away from home' for tourists visiting the district.\n\nVisitor Information:\n- Price Range: ₹1000 - ₹2000\n- Highlights: Spacious parking, restaurant attached.",
    location: "Wanaparthy Town",
    bestTime: "All year round",
    stories: [
      "The preferred choice for government officials and tourists."
    ]
  },
  {
    id: 68,
    name: "KPR Residency",
    category: "Hotels",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80",
    shortDescription: "Modern comfort with exceptional service.",
    description: "Rated 5.0/5 by locals, KPR Residency is a modern hotel known for its cleanliness and exceptional hospitality. It offers well-maintained rooms at budget-friendly prices.\n\nVisitor Information:\n- Price Range: ₹800 - ₹1500\n- Location: Near New Bus Stand.",
    location: "Near New Bus Stand, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "Praised for its hassle-free check-in and friendly staff."
    ]
  },
  {
    id: 69,
    name: "Manorama Hotel",
    category: "Hotels",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1596436889106-be35e843f974?q=80",
    shortDescription: "Old-time charm with excellent hospitality.",
    description: "A well-known establishment in Wanaparthy, Manorama Hotel offers a mix of old-world charm and convenient amenities. It is an affordable option for families and business travelers.\n\nVisitor Information:\n- Price Range: Affordable\n- Highlights: Convenient location on the main road.",
    location: "Main Road, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "A landmark hotel that has served the town for years."
    ]
  },
  {
    id: 70,
    name: "Hotel Rajadhani Luxury Rooms",
    category: "Hotels",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?q=80",
    shortDescription: "Experience luxury and comfort in the heart of Wanaparthy.",
    description: "Hotel Rajadhani offers premium AC and Non-AC luxury rooms with modern amenities. Known for its cleanliness, hospitality, and comfortable ambiance, it is a perfect choice for families and business travelers seeking a touch of luxury.\n\nVisitor Information:\n- Price Range: ₹1200 - ₹2500\n- Amenities: WiFi, Room Service, Parking.",
    location: "Wanaparthy Town",
    bestTime: "All year round",
    stories: [
      "Newest luxury addition to Wanaparthy's hospitality sector."
    ]
  },

  {
    id: 30,
    name: "J P Shopping Mall",
    category: "Shopping Malls",
    district: "Wanaparthy",
    image: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?q=80&w=1000&auto=format&fit=crop",
    shortDescription: "The premier retail destination for fashion and lifestyle.",
    description: "J P Shopping Mall is the largest retail complex in Wanaparthy, offering a wide range of apparel, electronics, and household items. It is the go-to place for festive shopping and the latest fashion trends.\n\nHighlights:\n- Range: Dedicated floors for sarees, men's wear, and children's clothing.\n- Features: Modern interiors and central location.",
    location: "Gandhi Chowk Area, Wanaparthy",
    bestTime: "October - January",
    stories: [
      "A landmark that revolutionized the shopping experience in the district."
    ]
  },
  {
    id: 31,
    name: "Trends Fashion Hub",
    category: "Shopping Malls",
    district: "Wanaparthy",
    image: "https://tse3.mm.bing.net/th/id/OIP.lR71SDaasB2VjiEtE1PtKQHaE0?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Global trends at your local convenience.",
    description: "Located near KDR Nagar, this modern store brings national and global fashion trends to Wanaparthy. Known for its seasonal collections and affordable prices, it is a favorite for the youth and modern shoppers.\n\nHighlights:\n- Specialized in: Western wear, casuals, and ethnic Fusion.",
    location: "KDR Nagar Road, Wanaparthy",
    bestTime: "October - January",
    stories: [
      "Brought the convenience of modern retail chains to the town heart."
    ]
  },
  {
    id: 32,
    name: "Chilkur Balaji Temple",
    category: "Temples",
    district: "Hyderabad",
    image: "/chilkur-balaji.jpg",
    shortDescription: "The 'Visa Balaji' temple where faith moves mountains.",
    description: "Located near the banks of Gandipet lake, this 500-year-old temple is one of the oldest in the Hyderabad region. It is famously known as the 'Visa Balaji' temple due to the belief that praying here helps devotees secure visas for foreign travel.\n\nUnique Features:\n- It is one of the few temples in India without a 'Hundi' (donation box).\n- Devotees perform 11 'Pradakshinas' (circumambulations) to make a wish and 108 if it's fulfilled.\n\nVisitor Information:\n- Timings: 05:00 AM – 08:00 PM\n- Dress Code: Traditional and respectful attire.\n- Transport: TSRTC buses (Route 288) and private vehicles available.",
    location: "Chilkur Village, Gandipet",
    bestTime: "October - February",
    stories: [
      "Known for its strict discipline and spiritual purity.",
      "A symbol of sincere prayer over material donations."
    ]
  },
  {
    id: 33,
    name: "Birla Mandir",
    category: "Temples",
    district: "Hyderabad",
    image: "/birla-mandir.jpg",
    shortDescription: "A white marble marvel overlooking the city.",
    description: "Built in 1976 by the Birla Foundation, this temple is constructed entirely of 2000 tons of pure white Rajasthani marble. It stands atop the 280-foot high Naubat Pahad hill, offering a panoramic view of Hyderabad and Secunderabad.\n\nArchitecture & Deity:\n- Dedicated to Lord Venkateswara (Lord Vishnu).\n- The architecture blends South Indian, Rajasthani, and Utkala styles.\n- Features scenes from the Ramayana and Mahabharata finely sculpted in marble.\n\nVisitor Information:\n- Timings: 07:00 AM – 12:00 PM & 03:00 PM – 09:00 PM\n- Note: Electronic gadgets and cameras are strictly prohibited inside.",
    location: "Naubat Pahad, near Lakdi-ka-Pul",
    bestTime: "October - March (Evening visits recommended)",
    stories: [
      "The hill was once used as a platform for the Nizam's band (Naubat).",
      "No bells are found in the temple as it is meant to be a place of quiet meditation."
    ]
  },
  {
    id: 34,
    name: "Karmanghat Hanuman Temple",
    category: "Temples",
    district: "Hyderabad",
    image: "/karmanghat-hanuman.jpg",
    shortDescription: "An ancient fortress of faith that once defied emperors.",
    description: "One of the oldest temples in the city, dating back over 800 years to the Kakatiya period. Legend has it that when Mughal Emperor Aurangzeb tried to destroy the temple, his soldiers could not even cross the gateway, and a thunderous voice challenged him, leading to the name 'Kar-man-ghat' (Make your heart strong).\n\nVisitor Information:\n- Timings: 05:30 AM – 12:00 PM & 04:00 PM – 08:30 PM\n- Auspicious Days: Tuesdays and Saturdays see a heavy influx of devotees.\n- Deity: Lord Hanuman (Dhyana Anjaneya).",
    location: "Karmanghat, near LB Nagar",
    bestTime: "October - February",
    stories: [
      "Aurangzeb famously failed to demolish this temple.",
      "Considered a 'soft-hearted' deity who fulfills all sincere wishes."
    ]
  },
  {
    id: 35,
    name: "Peddamma Thalli Temple",
    category: "Temples",
    district: "Hyderabad",
    image: "/peddamma-thalli.jpg",
    shortDescription: "The powerful guardian goddess of Jubilee Hills.",
    description: "One of Hyderabad's most popular Shakti temples, dedicated to the supreme Mother Goddess. The temple is especially famous for the Bonalu festival celebrations and is a frequent visit spot for many prominent figures in the city.\n\nHighlights:\n- The grand colorful Gopuram is a local landmark.\n- Special prayers and rituals during the Ashada Masam (July-August).\n\nVisitor Information:\n- Timings: 06:00 AM – 01:00 PM & 03:00 PM – 08:00 PM\n- Crowd: Extremely high on Sundays and during festival seasons.",
    location: "Jubilee Hills Road No. 55",
    bestTime: "July - August (Bonalu Festival)",
    stories: [
      "Considered the protector of the local region.",
      "The Bonalu procession here is one of the most vibrant in the city."
    ]
  },
  {
    id: 36,
    name: "St. Mary's Basilica",
    category: "Churches",
    district: "Hyderabad",
    image: "https://archdioceseofhyderabad.org/images/parish-images/chapel-st-marys-minor-basilica-secunderabad.jpg",
    shortDescription: "A historic Gothic masterpiece in Secunderabad.",
    description: "St. Mary's Basilica is one of the oldest and most beautiful Roman Catholic churches in the twin cities. Consecrated in 1850, it features stunning Gothic architecture with pointed arches and ribbed vaults.\n\nFeatures:\n- Multiple altars dedicated to different saints.\n- Exquisite stained-glass windows representing biblical scenes.\n- A peaceful courtyard that offers respite from the busy city traffic.",
    location: "Sarojini Devi Road, Secunderabad",
    bestTime: "December (Christmas season)",
    stories: [
      "Elevated to the status of a Minor Basilica in 2008.",
      "A symbol of the diverse religious harmony in the region."
    ]
  },
  {
    id: 37,
    name: "St. Joseph's Cathedral",
    category: "Churches",
    district: "Hyderabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRA1AOem29rUwDgbhYph-o9aptcizHwKmrt6A&s",
    shortDescription: "The majestic Roman Catholic cathedral of Abids.",
    description: "Located in the heart of Abids, St. Joseph's Cathedral is the seat of the Archbishop. Built in 1875, it is renowned for its Italian architectural influence and the massive bells imported from Italy.\n\nArchitecture:\n- Features a replica of Michelangelo's 'Pieta'.\n- Known for its high ceilings and excellent acoustics during choir performances.\n\nVisitor Information:\n- Best Time: Sunday Mass and during Christmas week.",
    location: "Gunfoundry, Abids",
    bestTime: "November - January",
    stories: [
      "The cathedral bells can play specific hymns heard across the neighborhood."
    ]
  },
  {
    id: 38,
    name: "Mecca Masjid",
    category: "Mosques",
    district: "Hyderabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmTUmbiosXtntFXpzfOoIMqsHhlincOgkMpA&s",
    shortDescription: "One of India's largest and most historic mosques.",
    description: "Mecca Masjid is a monumental landmark located stone's throw away from Charminar. Commissioned in 1614 and completed in 1694, it is named after the holy city of Mecca, as some of the bricks used in its central arch were made from soil brought from Mecca.\n\nHighlights:\n- Can accommodate over 10,000 worshippers at a time.\n- Features grand granite arches and intricate floral carvings.\n- Houses the tombs of several Nizams of the Asaf Jahi dynasty.",
    location: "Old City, near Charminar",
    bestTime: "October - March (Best during Ramadan)",
    stories: [
      "The massive central arch took 77 years to complete.",
      "A single piece of granite was used for the main prayer hall pillars."
    ]
  },
  {
    id: 39,
    name: "Spanish Mosque",
    category: "Mosques",
    district: "Hyderabad",
    image: "https://s7ap1.scene7.com/is/image/incredibleindia/spanish-mosque-hyderabad-secunderabad-telangana-3-copy-attr-hero?qlt=82&ts=1742161395262",
    description: "Also known as 'Masjid Iqbal-ud-Daula', this mosque is one of its kind in India. Built in 1906, it features distinct Spanish architecture inspired by the Cathedral–Mosque of Cordoba.\n\nUnique Features:\n- Unlike traditional mosques, it lacks domes and typical minarets.\n- The towers resemble church spires or castle turrets.\n- Walls are decorated with beautiful Quranic verses in gold.",
    location: "Begumpet, Hyderabad",
    bestTime: "October - March",
    stories: [
      "Built by Sir Vicar-ul-Umra after his travels to Europe.",
      "Often called the 'Mosque of the Moors'."
    ]
  },
  {
    id: 40,
    name: "KBR National Park",
    category: "Parks",
    district: "Hyderabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTLS2PP4j8uEayOvI34nNfWz-b56ZPbvwCm2g&s",
    shortDescription: "A massive urban forest in the heart of Jubilee Hills.",
    description: "Kasu Brahmananda Reddy (KBR) National Park is a 390-acre sanctuary providing much-needed green cover to the city. It is a haven for birds, peacocks, and various flora and fauna.\n\nActivities:\n- Popular for early morning and evening jogging.\n- Nature photography and bird watching.\n- Provides a cool micro-climate in the middle of a busy residential area.",
    location: "Jubilee Hills Check Post",
    bestTime: "June - February (Lush green after rains)",
    stories: [
      "The park area was originally part of the Chiran Palace estate of the Nizam."
    ]
  },
  {
    id: 41,
    name: "Lumbini Park",
    category: "Parks",
    district: "Hyderabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ06YNNVwua1HqE9qquQbIbV4-tKjSfiuJY5Q&s",
    shortDescription: "Scenic lakefront park with iconic boating and laser shows.",
    description: "Situated on the banks of Hussain Sagar Lake, Lumbini Park is a top attraction for tourists and families. It is the main boarding point for ferries to the Buddha Statue in the middle of the lake.\n\nHighlights:\n- Musical fountain and nightly high-tech laser show.\n- Beautiful floral clock at the entrance.\n- Stunning evening views of the standing Buddha statue.",
    location: "Tank Bund Road",
    bestTime: "October - March",
    stories: [
      "Named after the birthplace of Lord Buddha."
    ]
  },
  {
    id: 42,
    name: "Hyderabad Botanical Garden",
    category: "Parks",
    district: "Hyderabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpzeeaEhVCDaQws4YLhDdqHbuoUYxiCMNnkA&s",
    shortDescription: "270 acres of ecological wonder near Hitech City.",
    description: "The Sri Kotla Vijaya Bhaskara Reddy Botanical Garden is a vast expanse of greenery dedicated to the conservation of plants. It features 19 different sectors including bamboo, palm, medicinal plants, and timber trees.\n\nVisitor Info:\n- Features meandering waterways and rock formations.\n- Ideal for educational trips and peaceful nature walks.\n- Great spot for photography during the bloom season.",
    location: "Kothaguda, near Hitec City",
    bestTime: "September - February",
    stories: [
      "A vital carbon sink for the city's IT hub."
    ]
  },
  {
    id: 43,
    name: "Sarath City Capital Mall",
    category: "Shopping Malls",
    district: "Hyderabad",
    image: "https://sarathcitycapitalmall.com/wp-content/uploads/2020/04/mall-front-1080x450-1.jpg",
    shortDescription: "One of the largest shopping malls in India.",
    description: "A massive shopping destination in Kondapur, spanning over 8 floors and millions of square feet. It houses hundreds of national and international brands, a massive food court, and multiple entertainment zones.\n\nEntertainment:\n- Largest multiplex in the city (AMB Cinemas).\n- Indoor adventure park and gaming arcades.\n- Frequent celebrity visits and cultural events.",
    location: "Kondapur, Hitech City Road",
    bestTime: "All Year (Peak during festivals)",
    stories: [
      "Redefined the mall experience in South India with its sheer scale."
    ]
  },
  {
    id: 44,
    name: "Inorbit Mall",
    category: "Shopping Malls",
    district: "Hyderabad",
    image: "https://andhra.mallsmarket.com/sites/default/files/photos/malls/InorbitMall-Cyberabad-1.jpg",
    shortDescription: "Premium shopping with a stunning lake view.",
    description: "Located in the heart of Hitech City, Inorbit Mall is famous for its curated mix of premium brands and its beautiful location overlooking the Durgam Cheruvu lake.\n\nHighlights:\n- Excellent view of the Cable Bridge from the food court.\n- High-end fashion boutiques and electronics stores.\n- Popular destination for business travelers and IT professionals.",
    location: "Mindspace, Madhapur",
    bestTime: "Evening visits for the lake view",
    stories: [
      "Known for its sustainability initiatives and green building practices."
    ]
  },
  {
    id: 45,
    name: "Bonalu Festival",
    category: "Seasonal Festivals",
    district: "Hyderabad",
    image: "/peddamma-thalli.jpg",
    shortDescription: "The energetic spirit of the Mother Goddess celebrations.",
    description: "Bonalu is a traditional Telangana Hindu festival centered on the Goddess Mahakali. Devotees (mostly women) carry 'Bonam' (cooked rice with milk and jaggery in a brass or earthen pot) to temples as an offering.\n\nHighlights:\n- The 'Pothuraju' leading the vibrant processions with whips.\n- Rhythmic drum beats and folk dances.\n- Celebrated extensively at Golconda, Secunderabad, and Old City temples.",
    location: "City-wide (Major hubs: Golconda, Ujjaini Mahakali)",
    bestTime: "July - August",
    stories: [
      "A thanksgiving festival to the Goddess for protecting the city from plague."
    ]
  },
  {
    id: 50,
    name: "Jainath Temple",
    category: "Temples",
    district: "Adilabad",
    image: "/adilabad-jainath.jpg",
    shortDescription: "Ancient temple dedicated to Lord Surya Narayana.",
    description: "Built by the Pallava king, this temple is a masterpiece of Jain style architecture. The temple is dedicated to Lord Surya Narayana and features intricate carvings and inscriptions.",
    location: "Jainath, Adilabad",
    bestTime: "October - March",
    stories: [
      "The sun's rays fall directly on the deity's feet during specific times of the year."
    ]
  },
  {
    id: 51,
    name: "Nagoba Temple",
    category: "Temples",
    district: "Adilabad",
    image: "/adilabad-nagoba.jpg",
    shortDescription: "A sacred tribal temple famous for the Nagoba Jatara.",
    description: "Located in Keslapur village, this temple is dedicated to the serpent god Nagoba. It is the center of the famous Nagoba Jatara, the second largest tribal festival in Telangana held by the Gond tribe.",
    location: "Keslapur, Adilabad",
    bestTime: "January - February (During Jatara)",
    stories: [
      "The Gond tribe performs the Maha Puja here every year."
    ]
  },
  {
    id: 52,
    name: "Basar Gnana Saraswati Temple",
    category: "Temples",
    district: "Adilabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZSaLUZOnha5dTLYg2mTOldg1VZpm44NLFCw&s",
    shortDescription: "One of the two famous Saraswati temples in India.",
    description: "Situated on the banks of the Godavari River, this ancient temple is dedicated to Goddess Saraswati. It is a major pilgrimage site for 'Akshara Abhyasam' (initiation of education) for children.",
    location: "Basar, Nirmal (near Adilabad)",
    bestTime: "All year round",
    stories: [
      "Legend says Sage Vyasa meditated here."
    ]
  },
  {
    id: 53,
    name: "Kalwa Narasimha Swamy Temple",
    category: "Temples",
    district: "Adilabad",
    image: "/adilabad-kalwa.jpg",
    shortDescription: "A serene temple located amidst nature.",
    description: "Surrounded by lush greenery, this temple dedicated to Lord Narasimha is a popular spot for devotees and nature lovers alike. The annual jatara draws large crowds.",
    location: "Kalwa, Adilabad",
    bestTime: "August - February",
    stories: [
      "The temple is situated near a dense forest area."
    ]
  },
  {
    id: 54,
    name: "CSI Holy Cross Cathedral",
    category: "Churches",
    district: "Adilabad",
    image: "https://www.cdn.smcimprojects.com/img_browse?photo=MVlObER4cFkxV3RTL2owNy9HN2JPTWIvZTVVemlXYmp5NFc3a2NRaXl2MFNveVhQbkpkb0ZiN09tT2JsRGpvRg==&t_id=dzNvNEFrb3VvbnVNNjE5a2pSdDlYUT09&d_id=dmdlMXBVWkNqcS95MkFDVmlEWExZQT09",
    shortDescription: "A prominent cathedral serving the local community.",
    description: "This historic cathedral is known for its beautiful architecture and vibrant Sunday services. It serves as a spiritual hub for the Christian community in the district.",
    location: "Adilabad Town",
    bestTime: "December",
    stories: []
  },
  {
    id: 55,
    name: "St. Joseph's Cathedral",
    category: "Churches",
    district: "Adilabad",
    image: "https://www.cdn.smcimprojects.com/img_browse?photo=MzF2LzlObVByOEgyajZjZllrQ0xNYm1ET0Y4eFU1TG9CWnZJUFFOZmRYZWZtTC95OXo1Wk5SenlKdXRzZ2YrQQ==&t_id=dzNvNEFrb3VvbnVNNjE5a2pSdDlYUT09&d_id=dmdlMXBVWkNqcS95MkFDVmlEWExZQT09",
    shortDescription: "A peaceful place of worship in the heart of the town.",
    description: "St. Joseph's Cathedral stands as a symbol of peace and faith. The church architecture is simple yet elegant, providing a tranquil environment for prayer.",
    location: "Adilabad Town",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 56,
    name: "Jama Masjid",
    category: "Mosques",
    district: "Adilabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-GvhsM5dwwKMBGw5lhLB9lDrSBlymcYB5AQ&s",
    shortDescription: "The largest mosque in Adilabad.",
    description: "Jama Masjid is the central mosque of Adilabad, featuring grand domes and minarets. It is a major gathering place for Friday prayers and Eid celebrations.",
    location: "Adilabad Town center",
    bestTime: "Ramadan",
    stories: []
  },
  {
    id: 57,
    name: "Madina Masjid",
    category: "Mosques",
    district: "Adilabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqu5GMf9_qExZ6c4IXr3HKGaxHP63tTQiYng&s",
    shortDescription: "A beautiful mosque with a community focus.",
    description: "Known for its community activities and architectural beauty, Madina Masjid is a key spiritual center in Adilabad.",
    location: "Adilabad",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 58,
    name: "Jowar Roti (Jonna Rotte)",
    category: "Local Food",
    district: "Adilabad",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5b2cJrB-B62N2lPL4PhAhPwbK15ssXSVmqA&s",
    shortDescription: "The staple healthy flatbread of the region.",
    description: "Jowar Roti, made from sorghum flour, is the daily staple food in Adilabad. It is gluten-free and usually served with spicy curries or dal.",
    location: "Available in all local mess and hotels",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 59,
    name: "Spicy Mutton Curry",
    category: "Local Food",
    district: "Adilabad",
    image: "https://www.licious.in/blog/wp-content/uploads/2020/12/Mutton-Masala-min.jpg",
    shortDescription: "A fiery and flavorful meat delicacy.",
    description: "Adilabad is known for its spicy non-vegetarian cuisine. The traditional mutton curry cooked with local spices is a must-try for meat lovers.",
    location: "Local Restaurants",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 60,
    name: "Sarva Pindi",
    category: "Local Food",
    district: "Adilabad",
    image: "https://www.shutterstock.com/shutterstock/photos/1537071020/display_1500/stock-photo-sarva-pindi-a-dish-native-to-the-state-of-telangana-india-a-delicious-home-cooked-spicy-flat-1537071020.jpg",
    shortDescription: "A savory pancake and popular tea-time snack.",
    description: "Sarva Pindi is a traditional spicy pancake made from rice flour, chana dal, sesame seeds, and curry leaves. It's unique to Telangana.",
    location: "Street food stalls",
    bestTime: "Evenings",
    stories: []
  },
  {
    id: 71,
    name: "Traditional Handloom Weaving in Kothakota",
    category: "Local Experiences / Crafts",
    district: "Wanaparthy",
    image: "https://tse3.mm.bing.net/th/id/OIP.fLn1njO6ks-BxDpOhbO0VwHaE8?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Witness the artistry of Kothakota silk sarees.",
    description: "In places like Kothakota within Wanaparthy district, silk weaving has a long-standing heritage, where artisans produce Kothakota silk sarees with intricate zari work, reflecting craftsmanship passed down through generations. You can visit weaving centres to see the handloom process up close.",
    location: "Kothakota, Wanaparthy",
    bestTime: "All year round",
    stories: [
      "Kothakota sarees are known for their distinct borders and pallus.",
      "The craft has been patronized by the Wanaparthy Samsthanam for centuries."
    ]
  },
  {
    id: 72,
    name: "Local Handicrafts in Weekly Markets",
    category: "Local Experiences / Crafts",
    district: "Wanaparthy",
    image: "https://www.inside-egypt.com/files/upload/images/zakupy.jpg",
    shortDescription: "Discover folk arts and crafts at local Santhas.",
    description: "Wanaparthy’s weekly markets (santha) often feature handmade jewelry, pottery, wood carvings, and woven fabrics made by local artisans. These markets are great places to see and buy folk arts and crafts directly from the craftsmen and interact with them about their work.",
    location: "Wanaparthy Weekly Markets",
    bestTime: "Weekly Market Days",
    stories: [
      "A vibrant display of rural Telangana's artistic soul.",
      "Supports local artisans and keeps traditional crafts alive."
    ]
  },
  {
    id: 73,
    name: "Kakaku The Guest House",
    category: "Hotels",
    district: "Adilabad",
    image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/23/3b/b5/23/kakaku-the-guest-house.jpg?w=500&h=400&s=1",
    shortDescription: "Excellent amenities in a cozy setting.",
    description: "Rated 8.7/10, Kakaku The Guest House is a top choice for travelers in Adilabad. It is known for its neat and clean rooms, beautiful interiors, and excellent in-house kitchen facilities.\n\nVisitor Information:\n- Price Range: ₹2000 - ₹3500\n- Highlights: Modern amenities, helpful staff.",
    location: "Adilabad Town",
    bestTime: "All year round",
    stories: [
      "Praised by travelers for its surprising attention to detail."
    ]
  },
  {
    id: 74,
    name: "Hotel Sai Panchvati",
    category: "Hotels",
    district: "Adilabad",
    image: "https://cdn1.goibibo.com/voy_ing/t_g/3200d80403a311e99f790242ac110002.jpg",
    shortDescription: "Popular budget-friendly hotel.",
    description: "Hotel Sai Panchvati offers comfortable accommodation at budget-friendly rates. It is a preferred choice for business travelers and families looking for a convenient stay in the city.\n\nVisitor Information:\n- Price Range: ₹800 - ₹1500\n- Amenities: Parking, Room Service.",
    location: "Adilabad City Center",
    bestTime: "All year round",
    stories: [
      "Reliable service for budget travelers."
    ]
  },
  {
    id: 75,
    name: "Haritha Hotel Adilabad",
    category: "Hotels",
    district: "Adilabad",
    image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/11/fc/7d/ab/haritha-hotel-kadam.jpg?w=900&h=-1&s=1",
    shortDescription: "Reliable government tourism hotel.",
    description: "Operated by Telangana Tourism, Haritha Hotel provides standard AC and Non-AC rooms with a restaurant. It is located conveniently for tourists visiting nearby waterfalls and sanctuaries.\n\nVisitor Information:\n- Price Range: ₹1000 - ₹2000\n- Facilities: Restaurant, Spacious Parking.",
    location: "Adilabad",
    bestTime: "All year round",
    stories: [
      "A hub for tourists heading to Kuntala and Pochera waterfalls."
    ]
  },
  {
    id: 76,
    name: "Sterling Nature Trails Tipeshwar",
    category: "Hotels",
    district: "Adilabad",
    image: "https://tse3.mm.bing.net/th/id/OIP.35dr2c7tLnNEVyzwUARMLwHaCU?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Luxury nature resort near the Tiger Reserve.",
    description: "For those seeking luxury amidst nature, Sterling Tipeshwar offers a premium experience near the wildlife sanctuary. It features top-class amenities, a swimming pool, and guided nature activities.\n\nVisitor Information:\n- Price Range: ₹5000+\n- Best for: Wildlife enthusiasts and luxury seekers.",
    location: "Near Tipeshwar Wildlife Sanctuary",
    bestTime: "October - June",
    stories: [
      "The perfect gateway to spotting tigers in the nearby reserve."
    ]
  },
  {
    id: 77,
    name: "Kuntala Waterfalls",
    category: "Parks",
    district: "Adilabad",
    image: "https://tse2.mm.bing.net/th/id/OIP.JHa4x9qku8io7RmgRpj8WwHaE7?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "The highest waterfall in Telangana.",
    description: "Plunging from a height of 147 feet, Kuntala Waterfalls is a spectacular sight nestled in dense forests. It is a popular spot for trekking and enjoying the raw beauty of nature, especially during the monsoon.\n\nVisitor Information:\n- Height: 147 feet\n- Activity: Trekking down 400+ steps to the base.",
    location: "Neredigonda Mandal, Adilabad",
    bestTime: "July - December (Monsoon & Winter)",
    stories: [
      "Named after Shakuntala, the beloved wife of King Dushyanta.",
      "Local legends say Shakuntala used to bathe in these waters."
    ]
  },
  {
    id: 78,
    name: "Pochera Waterfalls",
    category: "Parks",
    district: "Adilabad",
    image: "https://3.bp.blogspot.com/-L0fSBnbaFmg/WDOJf-cIiYI/AAAAAAAACOo/4M4v7RlaK44mfzPTHZGob4BLGA7Zx1GhQCLcB/s1600/pochera-waterfalls.jpg",
    shortDescription: "A wide and deep waterfall with scenic beauty.",
    description: "Located near Kuntala, Pochera Waterfalls is known for its wide drop into a deep, granite-lined pool. The surroundings are lush and serene, making it a perfect picnic spot.\n\nVisitor Information:\n- Highlights: The roaring sound of water crashing on granite rocks.\n- Caution: Swimming is dangerous due to depth.",
    location: "Near Boath, Adilabad",
    bestTime: "July - December",
    stories: [
      "The deepest of all waterfalls in Telangana.",
      "Surrounded by a dense forest rich in flora."
    ]
  },
  {
    id: 79,
    name: "Kawal Wildlife Sanctuary",
    category: "Parks",
    district: "Adilabad",
    image: "https://tse3.mm.bing.net/th/id/OIP.khgwqPNmRZFP6wzo5w5GbgHaEH?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "A major Tiger Reserve in Telangana.",
    description: "Spanning over 893 sq km, Kawal Wildlife Sanctuary is a haven for wildlife enthusiasts. It is home to tigers, leopards, spotted deer, and diverse bird species. The sanctuary offers jeep safaris for a thrilling experience.\n\nVisitor Information:\n- Activities: Jeep Safari, Bird Watching.\n- Fauna: Tigers, Leopards, Sambar, Nilgai.",
    location: "Jannaram, Adilabad",
    bestTime: "October - May",
    stories: [
      "Recently declared as a Tiger Reserve to protect the big cat population."
    ]
  },
  {
    id: 80,
    name: "Mavala Haritha Vanam",
    category: "Parks",
    district: "Adilabad",
    image: "https://tse3.mm.bing.net/th/id/OIP.BHl6_9-4ivuuE-Yga2p6ZQAAAA?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "An adventure and ecological park near the town.",
    description: "Located just 6 km from Adilabad town, this park offers a blend of nature and adventure. It features safari zones, adventure activities like zip-lining, and peaceful walking tracks.\n\nVisitor Information:\n- Activities: Adventure sports, Safari.\n- Best for: Family outings and weekend recreations.",
    location: "Mavala, Adilabad",
    bestTime: "All year round",
    stories: [
      "A model for urban ecological conservation."
    ]
  },
  {
    id: 81,
    name: "Nagoba Jatara",
    category: "Seasonal Festivals",
    district: "Adilabad",
    image: "https://tse4.mm.bing.net/th/id/OIP.fphpwKSdUey1QIm_UgZ0-wHaGH?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "The second largest tribal festival in India.",
    description: "Celebrated by the Mesaram clan of the Gond tribes, Nagoba Jatara is a 10-day festival held at Keslapur. It involves the worship of the snake god Nagoba and includes rituals like the 'Bheting', where new daughters-in-law are introduced to the clan god.\n\nHighlights:\n- Maha Puja to Nagoba.\n- Tribal Durbar to address grievances.",
    location: "Keslapur Village, Adilabad",
    bestTime: "January - February (Pushya Masam)",
    stories: [
      "Pilgrims fetch holy water from the Godavari river in pots for the rituals.",
      "A unique blend of devotion and tribal governance."
    ]
  },
  {
    id: 82,
    name: "Dandari-Gussadi Festival",
    category: "Seasonal Festivals",
    district: "Adilabad",
    image: "https://tse4.mm.bing.net/th/id/OIP.K0z3axWebRrb22X5PWn1SQHaEM?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "A vibrant tribal dance festival during Diwali.",
    description: "The Dandari-Gussadi festival is a cultural extravaganza of the Raj Gonds. Troupes of dancers, dressed in unique costumes with peacock feather hats (Gussadi), visit villages performing traditional dances. It celebrates the harvest and tribal unity.\n\nHighlights:\n- Gussadi Dance with rhythmic drum beats.\n- Traditional Dandari troupes visiting households.",
    location: "Tribal Villages of Adilabad",
    bestTime: "October - November (Diwali Season)",
    stories: [
      "Gusadi is considered a form of the creator God.",
      "The dance is a way of seeking blessings for the community."
    ]
  },
  {
    id: 83,
    name: "Dokra Metal Crafts",
    category: "Local Experiences / Crafts",
    district: "Adilabad",
    image: "https://tse4.mm.bing.net/th/id/OIP.4tS5RaQfiqeqmjee9d0VqgHaDt?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Ancient lost-wax metal casting art.",
    description: "Practiced by the Ojha community of Adilabad, Dokra is a 4,000-year-old bell metal craft. Artisans use the 'lost-wax' casting technique to create intricate figurines of tribal gods, animals, and jewelry. No two pieces are identical.\n\nExperience:\n- Visit artisan villages like Ushegaon to see the process.\n- Buy authentic GI-tagged Dokra artifacts.",
    location: "Jainoor / Ushegaon, Adilabad",
    bestTime: "All year round",
    stories: [
      "One of the oldest metal casting techniques in human history.",
      "Awarded the Geographical Indication (GI) tag for its uniqueness."
    ]
  },
  {
    id: 84,
    name: "Sri Sita Ramachandraswamy Temple",
    category: "Temples",
    district: "Bhadradri Kothagudem",
    image: "https://i.ytimg.com/vi/lY08Hy78-PU/maxresdefault.jpg",
    shortDescription: "The 'Ayodhya of the South' on Godavari banks.",
    description: "Bhadrachalam Temple is one of the most significant Divya Kshetras of Lord Rama in India. Built by Kancharla Gopanna (Bhakta Ramadasu) in the 17th century, it stands majestically on the banks of the River Godavari. The temple is famous for its grand celebration of Sri Rama Navami and the Vaikunta Ekadasi.",
    location: "Bhadrachalam",
    bestTime: "October - April (Especially Sri Rama Navami)",
    stories: [
      "Built by Bhakta Ramadasu using funds from the royal treasury, leading to his imprisonment.",
      "Lord Rama is said to have appeared to Ramadasu in this holy place."
    ]
  },
  {
    id: 85,
    name: "Parnashala",
    category: "Temples",
    district: "Bhadradri Kothagudem",
    image: "https://1.bp.blogspot.com/-WUAyMO8BHNY/WHEvbm5qMsI/AAAAAAAACio/X6BksYxuUkQjBjyRgbuHwoEjYlnusL5EACLcB/s1600/parnasala.jpg",
    shortDescription: "The hermitage where Lord Rama lived in exile.",
    description: "Located 32 km from Bhadrachalam, Parnashala is a significant historic site where Lord Rama, Sita, and Lakshmana are believed to have built their hermitage during their 14-year exile. Visitors can see traces of their stay, such as 'Seethamma Vagu' and footprints.",
    location: "Parnashala Village",
    bestTime: "All year round",
    stories: [
      "The place where the demon king Ravana abducted Goddess Sita.",
      "Shows the footprint of Lord Rama and marks of his arrows on stones."
    ]
  },
  {
    id: 86,
    name: "Jatayu Paaka (Yetapaka)",
    category: "Temples",
    district: "Bhadradri Kothagudem",
    image: "https://hblimg.mmtcdn.com/content/hubble/img/ttd_images/mmt/activities/m_Bhadrachalam_Jattayu_pakka_1_l_587_783.jpg",
    shortDescription: "The mythological site of the bird King Jatayu.",
    description: "According to legend, this is where the giant bird Jatayu tried to rescue Sita from Ravana. The rock formation resembles a bird's wing, and it is a site of great mythological importance near Bhadrachalam.",
    location: "Yetapaka, near Bhadrachalam",
    bestTime: "All year round",
    stories: [
      "Jatayu fought valiantly here against Ravana to save Sita."
    ]
  },
  {
    id: 87,
    name: "St. Francis Xavier Church",
    category: "Churches",
    district: "Bhadradri Kothagudem",
    image: "https://tse2.mm.bing.net/th/id/OIP.bW8hxLiYvw58E0d87VaXpAHaIr?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "A historic center of worship in the coal belt.",
    description: "St. Francis Xavier Church in Kothagudem is a prominent Catholic church known for its peaceful ambiance and active community services. It serves as a spiritual hub for the Christian community in the industrial town.",
    location: "Babu Camp, Kothagudem",
    bestTime: "All year round (Christmas)",
    stories: []
  },
  {
    id: 88,
    name: "CSI Church Kothagudem",
    category: "Churches",
    district: "Bhadradri Kothagudem",
    image: "https://i.ytimg.com/vi/gyOe44UcQew/hqdefault.jpg",
    shortDescription: "A major Protestant church with colonial roots.",
    description: "The CSI (Church of South India) Church in Kothagudem is one of the oldest and largest churches in the district. It features a blend of traditional and modern architecture and hosts vibrant Sunday services.",
    location: "Kothagudem Town",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 89,
    name: "Masjid-e-Umar Farooq",
    category: "Mosques",
    district: "Bhadradri Kothagudem",
    image: "https://i.ytimg.com/vi/VU-UT7yFsdM/maxresdefault.jpg",
    shortDescription: "A central mosque for the local community.",
    description: "Masjid-e-Umar Farooq is a key place of worship for Muslims in the Kothagudem area. It is known for its spacious prayer hall and community welfare activities.",
    location: "Kothagudem",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 90,
    name: "Masjid-e-Aqsa",
    category: "Mosques",
    district: "Bhadradri Kothagudem",
    image: "https://masjidalaqsa.b-cdn.net/assets/images/al-aqsa-gallery/masjid%20al%20aqsa%20evening%20view.jpg",
    shortDescription: "A beautiful mosque in the heart of the district.",
    description: "Known for its architectural beauty and peaceful environment, Masjid-e-Aqsa attracts worshippers from across the town. It plays a vital role in the religious life of Bhadrachalam's Muslim community.",
    location: "Bhadrachalam",
    bestTime: "All year round",
    stories: []
  },


  {
    id: 92,
    name: "Bamboo Chicken (Bongu Chicken)",
    category: "Local Food",
    district: "Bhadradri Kothagudem",
    image: "https://i.ytimg.com/vi/Mqe55VyAlkc/maxresdefault.jpg",
    shortDescription: "A smoky, oil-free tribal delicacy.",
    description: "A specialty of the agency areas like Bhadrachalam and Maredumilli. Marinated chicken is stuffed into raw bamboo shoots and cooked over charcoal fire. The bamboo juices infuse a unique woody flavor into the meat.",
    location: "Roadside stalls near Bhadrachalam/Kinnerasani",
    bestTime: "All year round",
    stories: [
      "Originally a hunting meal prepared by local Koya tribes in the forest."
    ]
  },
  {
    id: 93,
    name: "Godavari Fish Pulusu",
    category: "Local Food",
    district: "Bhadradri Kothagudem",
    image: "https://images.boldsky.com/te/img/2024/12/fishpulusu-1735216208.jpg",
    shortDescription: "Spicy and tangy river fish curry.",
    description: "Made with fresh fish from the Godavari river, this curry is famous for its fiery spice levels and tanginess from tamarind and mango. It is a staple Sunday lunch for locals.",
    location: "Local Restaurants in Bhadrachalam",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 94,
    name: "Haritha Hotel Bhadrachalam",
    category: "Hotels",
    district: "Bhadradri Kothagudem",
    image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/16/47/bc/66/haritha-hotel-bhadrachalam.jpg?w=700&h=-1&s=1",
    shortDescription: "Convenient stay for temple pilgrims.",
    description: "Located very close to the temple, Haritha Hotel offers AC and Non-AC rooms catered specifically to pilgrims. It provides clean amenities and a vegetarian restaurant.",
    location: "Near Temple, Bhadrachalam",
    bestTime: "All year round",
    stories: [
      "Booked months in advance during Sri Rama Navami."
    ]
  },
  {
    id: 95,
    name: "Sri Kakateeya Grand Residency",
    category: "Hotels",
    district: "Bhadradri Kothagudem",
    image: "https://cf.bstatic.com/xdata/images/hotel/max1024x768/586098764.jpg?k=d471feb2b518becefffc7dfdc5441d3e2dec71b2aebe8f48ceb224548f4d1417&o=&hp=1",
    shortDescription: "Premium comfort in the Coal Town.",
    description: "A top-rated hotel in Kothagudem offering luxury rooms, banquet halls, and fine dining. It is the preferred choice for business travelers visiting the mining belt and tourists alike.\n\nVisitor Information:\n- Rating: 4.0/5\n- Amenities: Wi-Fi, Restaurant, Bar.",
    location: "Kothagudem",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 96,
    name: "Kinnerasani Wildlife Sanctuary",
    category: "Parks",
    district: "Bhadradri Kothagudem",
    image: "https://travellerkaka.com/wp-content/uploads/2024/08/Untitled-design-12-2.png",
    shortDescription: "A biodiversity hotspot with a scenic dam.",
    description: "Spanning over 635 sq km, this sanctuary is home to tigers, panthers, hyenas, and sloth bears. The Kinnerasani Dam located within the sanctuary adds to the scenic beauty, with the river meandering through the forest.\n\nVisitor Information:\n- Activities: Jeep Safari, Boating in the reservoir.\n- Highlights: Deer Park and Eco-cottages.",
    location: "Near Palvancha",
    bestTime: "October - June",
    stories: [
      "The river Kinnerasani is personified as a lover pining for her beloved Godavari."
    ]
  },
  {
    id: 97,
    name: "Kinnerasani Deer Park",
    category: "Parks",
    district: "Bhadradri Kothagudem",
    image: "https://www.joonsquare.com/usermanage/image/business/kinnerasani-wildlife-sanctuary-bhadradri-kothagudem-35184/kinnerasani-wildlife-sanctuary-bhadradri-kothagudem-nerasani-wildlife-sanctuary3.jpg",
    shortDescription: "A dedicated park for spotted deer.",
    description: "Located within the sanctuary complex, this park is a safe haven for a large population of spotted deer. It is a great spot for children and families to see these gentle creatures up close in a natural setting.",
    location: "Kinnerasani Dam Area",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 98,
    name: "Central Park Kothagudem",
    category: "Parks",
    district: "Bhadradri Kothagudem",
    image: "https://i.ytimg.com/vi/r0CevWUPUAM/maxresdefault.jpg?sqp=-oaymwEmCIAKENAF8quKqQMa8AEB-AH-CYAC0AWKAgwIABABGHIgVSggMA8=&rs=AOn4CLBmctRFjyAuSg-TG8MhXb4pPLfJBQ",
    shortDescription: "The green lung of the mining town.",
    description: "Central Park is a well-maintained urban park in Kothagudem. It features lush lawns, walking tracks, musical fountains, and play areas, serving as the primary recreational spot for the town's residents.",
    location: "Kothagudem",
    bestTime: "Evenings",
    stories: []
  },
  {
    id: 99,
    name: "Sri Rama Navami",
    category: "Seasonal Festivals",
    district: "Bhadradri Kothagudem",
    image: "https://media.telanganatoday.com/wp-content/uploads/2023/03/Rama-Navami-1.jpg",
    shortDescription: "The celestial wedding of Lord Rama and Sita.",
    description: "Bhadrachalam hosts the grandest Sri Rama Navami celebrations in the state. The 'Sitarama Kalyanam' (wedding ceremony) is performed with great pomp, attended by lakhs of devotees and dignitaries. Pearls are offered to the deities by the state government.",
    location: "Bhadrachalam Temple",
    bestTime: "March/April",
    stories: [
      "A tradition started by the Qutub Shahi rulers of sending pearls continues today by the Telangana government."
    ]
  },
  {
    id: 100,
    name: "Mukkoti Vaikunta Ekadasi",
    category: "Seasonal Festivals",
    district: "Bhadradri Kothagudem",
    image: "https://www.oneindia.com/img/1200x60x675/2022/01/ekadashi-1642012003.jpg",
    shortDescription: "The day the northern gates of heaven open.",
    description: "Celebrated in December/January, this festival attracts massive crowds. The north gate (Vaikunta Dwaram) of the temple is opened for devotees, believed to grant salvation. The 'Teppotsavam' (boat festival) on the Godavari is a visual spectacle.",
    location: "Bhadrachalam Temple",
    bestTime: "December/January",
    stories: []
  },
  {
    id: 101,
    name: "Koya Bamboo Crafts",
    category: "Local Experiences / Crafts",
    district: "Bhadradri Kothagudem",
    image: "https://images.tv9telugu.com/wp-content/uploads/2023/07/bamboo-crafts-1.jpg",
    shortDescription: "Intricate weaving from the forests.",
    description: "The Koya tribes of Bhadradri are masters of bamboo craft. They create sturdy and beautiful baskets, mats, and decorative items. These eco-friendly crafts reflect their sustainable lifestyle and deep connection to the forest.",
    location: "Tribal Haats / Kinnerasani",
    bestTime: "All year round",
    stories: [
      "A skill passed down through generations of forest dwellers."
    ]
  },
  {
    id: 102,
    name: "Koya Tribal Paintings",
    category: "Local Experiences / Crafts",
    district: "Bhadradri Kothagudem",
    image: "https://tse4.mm.bing.net/th/id/OIP.3FHSWPZN5iOiueTFZGnybAHaEK?rs=1&pid=ImgDetMain&o=7&rm=3",
    shortDescription: "Vibrant art depicting tribal life and nature.",
    description: "Similar to Warli art but distinct in style, Koya paintings depict scenes of hunting, farming, and festivals like Sammakka Saralamma. Using natural colors, these paintings are a visual documentation of their rich history and culture.",
    location: "Bhadrachalam / Tribal Museums",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 103,
    name: "Bhadrakali Temple",
    category: "Temples",
    district: "Hanamkonda",
    image: "https://warangaltourism.in/images/places-to-visit-warangal/headers/bhadrakali-temple-warangal-tourism-entry-fee-timings-holidays-reviews-header.jpg",
    shortDescription: "Ancient Kakatiya temple dedicated to Goddess Bhadrakali.",
    description: "Built in 625 AD by the Chalukyas and later patronsied by the Kakatiyas, this temple sits on a hill near the Bhadrakali Lake. The main idol of the Goddess is fierce yet majestic, with eight arms holding weapons.",
    location: "Near Bhadrakali Lake, Hanamkonda",
    bestTime: "September - October (Bathukamma/Navaratri)",
    stories: [
      "The Kakatiya kings worshipped Goddess Bhadrakali as their family deity before wars.",
      "The Koh-i-Noor diamond is believed to have been installed in the left eye of the goddess by the Kakatiya rulers."
    ]
  },
  {
    id: 104,
    name: "Padmakshi Temple",
    category: "Temples",
    district: "Hanamkonda",
    image: "https://temple.yatradham.org/public/Product/temple/temple_xei3qY6t_202307161555060.webp",
    shortDescription: "A Jain-Hindu cave temple on a hillock.",
    description: "Dating back to the 12th century, this temple is dedicated to Goddess Padmakshi. It features a stunning Annakonda Pillar at the entrance and carvings of Jain Tirthankaras, reflecting its Jain origins before becoming a Hindu shrine.",
    location: "Padmakshi Hill, Hanamkonda",
    bestTime: "All year round",
    stories: [
      "Originally a Jain Basadi (shrine) before converting to a Hindu temple.",
      "Women gather here in thousands to celebrate the Bathukamma festival at the adjoining pond."
    ]
  },
  {
    id: 105,
    name: "Thousand Pillar Temple",
    category: "Temples",
    district: "Hanamkonda",
    image: "https://www.travelure.in/wp-content/uploads/2022/07/1000-Pillars-Temple-Header-1.jpg",
    shortDescription: "A masterpiece of Kakatiya architecture.",
    description: "Built in 1163 AD by Rudra Deva, this temple (Veyisthambala Gudi) is a star-shaped triple shrine (Trikutalayam) dedicated to Shiva, Vishnu, and Surya. It is famous for its intricate carvings and the massive Nandi bull carved from a single black stone.",
    location: "Hanamkonda Town",
    bestTime: "All year round",
    stories: [
      "The pillars are so polished they shine like mirrors.",
      "It was desecrated by the Tughlaq dynasty but remains a standing wonder."
    ]
  },
  {
    id: 106,
    name: "Siddeshwara Temple",
    category: "Temples",
    district: "Hanamkonda",
    image: "https://pbs.twimg.com/media/EDPAmefVAAIa-Z0.jpg",
    shortDescription: "historic Shiva temple from the 3rd century.",
    description: "One of the oldest temples in the region, Siddeshwara Temple dates back to the 3rd century AD. Its Chalukyan style pillars and serene atmosphere make it a must-visit for history buffs and devotees.",
    location: "Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 107,
    name: "CSI Cathedral Hanamkonda",
    category: "Churches",
    district: "Hanamkonda",
    image: "https://i.ytimg.com/vi/FJLZ7K95rbQ/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLDagMwPlVQL3NNhZygD65e7QNROBw",
    shortDescription: "A prominent Protestant church in the city.",
    description: "The CSI Cathedral in Hanamkonda is a major center for the Christian community. Known for its Gothic-inspired architecture and vibrant Sunday services, it has a rich history serving the locals for decades.",
    location: "Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 108,
    name: "Roman Catholic Diocese of Warangal",
    category: "Churches",
    district: "Hanamkonda",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCsJ-qadylq0ZvP_dPcSTPO6VzcHptq044xg&s",
    shortDescription: "The seat of the Bishop and a grand cathedral.",
    description: "Fatima Cathedral, part of the Roman Catholic Diocese, is a stunning architectural marvel in Hanamkonda. It is the central place of worship for Catholics in the region and hosts grand celebrations during Christmas and Easter.",
    location: "Fatima Nagar, Hanamkonda",
    bestTime: "December",
    stories: []
  },
  {
    id: 109,
    name: "Centenary Baptist Church",
    category: "Churches",
    district: "Hanamkonda",
    image: "https://content.jdmagicbox.com/v2/comp/mumbai/h5/9999px870.x870.121221182251.i4h5/catalogue/centenary-baptist-church-hanamkonda-warangal-churches-t15a2fj3tj.jpg",
    shortDescription: "A historic church with a large congregation.",
    description: "Established by American missionaries, the Centenary Baptist Church is a landmark in Hanamkonda. It is known for its community service aimed at education and health.",
    location: "Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 110,
    name: "Masjid-e-Fatima",
    category: "Mosques",
    district: "Hanamkonda",
    image: "https://content.jdmagicbox.com/v2/comp/warangal/a6/9999px870.x870.220416224315.q6a6/catalogue/masjid-e-fatima-hanamkonda-warangal-mosques-Tjhi3s0AnU.jpg",
    shortDescription: "A key spiritual center in Kazipet-Hanamkonda.",
    description: "Located near the NIT Warangal area, Masjid-e-Fatima is a beautiful mosque serving the student and local Muslim community. It is known for its peaceful ambiance and architectural elegance.",
    location: "Kazipet/Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 111,
    name: "Ekasilanagar Masjid",
    category: "Mosques",
    district: "Hanamkonda",
    image: "https://content.jdmagicbox.com/v2/comp/hyderabad/y8/040pxx40.xx40.200925155042.t1y8/catalogue/masjid-e-azeezullah-nagaram-hyderabad-mosques-8xyw4Y5E2Z.jpg",
    shortDescription: "A community mosque in the heart of the town.",
    description: "A prominent mosque in Hanamkonda, playing a vital role in daily prayers and community gatherings.",
    location: "Ekasilanagar, Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 112,
    name: "Jamia Masjid Hanamkonda",
    category: "Mosques",
    district: "Hanamkonda",
    image: "https://content.jdmagicbox.com/v2/comp/warangal/p6/9999px870.x870.180303184217.i2p6/catalogue/masjid-e-ali-hassan-ar-rasheed-waddepally-warangal-mosques-49ogc8a9tf.jpg",
    shortDescription: "One of the oldest mosques in the district.",
    description: "Jamia Masjid stands as a testament to the region's diverse history. It is a central hub for Friday prayers and religious festivals like Eid.",
    location: "Hanamkonda Chowrastha",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 113,
    name: "Green Park Biryani",
    category: "Local Food",
    district: "Hanamkonda",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVb1xpgTvlrmaGXfTtGL8EoYSu-Kxlxu2egg&s",
    shortDescription: "Legendary Biryani spot in the city.",
    description: "Green Park Restaurant is synonymous with Biryani in Hanamkonda. Their spicy, aromatic chicken and mutton biryanis attract food lovers from all over the district.",
    location: "Nakkalagutta, Hanamkonda",
    bestTime: "Lunch/Dinner",
    stories: []
  },
  {
    id: 114,
    name: "Mirchi Bajji at Excise Colony",
    category: "Local Food",
    district: "Hanamkonda",
    image: "https://media-assets.swiggy.com/swiggy/image/upload/f_auto,q_auto,fl_lossy/RX_THUMBNAIL/IMAGES/VENDOR/2024/12/28/ad4e33e1-ec84-4f14-b2a0-059a3634a699_1017762.jpg",
    shortDescription: "Famous street food snack.",
    description: "Seenu Mirchi Bandi in Excise Colony is legendary. The stuffed, deep-fried chili fritters served with onions and roasted peanuts are a spicy treat that defines Hanamkonda's street food scene.",
    location: "Excise Colony, Hanamkonda",
    bestTime: "Evenings",
    stories: [
      "Locals swear by the distinct masala stuffing used here."
    ]
  },
  {
    id: 115,
    name: "Sarva Pindi",
    category: "Local Food",
    district: "Hanamkonda",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwLI8qzXDcFoWaX8mcZuczvne7QK84IeEOJQ&s",
    shortDescription: "Traditional spicy pancake.",
    description: "A quintessential Telangana snack made of rice flour, chana dal, peanuts, and chili. It is flattened on a pan and cooked to a crisp. Available in most local messes and homes.",
    location: "Local eateries",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 116,
    name: "Hotel Ashoka",
    category: "Local Food",
    district: "Hanamkonda",
    image: "https://content.jdmagicbox.com/comp/warangal/q1/9999p8712.8712.090527150604.i2q1/catalogue/hotel-ashoka-hanamkonda-warangal-hotels-rs-1001-to-rs-2000--2emf4lm.jpg",
    shortDescription: "Classic Andhra and Telangana meals.",
    description: "One of the oldest and most respected restaurants. Their full meals (thali) with an array of curries, dals, and chutneys offer a wholesome traditional dining experience.",
    location: "Hanamkonda Main Road",
    bestTime: "Lunch",
    stories: []
  },
  {
    id: 117,
    name: "Hotel Suprabha",
    category: "Hotels",
    district: "Hanamkonda",
    image: "https://content3.jdmagicbox.com/comp/warangal/x4/9999px870.x870.190516233729.k6x4/catalogue/suprabha-hotel-restaurant-hanamkonda-warangal-home-delivery-restaurants-swgwjmf5hg.jpg",
    shortDescription: "Luxury stay with excellent dining.",
    description: "A 3-star hotel offering premium amenities, diverse dining options, and banquet halls. It is a favorite among business travelers and families visiting the city.\n\nVisitor Information:\n- Rating: 4/5\n- Amenities: Wi-Fi, Multi-cuisine restaurant.",
    location: "Nakkalagutta, Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 118,
    name: "Haritha Kakatiya Hotel",
    category: "Hotels",
    district: "Hanamkonda",
    image: "https://tourism.telangana.gov.in/storage/app/media/kakatiya_hotel.jpeg",
    shortDescription: "Government-run premium hotel.",
    description: "Operated by Telangana Tourism, this hotel offers spacious rooms, a bar, and a restaurant. Its location is ideal for tourists as it's close to major attractions like the Thousand Pillar Temple.\n\nVisitor Information:\n- Price: ₹2000 - ₹4000\n- Highlights: Spacious property, Greenery.",
    location: "Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 119,
    name: "Vishnu Grand (Townhouse Oak)",
    category: "Hotels",
    district: "Hanamkonda",
    image: "https://cf.bstatic.com/xdata/images/hotel/max1024x768/768774924.jpg?k=b1bda96e380132bfef5acdb7bb9276698d4f30624ed90febfea85ad601166882&o=",
    shortDescription: "Modern amenities in the city center.",
    description: "Known for its modern interiors and prompt service, Vishnu Grand is a top choice for a comfortable stay. It features well-equipped rooms and an in-house restaurant.\n\nVisitor Information:\n- Rating: 4.2/5\n- Best for: Corporate and Leisure.",
    location: "Public Garden Road, Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 120,
    name: "Hotel Thousand Pillars",
    category: "Hotels",
    district: "Hanamkonda",
    image: "https://media-cdn.tripadvisor.com/media/photo-s/2b/a2/a5/14/caption.jpg",
    shortDescription: "Budget-friendly stay near the historic temple.",
    description: "Located within walking distance of the famous Thousand Pillar Temple, this hotel offers decent accommodation for budget travelers and pilgrims.\n\nVisitor Information:\n- Price: Budget\n- Proximity: Very close to temple.",
    location: "Hanamkonda",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 121,
    name: "Kakatiya Musical Garden",
    category: "Parks",
    district: "Hanamkonda",
    image: "https://static.toiimg.com/photo/msid-59593238,width-96,height-65.cms",
    shortDescription: "Evening entertainment with musical fountains.",
    description: "A beautifully landscaped garden famous for its musical fountain show that synchronizes water, light, and music. It also has a rock garden and a duck pond, making it a perfect evening outing spot.\n\nVisitor Information:\n- Timings: 4 PM - 8 PM\n- Highlight: 7 PM Musical Fountain Show.",
    location: "Near Bhadrakali Temple",
    bestTime: "Evenings",
    stories: []
  },
  {
    id: 122,
    name: "Kakatiya Rock Garden",
    category: "Parks",
    district: "Hanamkonda",
    image: "https://warangaltourism.in/images//tourist-places/kakatiya-rock-garden-warangal/kakatiya-rock-garden-warangal-tourism-opening-time-closing.jpg",
    shortDescription: "Sculptures of wild animals in a rocky terrain.",
    description: "This park features life-size sculptures of animals like lions, deer, and giraffes set amidst natural rock formations. It is a favorite among children and offers a unique walking experience.",
    location: "Hanamkonda",
    bestTime: "Mornings/Evenings",
    stories: []
  },
  {
    id: 123,
    name: "Vana Vigyan Kendra (Zoo Park)",
    category: "Parks",
    district: "Hanamkonda",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3pO4xZPrK2BJJQL43yQu2OiZAAGcUKiEWqQ&s",
    shortDescription: "Mini zoo and education center.",
    description: "Also known as the Warangal Zoo, this park houses various species of animals, birds, and reptiles. It serves as an educational center for environmental conservation and provides a green escape in the city.",
    location: "Hunter Road, Hanamkonda",
    bestTime: "Winter",
    stories: []
  },
  {
    id: 124,
    name: "Waddepally Lake Park",
    category: "Parks",
    district: "Hanamkonda",
    image: "https://i.pinimg.com/736x/bb/1a/f8/bb1af8c3529a5f5e656eccac60deafbd.jpg",
    shortDescription: "Scenic lakefront promenade.",
    description: "The park along the bund of Waddepally Lake is popular for morning walkers and nature lovers. It offers serene views of the water and is a great spot for bird watching during migration season.",
    location: "Waddepally, Hanamkonda",
    bestTime: "Mornings/Evenings",
    stories: []
  },
  {
    id: 125,
    name: "Bathukamma",
    category: "Seasonal Festivals",
    district: "Hanamkonda",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSS9TyYjXrgSZxNJg2HG0YX56uIioTtttNzJQ&s",
    shortDescription: "The grand floral festival of Telangana.",
    description: "Hanamkonda comes alive during Bathukamma, with the Bhadrakali Lake and Padmakshi Temple being central hubs. Women create conical flower stacks and dance around them, celebrating nature and the goddess.",
    location: "Bhadrakali Lake / Padmakshi Temple",
    bestTime: "September/October",
    stories: [
      "The 'Saddula Bathukamma' finale at Bhadrakali bund is a spectacular sight."
    ]
  },
  {
    id: 126,
    name: "Shakambari Utsavam",
    category: "Seasonal Festivals",
    district: "Hanamkonda",
    image: "https://prabhanews.com/wp-content/uploads/2025/07/n6717708291752037131359ba82851bb1ab926676ba39600ba19cbaeffd9071469b0bc9810f1731a205778d-768x432.jpg",
    shortDescription: "Goddess adorned with vegetables.",
    description: "Celebrated at the Bhadrakali Temple during Ashada Masam (July), the deity is decorated entirely with vegetables and fruits to pray for good rains and harvest. It is a unique and colorful festival.",
    location: "Bhadrakali Temple",
    bestTime: "July",
    stories: []
  },
  {
    id: 127,
    name: "Warangal Durries",
    category: "Local Experiences / Crafts",
    district: "Hanamkonda",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSXJHvDB2pCSxWUio9gusxqeKUdb65yP4cZEA&s",
    shortDescription: "GI-tagged handwoven rugs.",
    description: "Hanamkonda and Warangal are famous for their cotton durries (rugs). These hand-woven carpets are known for their durability, geometric patterns, and vibrant colors. You can visit Kothawada to see weavers in action.",
    location: "Kothawada, Warangal/Hanamkonda",
    bestTime: "All year round",
    stories: [
      "Exported globally, these rugs put the region on the world craft map."
    ]
  },
  {
    id: 128,
    name: "Pembarthy Metal Crafts",
    category: "Local Experiences / Crafts",
    district: "Hanamkonda",
    image: "https://uat-tshandloom.aptonline.in:8443/GolkoCrafts/images/blog/21-pembarthi.jpg",
    shortDescription: "Exquisite brass and copper ware.",
    description: "Though traditionally from Pembarthy village nearby, Hanamkonda is a major market for these metal crafts. Artisans create stunning idols, wall hangings, and vessels with intricate sheet metal work.",
    location: "Shop at Lepakshi or local handicraft stores",
    bestTime: "All year round",
    stories: [
      "A craft patronized by the Kakatiya rulers for temple decorations."
    ]
  },
  {
    id: 129,
    name: "Scroll Paintings (Cheriyal)",
    category: "Local Experiences / Crafts",
    district: "Hanamkonda",
    image: "https://uat-tshandloom.aptonline.in:8443/GolkoCrafts/images/blog/03-10-rural.jpg",
    shortDescription: "Storytelling through canvas.",
    description: "Cheriyal Scroll Painting is a unique art form of the region used by storytellers. These vibrant paintings depicting mythology and rural life are distinctive to the Hanamkonda-Warangal cultural belt.",
    location: "Art galleries / Handicraft emporiums",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 130,
    name: "Sri Lakshmi Narasimha Swamy Temple, Dharmapuri",
    category: "Temples",
    district: "Jagtial",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqqW4s2ZMtpH95a8_voH_79waX_P_UC9_x7Q&s",
    shortDescription: "Ancient holy temple on the banks of Godavari.",
    description: "Dharmapuri is one of the most important religious sites in Telangana. The temple is dedicated to Lord Lakshmi Narasimha Swamy, an incarnation of Lord Vishnu. It is unique for featuring two forms of the Lord - Yoga Narasimha and Ugra Narasimha. The temple architecture and its location on the sacred Godavari river make it a highly revered pilgrimage spot.",
    location: "Dharmapuri, Jagtial District",
    bestTime: "October - March",
    stories: [
      "Dharmapuri is known as the 'Teertha Raja' meaning King of Pilgrimage sites.",
      "The town is believed to be the home of the sacred souls of ancestors."
    ]
  },
  {
    id: 131,
    name: "Kondagattu Anjaneya Swamy Temple",
    category: "Temples",
    district: "Jagtial",
    image: "https://www.trawell.in/admin/images/upload/144418116Karimnagar_Kondagattu_Main.jpg",
    shortDescription: "Famous Hanuman temple nestled in scenic hills.",
    description: "Kondagattu Anjaneya Swamy Temple is one of the most famous shrines in Telangana. Located on a hillock, the temple is dedicated to Lord Hanuman. It is surrounded by lush green valleys and natural springs. Devotees believe that a 41-day 'Hanuman Deeksha' here can cure any ailment. The temple is also known for its beautiful architecture and spiritual energy.",
    location: "Kondagattu, Jagtial District",
    bestTime: "All year round (Special on Hanuman Jayanti)",
    stories: [
      "According to local folklore, the temple was built by a cowherd 300 years ago.",
      "The idol is unique as it represents both Anjaneya Swamy and Narasimha Swamy."
    ]
  },
  {
    id: 132,
    name: "Sahasra Linga Temple, Polasa",
    category: "Temples",
    district: "Jagtial",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR00PrUC7NxgrJoDXWHhebUSCOb0K738b41dg&s",
    shortDescription: "Architectural marvel featuring 1000 Shiva Lingas.",
    description: "Located in Polasa village, this ancient temple is dedicated to Lord Shiva. The highlight of the temple is the Sahasra Linga (one thousand lingas) carved on a single large Shiva Linga. It reflects the exceptional craftsmanship of the Kakatiya period.",
    location: "Polasa, Jagtial District",
    bestTime: "October - February",
    stories: [
      "Believed to have been built by the local rulers under the Kakatiya influence."
    ]
  },
  {
    id: 133,
    name: "Sri Kodanda Rama Temple",
    category: "Temples",
    district: "Jagtial",
    image: "https://temple.yatradham.org/public/Product/temple/temple_C8vOg56R_202307161439150.webp",
    shortDescription: "Significant Rama temple in Dharoor Camp.",
    description: "A prominent place of worship in the Jagtial region, the Sri Kodanda Rama Temple is known for its peaceful environment and traditional rituals. It is a center for major festivals like Sri Rama Navami.",
    location: "Dharoor Camp, Jagtial",
    bestTime: "March - April (Sri Rama Navami)",
    stories: []
  },
  {
    id: 134,
    name: "Hebron Prayer House",
    category: "Churches",
    district: "Jagtial",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkjkuoTthZRQDcWdNXQKCYc8VB-zWFF_31oQ&s",
    shortDescription: "Vibrant prayer house in Govindpalli.",
    description: "A central place of meeting and worship for the Christian community in Jagtial. Known for its soul-stirring prayer sessions and community gathering during Christmas and New Year.",
    location: "Govindpalli, Jagtial",
    bestTime: "December",
    stories: []
  },
  {
    id: 135,
    name: "St. Paul's Church",
    category: "Churches",
    district: "Jagtial",
    image: "https://content.jdmagicbox.com/v2/comp/hyderabad/f4/040pxx40.xx40.180316123127.a4f4/catalogue/st-anthony-s-shrine-sitaphalmandi-hyderabad-churches-b7wnp4LyLI.jpg",
    shortDescription: "Historic church in the heart of Jagtial.",
    description: "St. Paul's Church is one of the older denominations in the district, serving a large congregation. It is known for its traditional liturgical services and educational contributions in the region.",
    location: "Jagtial Town",
    bestTime: "December",
    stories: []
  },
  {
    id: 136,
    name: "Jama Masjid Jagtial",
    category: "Mosques",
    district: "Jagtial",
    image: "https://content.jdmagicbox.com/comp/koratla/p4/9999px872.x872.220319220005.g2p4/catalogue/jam-e-masjid-koratla-koratla-mosques-1jwbjz9gpm.jpg",
    shortDescription: "Historic mosque near Jagtial Qila.",
    description: "Located near the historic Jagtial Fort (Qila), the Jama Masjid is the largest and most significant mosque in the town. It features a grand prayer hall and remains the focal point for Friday congregations and Eid festivals.",
    location: "Khila Gadda Road, Jagtial",
    bestTime: "All year round (Ramadan/Eid)",
    stories: [
      "The mosque shares a proximity to the ancient earth-and-stone fort of the Nizams."
    ]
  },
  {
    id: 137,
    name: "Masjid Mirza Ahmed Baig",
    category: "Mosques",
    district: "Jagtial",
    image: "https://content.jdmagicbox.com/v2/comp/jagtial/m8/9999p8724.8724.220130014245.b3m8/catalogue/fahraan-masjid-puranipet-jagtial-mosques-meUXLzcN49-250.jpg",
    shortDescription: "Beautifully designed local mosque.",
    description: "A prominent mosque known for its peaceful atmosphere and community focus. It serves the local residents for daily prayers and religious education.",
    location: "Jagtial Town",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 138,
    name: "Jowar Roti & Local Meals",
    category: "Local Food",
    district: "Jagtial",
    image: "https://images.hindustantimes.com/rf/image_size_630x354/HT/p2/2020/12/22/Pictures/4-langar-thali-bangla-sahib_306ff69a-447f-11eb-9d7d-764df83b7a87.jpg",
    shortDescription: "Authentic staple food of Jagtial.",
    description: "The traditional diet of Jagtial revolves around 'Sajja Rotte' (Pearl Millet Bread) and 'Jonna Rotte' (Sorghum Bread). These are usually served with spicy curries made from local vegetables, lentils, or Gongura chutney.",
    location: "Local Mess & Eateries, Jagtial",
    bestTime: "All year round",
    stories: [
      "A healthy, gluten-free traditional diet that has sustained local farmers for generations."
    ]
  },
  {
    id: 139,
    name: "Sarva Pindi",
    category: "Local Food",
    district: "Jagtial",
    image: "https://media.assettype.com/tnm%2Fimport%2Fsites%2Fdefault%2Ffiles%2Fimages%2FSarvapindi_1.jpg?w=640&auto=format%2Ccompress",
    shortDescription: "Spicy and crispy Telangana pancake.",
    description: "Jagtial is famous for its Sarva Pindi, a savory pancake made from rice flour, chana dal, peanuts, ginger, and garlic. It is cooked in a deep pan to achieve a crispy texture and is a favorite evening snack.",
    location: "Street Food Stalls, Jagtial Market",
    bestTime: "Evenings",
    stories: []
  },
  {
    id: 140,
    name: "Hotel PMR Grand",
    category: "Hotels",
    district: "Jagtial",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCH290alOLKKIBDF-t373D8l1RjQFuoYR-Hg&s",
    shortDescription: "Modern comfort and fine dining in Jagtial.",
    description: "PMR Grand is one of the premier hotels in Jagtial, offering well-furnished AC rooms and a popular multi-cuisine restaurant. It is ideal for business travelers and families seeking modern amenities.",
    location: "Main Road, Jagtial",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 141,
    name: "Haritha Hotel Kondagattu",
    category: "Hotels",
    district: "Jagtial",
    image: "https://i0.wp.com/hotels.xploreall.com/wp-content/uploads/2024/06/kondagattu.jpg",
    shortDescription: "Government-run tourism hotel near the temple.",
    description: "Operated by Telangana Tourism, this hotel provides a comfortable stay for pilgrims visiting the Kondagattu Anjaneya Swamy Temple. It offer scenic views of the surrounding hills and standard hospitality services.",
    location: "Kondagattu Hilltop",
    bestTime: "All year round",
    stories: []
  },
  {
    id: 142,
    name: "Jagtial Urban Forest Park",
    category: "Parks",
    district: "Jagtial",
    image: "https://www.deccanchronicle.com/h-upload/2025/01/01/1877826-images8.webp",
    shortDescription: "Lush green escape and adventure zone.",
    description: "Located in Ambaripet village, this park is part of the state government's initiative to create 'urban lungs'. It features walking tracks, cycling paths, children's play area, and an open-air gym amidst native forest trees.",
    location: "Ambaripet, Jagtial Rural",
    bestTime: "September - February",
    stories: [
      "Designed to provide a jungle-like experience to urban dwellers."
    ]
  },
  {
    id: 143,
    name: "Jagityal Municipal Park",
    category: "Parks",
    district: "Jagtial",
    image: "https://content.jdmagicbox.com/comp/jagtial/i1/9999px878.x878.180701025331.a1i1/catalogue/jagityal-municipal-park-jagtial-jagtial-65k5u2zatn.jpg",
    shortDescription: "Family recreation park in Puranipet.",
    description: "A well-maintained community park in the heart of the town, featuring manicured lawns, colorful flower beds, and seating areas. It is the go-to place for locals for morning walks and evening family outings.",
    location: "Puranipet, Jagtial",
    bestTime: "Evenings",
    stories: []
  },
  {
    id: 144,
    name: "Jagtial Mini Tank Bund",
    category: "Parks",
    district: "Jagtial",
    image: "https://content3.jdmagicbox.com/comp/jagtial/f6/9999p8724.8724.230331140508.v3f6/catalogue/jagtial-mini-tank-bund-islampura-jagtial-parks-5ccfqxypj2.jpg",
    shortDescription: "Scenic waterfront development.",
    description: "Modeled after the Hyderabad Tank Bund, this local project provides a beautiful promenade for the residents. With illumination, seating, and a view of the water, it has become a central social hub.",
    location: "Islampura, Jagtial",
    bestTime: "Evenings",
    stories: []
  },
  {
    id: 145,
    name: "Dussehra - Narakasura Vadha",
    category: "Seasonal Festivals",
    district: "Jagtial",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTR3nU_6AgQQg3RGBhZDeMSqUJS48B7zMenGA&s",
    shortDescription: "Grand celebration of victory over evil.",
    description: "Dussehra is celebrated with immense fervor in Jagtial. Thousands gather at Jambigadde to witness the 'Narakasura Vadha' (symbolic slaying of the demon), followed by grand processions and cultural performances.",
    location: "Jambigadde grounds, Jagtial",
    bestTime: "September - October",
    stories: [
      "The celebration is unique to Jagtial's local culture and communal spirit."
    ]
  },
  {
    id: 146,
    name: "Varadha Pasham Ritual",
    category: "Seasonal Festivals",
    district: "Jagtial",
    image: "https://assets.thehansindia.com/h-upload/2025/06/30/1563751-varada.webp",
    shortDescription: "Ancient ritual to appease the gods for good harvest.",
    description: "An annual ritual performed in Beerpur Mandal. Devotees trek through dense forests to a hilltop temple to offer 'Payasam' to Lord Narasimha Swamy. They believe this ensures local health and agricultural prosperity.",
    location: "Pedda Gutta, Beerpur Mandal",
    bestTime: "Annual (Varies)",
    stories: [
      "A deeply rooted traditional practice that brings together remote forest villages."
    ]
  },
  {
    id: 147,
    name: "Silver Filigree Art",
    category: "Local Experiences / Crafts",
    district: "Jagtial",
    image: "https://handicrafts.nic.in/crafts/All_Crafts/Craft_Categories/Metal/Silver_Metal/Silver_Filigree_of_Karimnagar/Image_Gallery/SilFiKar_I03.jpg",
    shortDescription: "Intricate silver wire craft.",
    description: "Influenced by the nearby Karimnagar artisans, Jagtial also features traditional silver filigree work. This involves twisting fine silver wires into intricate lace-like patterns to create jewelry, boxes, and showpieces.",
    location: "Local Artisan Workshops, Jagtial",
    bestTime: "All year round",
    stories: [
      "A craft that dates back to the 19th century and has gained international recognition."
    ]
  }
];

export const initialBookings = [];
