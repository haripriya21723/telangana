import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout, isAuthenticated, isAdmin } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <span className="text-2xl font-bold text-telangana-orange">
                🧭 Telangana Trails
              </span>
            </Link>
            <div className="hidden md:ml-10 md:flex md:space-x-8">
              <Link
                to="/"
                className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
              >
                Home
              </Link>
              <Link
                to="/explore"
                className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
              >
                Explore Trails
              </Link>
              <Link
                to="/festivals"
                className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
              >
                Festivals
              </Link>
              <Link
                to="/stories"
                className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
              >
                Stories
              </Link>
              {isAuthenticated && (
                <Link
                  to="/itineraries"
                  className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
                >
                  My Itineraries
                </Link>
              )}
              {isAdmin && (
                <Link
                  to="/admin"
                  className="text-red-700 hover:text-red-800 px-3 py-2 text-sm font-medium font-semibold"
                >
                  Admin
                </Link>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link
                  to="/profile"
                  className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
                >
                  {user?.firstName} {user?.lastName}
                </Link>
                <button
                  onClick={handleLogout}
                  className="bg-telangana-orange text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-orange-600"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-gray-700 hover:text-telangana-orange px-3 py-2 text-sm font-medium"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-telangana-orange text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-orange-600"
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
