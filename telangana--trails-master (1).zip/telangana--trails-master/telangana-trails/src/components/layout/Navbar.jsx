import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext'; // Updated path
import { Menu, X, MapPin, User, LogOut, Heart, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between h-16 items-center">
                    <Link to="/" className="flex items-center space-x-2 group">
                        <img
                            src="/logo.jpg"
                            alt="Telangana Trails"
                            className="h-12 w-auto object-contain group-hover:scale-105 transition-transform mix-blend-multiply"
                        />
                    </Link>

                    {/* Desktop Menu */}
                    <div className="hidden md:flex items-center space-x-8">
                        <Link to="/" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">
                            Home
                        </Link>
                        <Link to="/categories" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">
                            Explore
                        </Link>
                        <Link to="/districts" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">
                            Districts
                        </Link>

                        {user ? (
                            <div className="flex items-center space-x-6">
                                {user.role === 'admin' ? (
                                    <Link to="/admin" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">
                                        Admin Dashboard
                                    </Link>
                                ) : (
                                    <>
                                        <Link to="/dashboard" className="text-gray-600 hover:text-pink-600 transition-colors flex items-center space-x-1">
                                            <ShoppingBag size={20} />
                                            <span>My Journey</span>
                                        </Link>
                                    </>
                                )}
                                <div className="flex items-center space-x-3 pl-6 border-l border-gray-200">
                                    <span className="text-sm font-medium text-gray-700">Hi, {user.name}</span>
                                    <button
                                        onClick={handleLogout}
                                        className="p-2 text-gray-500 hover:text-red-500 transition-colors"
                                    >
                                        <LogOut size={20} />
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex items-center space-x-4">
                                <Link to="/login" className="text-gray-700 font-medium hover:text-pink-600 px-4 py-2 transition-colors">
                                    Login
                                </Link>
                                <Link to="/signup" className="bg-gradient-to-r from-pink-600 to-orange-500 text-white px-5 py-2 rounded-full font-medium hover:shadow-lg hover:shadow-pink-500/30 transition-all transform hover:-translate-y-0.5">
                                    Sign Up
                                </Link>
                            </div>
                        )}
                    </div>

                    {/* Mobile menu button */}
                    <div className="md:hidden flex items-center">
                        <button
                            onClick={() => setIsOpen(!isOpen)}
                            className="text-gray-600 hover:text-gray-900 focus:outline-none"
                        >
                            {isOpen ? <X size={24} /> : <Menu size={24} />}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="md:hidden bg-white border-t border-gray-100 overflow-hidden"
                    >
                        <div className="px-4 pt-2 pb-6 space-y-2">
                            <Link onClick={() => setIsOpen(false)} to="/" className="block px-3 py-2 text-gray-700 font-medium hover:bg-pink-50 hover:text-pink-600 rounded-md">
                                Home
                            </Link>
                            <Link onClick={() => setIsOpen(false)} to="/categories" className="block px-3 py-2 text-gray-700 font-medium hover:bg-pink-50 hover:text-pink-600 rounded-md">
                                Explore
                            </Link>
                            <Link onClick={() => setIsOpen(false)} to="/districts" className="block px-3 py-2 text-gray-700 font-medium hover:bg-pink-50 hover:text-pink-600 rounded-md">
                                Districts
                            </Link>
                            {user ? (
                                <>
                                    {user.role === 'admin' ? (
                                        <Link onClick={() => setIsOpen(false)} to="/admin" className="block px-3 py-2 text-gray-700 font-medium hover:bg-pink-50 hover:text-pink-600 rounded-md">
                                            Admin Dashboard
                                        </Link>
                                    ) : (
                                        <Link onClick={() => setIsOpen(false)} to="/dashboard" className="block px-3 py-2 text-gray-700 font-medium hover:bg-pink-50 hover:text-pink-600 rounded-md">
                                            My Journey
                                        </Link>
                                    )}
                                    <button onClick={handleLogout} className="w-full text-left px-3 py-2 text-red-600 font-medium hover:bg-red-50 rounded-md">
                                        Logout
                                    </button>
                                </>
                            ) : (
                                <>
                                    <Link onClick={() => setIsOpen(false)} to="/login" className="block px-3 py-2 text-gray-700 font-medium hover:bg-pink-50 hover:text-pink-600 rounded-md">
                                        Login
                                    </Link>
                                    <Link onClick={() => setIsOpen(false)} to="/signup" className="block px-3 py-2 text-pink-600 font-medium hover:bg-pink-50 rounded-md">
                                        Sign Up
                                    </Link>
                                </>
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </nav>
    );
};

export default Navbar;
