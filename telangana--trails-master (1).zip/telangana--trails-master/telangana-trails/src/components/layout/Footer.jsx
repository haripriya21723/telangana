import React from 'react';
import { Facebook, Twitter, Instagram, Mail } from 'lucide-react';

const Footer = () => {
    return (
        <footer className="bg-gray-900 text-white pt-12 pb-8">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div className="space-y-4">
                        <h3 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-orange-500">
                            Telangana Trails
                        </h3>
                        <p className="text-gray-400 text-sm leading-relaxed">
                            Discover the hidden gems, historic wonders, and vibrant culture of Telangana. Your journey into the heart of the Deccan starts here.
                        </p>
                    </div>

                    <div>
                        <h4 className="text-lg font-semibold mb-4 text-gray-200">Quick Links</h4>
                        <ul className="space-y-2 text-sm text-gray-400">
                            <li><a href="#" className="hover:text-pink-500 transition-colors">About Us</a></li>
                            <li><a href="#" className="hover:text-pink-500 transition-colors">Destinations</a></li>
                            <li><a href="#" className="hover:text-pink-500 transition-colors">Cultural Ethics</a></li>
                            <li><a href="#" className="hover:text-pink-500 transition-colors">FAQ</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-lg font-semibold mb-4 text-gray-200">Contact</h4>
                        <ul className="space-y-2 text-sm text-gray-400">
                            <li className="flex items-center space-x-2">
                                <Mail size={16} />
                                <span>support@telanganatrails.com</span>
                            </li>
                            <li>Hyderabad, Telangana, India</li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="text-lg font-semibold mb-4 text-gray-200">Follow Us</h4>
                        <div className="flex space-x-4">
                            <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors"><Facebook /></a>
                            <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors"><Twitter /></a>
                            <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors"><Instagram /></a>
                        </div>
                    </div>
                </div>

                <div className="border-t border-gray-800 mt-12 pt-8 text-center text-sm text-gray-500">
                    &copy; {new Date().getFullYear()} Telangana Trails. All rights reserved.
                </div>
            </div>
        </footer>
    );
};

export default Footer;
