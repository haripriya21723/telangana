# Telangana Trails

**Transform travel from passive sightseeing into active cultural immersion using AI-driven storytelling.**

Telangana Trails is a comprehensive web application that allows travelers to explore Telangana's rich cultural heritage, festivals, rituals, temples, forts, and local experiences through interactive, AI-personalized journeys.

## 🚀 Features

### User Side
- **Homepage** - Immersive hero section with compelling content
- **Explore Trails** - Browse trails with advanced filters (category, district, search, popular, hidden gems)
- **Trail Details** - Comprehensive information including history, legends, rituals, stories, festivals, and reviews
- **AI-Powered Itineraries** - Generate personalized travel plans based on interests and duration
- **Interactive Storytelling** - Folklore, temple legends, and cultural stories
- **Festivals & Rituals** - Real-time festival updates and participation guidelines
- **User Account** - Profile management, saved trails, visited locations
- **Reviews & Ratings** - Share experiences and rate trails

### Admin Dashboard
- **User Management** - View and manage user accounts
- **Content Management** - Create, edit, and delete trails, festivals, and stories
- **Analytics** - Comprehensive insights and statistics
- **Activity Tracking** - Monitor user engagement and activities

## 🛠️ Tech Stack

### Frontend
- **React.js** - Component-based UI library
- **React Router** - Client-side routing
- **Tailwind CSS** - Utility-first CSS framework
- **Axios** - HTTP client for API requests

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web application framework
- **Prisma ORM** - Database toolkit
- **SQLite** - Relational database (dev/production-ready)

### Authentication
- **JWT** - JSON Web Tokens for authentication
- **bcryptjs** - Password hashing

## 📦 Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd telangana-trails
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```env
   PORT=3000
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   DATABASE_URL="file:./dev.db"
   ```

4. **Set up the database**
   ```bash
   npx prisma generate
   npx prisma migrate dev --name init
   ```

5. **Start the development server**
   
   For frontend (Terminal 1):
   ```bash
   npm run dev
   ```
   
   For backend (Terminal 2):
   ```bash
   npm run dev:server
   ```

6. **Access the application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:3000
   - API Health: http://localhost:3000/api/health

## 📁 Project Structure

```
telangana-trails/
├── server/
│   ├── routes/          # API route handlers
│   ├── middleware/      # Authentication middleware
│   ├── db/              # Prisma client
│   └── index.js         # Express server entry
├── prisma/
│   └── schema.prisma    # Database schema
├── src/
│   ├── components/      # Reusable React components
│   ├── pages/           # Page components
│   │   └── admin/       # Admin dashboard pages
│   ├── context/         # React context providers
│   ├── utils/           # Utility functions & API client
│   ├── App.jsx          # Main app component
│   └── main.jsx         # React entry point
└── public/              # Static assets
```

## 🗄️ Database Schema

The application uses Prisma with SQLite. Key models include:
- **User** - User accounts and authentication
- **Trail** - Destinations, temples, forts, etc.
- **Festival** - Festivals and cultural events
- **Story** - Folklore, legends, and cultural narratives
- **Review** - User reviews and ratings
- **UserActivity** - Track visits and bookmarks
- **Itinerary** - AI-generated travel plans
- **ItineraryTrail** - Trail assignments in itineraries

## 🔐 Authentication

The app uses JWT-based authentication. Users can:
- Register with email and password
- Login to access protected routes
- Access role-based features (admin/moderator)

## 🧭 API Endpoints

### Public Routes
- `GET /api/trails` - Get all trails (with filters)
- `GET /api/trails/:id` - Get trail details
- `GET /api/festivals` - Get festivals
- `GET /api/stories` - Get stories
- `GET /api/reviews/trail/:trailId` - Get reviews for a trail

### Protected Routes
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/trails/:id/activity` - Record user activity
- `POST /api/reviews` - Create review
- `POST /api/itineraries/generate` - Generate AI itinerary

### Admin Routes (Require Admin Role)
- `GET /api/admin/users` - Get all users
- `GET /api/admin/analytics` - Get analytics
- `POST /api/admin/trails` - Create trail
- `PUT /api/admin/trails/:id` - Update trail
- `DELETE /api/admin/trails/:id` - Delete trail
- Similar CRUD operations for festivals and stories

## 🎨 Features in Detail

### AI Itinerary Generation
The itinerary generation algorithm:
1. Filters trails by user-selected interests
2. Scores trails based on ratings and popularity
3. Distributes top-scored trails across the requested duration
4. Creates a personalized travel plan

### Trail Discovery
- Advanced filtering by category, district, and popularity
- Search functionality
- Hidden gems discovery
- Detailed trail information with multimedia support

## 🚧 Future Enhancements

- AR/VR heritage walks
- Multi-language support
- Mobile app version
- Real-time notifications
- Social sharing features
- Offline mode support

## 📝 License

This project is private and proprietary.

## 👥 Team

Developed for Telangana Trails - Preserving Heritage Through Technology

---

**© Telangana Trails – Preserving Heritage Through Technology**
