# Setup Guide for Telangana Trails

## Initial Setup Steps

### 1. Install Dependencies
```bash
cd telangana-trails
npm install
```

### 2. Create Environment File
Create a `.env` file in the root directory (`telangana-trails/`) with the following content:

```env
PORT=3000
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production-use-a-strong-random-string
DATABASE_URL="file:./dev.db"
```

**Important**: Replace `your-super-secret-jwt-key-change-this-in-production-use-a-strong-random-string` with a strong, random string for JWT token signing.

### 3. Initialize Database

```bash
# Generate Prisma Client
npx prisma generate

# Create database and run migrations
npx prisma migrate dev --name init
```

This will:
- Create the SQLite database file (`dev.db`)
- Set up all the database tables according to the Prisma schema

### 4. Create Admin User (Optional)

You can create an admin user directly in the database or through the registration form and manually update the role in the database:

```bash
# Open Prisma Studio to manage database
npx prisma studio
```

Then navigate to the User table and change the `role` field from `"user"` to `"admin"`.

### 5. Start the Development Servers

**Terminal 1 - Frontend (Vite):**
```bash
npm run dev
```
This will start the React frontend on http://localhost:5173

**Terminal 2 - Backend (Express):**
```bash
npm run dev:server
```
Or if you have nodemon installed:
```bash
npm run dev:server
```

This will start the Express backend on http://localhost:3000

### 6. Access the Application

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3000
- **API Health Check**: http://localhost:3000/api/health
- **Prisma Studio** (Database GUI): Run `npx prisma studio` and access at http://localhost:5555

## Common Issues

### Database Issues
If you encounter database errors:
```bash
# Reset the database (WARNING: This will delete all data)
npx prisma migrate reset

# Or regenerate Prisma Client
npx prisma generate
```

### Port Already in Use
If port 3000 or 5173 is already in use:
- Change `PORT` in `.env` file for backend
- Change `server.port` in `vite.config.js` for frontend

### CORS Issues
The backend is configured to accept requests from `http://localhost:5173`. If you change the frontend port, update the CORS settings in `server/index.js`.

## Testing the Application

1. **Register a new user** at http://localhost:5173/register
2. **Login** at http://localhost:5173/login
3. **Explore trails** at http://localhost:5173/explore
4. **Create an itinerary** (requires login) at http://localhost:5173/itineraries
5. **Access admin dashboard** (requires admin role) at http://localhost:5173/admin

## Production Deployment

For production deployment:

1. **Change database** from SQLite to PostgreSQL or MySQL
2. **Update `.env`** with production database URL
3. **Set strong JWT_SECRET** in production environment
4. **Build frontend**: `npm run build`
5. **Serve frontend** using a static file server (Nginx, Vercel, Netlify)
6. **Deploy backend** to platforms like Railway, Render, or Heroku
7. **Run migrations**: `npx prisma migrate deploy`

## Next Steps

- Add sample data through the admin dashboard
- Customize the content for Telangana-specific trails
- Add images and multimedia content
- Configure AI itinerary parameters
- Set up notifications and email services
