import { PrismaClient } from '@prisma/client';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';

dotenv.config({ path: './.env' });

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Create Users
  const hashedPassword = await bcrypt.hash('password123', 10);
  const adminPassword = await bcrypt.hash('adminpassword', 10);

  await prisma.user.upsert({
    where: { email: 'admin@kprit.ac.in' },
    update: {},
    create: {
      name: 'Admin User',
      email: 'admin@kprit.ac.in',
      password: adminPassword,
      role: 'ADMIN',
    },
  });

  await prisma.user.upsert({
    where: { email: 'sai@kprit.ac.in' },
    update: {},
    create: {
      name: 'Sai Kumar',
      email: 'sai@kprit.ac.in',
      password: hashedPassword,
      role: 'USER',
    },
  });

  console.log('Users created');

  // Create Categories
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { name: 'Temple' },
      update: {},
      create: {
        name: 'Temple',
        description: 'Ancient temples and spiritual sites',
      },
    }),
    prisma.category.upsert({
      where: { name: 'Fort' },
      update: {},
      create: {
        name: 'Fort',
        description: 'Historical forts and monuments',
      },
    }),
    prisma.category.upsert({
      where: { name: 'Heritage' },
      update: {},
      create: {
        name: 'Heritage',
        description: 'Heritage sites and cultural landmarks',
      },
    }),
    prisma.category.upsert({
      where: { name: 'Craft' },
      update: {},
      create: {
        name: 'Craft',
        description: 'Traditional craft villages and artisans',
      },
    }),
    prisma.category.upsert({
      where: { name: 'Food' },
      update: {},
      create: {
        name: 'Food',
        description: 'Food and cultural experiences',
      },
    }),
  ]);

  console.log(`Created ${categories.length} categories`);
  categories.forEach((c, i) => console.log(`Category ${i}:`, c ? c.name : 'undefined'));

  const templeCategory = categories[0];
  const fortCategory = categories[1];
  const heritageCategory = categories[2];
  const craftCategory = categories[3];
  const foodCategory = categories[4];

  // Create Destinations
  const destinations = await Promise.all([
    prisma.destination.upsert({
      where: { id: 'dest-1' },
      update: {},
      create: {
        id: 'dest-1',
        name: 'Charminar',
        description: 'The iconic monument of Hyderabad, built in 1591 by Muhammad Quli Qutb Shah to mark the end of a plague in the city.',
        latitude: 17.3616,
        longitude: 78.4747,
        categoryId: heritageCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=800',
      },
    }),
    prisma.destination.upsert({
      where: { id: 'dest-2' },
      update: {},
      create: {
        id: 'dest-2',
        name: 'Golconda Fort',
        description: 'A majestic fort complex that was the capital of the medieval sultanate of the Qutb Shahi dynasty.',
        latitude: 17.3833,
        longitude: 78.4011,
        categoryId: fortCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1604725333738-89423c4f0f9e?w=800',
      },
    }),
    prisma.destination.upsert({
      where: { id: 'dest-3' },
      update: {},
      create: {
        id: 'dest-3',
        name: 'Bhadrachalam Temple',
        description: 'A famous temple dedicated to Lord Rama, located on the banks of the Godavari River.',
        latitude: 17.6686,
        longitude: 80.8906,
        categoryId: templeCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=800',
      },
    }),
    prisma.destination.upsert({
      where: { id: 'dest-4' },
      update: {},
      create: {
        id: 'dest-4',
        name: 'Warangal Fort',
        description: 'An ancient fort built during the Kakatiya dynasty, known for its architectural grandeur.',
        latitude: 17.9566,
        longitude: 79.6022,
        categoryId: fortCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1539650116574-75c0c6d73aa6?w=800',
      },
    }),
    prisma.destination.upsert({
      where: { id: 'dest-5' },
      update: {},
      create: {
        id: 'dest-5',
        name: 'Thousand Pillar Temple',
        description: 'A historic Hindu temple dedicated to Lord Shiva, Vishnu and Surya, built by the Kakatiyas.',
        latitude: 18.0,
        longitude: 79.5883,
        categoryId: templeCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1539650116574-75c0c6d73aa6?w=800',
      },
    }),
  ]);

  // Create Hidden Trail Destinations
  await Promise.all([
    prisma.destination.upsert({
      where: { id: 'dest-6' },
      update: {},
      create: {
        id: 'dest-6',
        name: 'Nirmal Village - Traditional Crafts',
        description: 'A hidden gem known for its traditional wooden toys, exquisite hand-painted furniture, and unique Nirmal paintings that showcase Telangana\'s rich artisanal heritage.',
        latitude: 19.0969,
        longitude: 78.3447,
        categoryId: craftCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1586985289688-ca3cf47d3b6e?w=800',
        isHiddenTrail: true,
        localExperiences: '• Watch artisans create intricate Nirmal toys and furniture\n• Learn the traditional painting techniques from master craftsmen\n• Purchase authentic handicrafts directly from the makers\n• Visit local workshops to see centuries-old techniques\n• Experience the village life and interact with local families',
      },
    }),
    prisma.destination.upsert({
      where: { id: 'dest-7' },
      update: {},
      create: {
        id: 'dest-7',
        name: 'Pochampally Ikat Weaving Village',
        description: 'An authentic village experience where traditional Ikat weaving has been practiced for generations. Witness the intricate dyeing and weaving process that creates stunning geometric patterns.',
        latitude: 17.3920,
        longitude: 78.6785,
        categoryId: craftCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1586105251261-72a756497a11?w=800',
        isHiddenTrail: true,
        localExperiences: '• Observe master weavers create intricate Ikat patterns\n• Try your hand at the traditional dyeing technique\n• Purchase handwoven sarees and fabrics directly from weavers\n• Learn about the mathematical precision behind Ikat patterns\n• Enjoy traditional Telangana meals with local families',
      },
    }),
    prisma.destination.upsert({
      where: { id: 'dest-8' },
      update: {},
      create: {
        id: 'dest-8',
        name: 'Medak - Rural Food Trail',
        description: 'Experience authentic Telangana cuisine through a village food trail. Discover traditional cooking methods, local ingredients, and regional specialties passed down through generations.',
        latitude: 18.0452,
        longitude: 78.2610,
        categoryId: foodCategory.id,
        imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
        isHiddenTrail: true,
        localExperiences: '• Participate in traditional cooking sessions with local women\n• Taste authentic Telangana dishes: Jonna Roti, Sarva Pindi, and Hyderabadi Biryani\n• Visit local markets to learn about regional ingredients\n• Learn the art of making traditional pickles and chutneys\n• Experience a village-style community meal',
      },
    }),
  ]);

  // Create Stories
  await prisma.story.upsert({
    where: { id: 'story-1' },
    update: {},
    create: {
      id: 'story-1',
      title: 'The Legend of Charminar',
      content: 'Charminar was built by Muhammad Quli Qutb Shah in 1591. Legend says he built it at the exact location where he first glimpsed his future queen, Bhagmati. The monument symbolizes the four pillars of Islam and stands as a testament to the city\'s rich history.',
      history: 'Built in 1591, Charminar is a monument and mosque located in Hyderabad. The structure was built by the fifth ruler of the Qutb Shahi dynasty, Muhammad Quli Qutb Shah. It is listed as an archaeological and architectural treasure on the official "List of Monuments" prepared by the Archaeological Survey of India.',
      folklore: 'Local folklore suggests that Charminar was built to commemorate the end of a plague that had ravaged the city. The sultan prayed for the plague to end and vowed to build a mosque at the location where it stopped.',
      rituals: 'Devotees often visit the mosque on Fridays for prayers. The area around Charminar comes alive during Ramadan with food stalls and markets. The monument is beautifully illuminated during festivals.',
      destinationId: destinations[0].id,
      imageUrl: 'https://images.unsplash.com/photo-1582979512210-99b6a53386f9?w=800',
    },
  });

  await prisma.story.upsert({
    where: { id: 'story-2' },
    update: {},
    create: {
      id: 'story-2',
      title: 'Golconda: The Diamond Fort',
      content: 'Golconda Fort was once the center of the world\'s diamond trade. The famous Koh-i-Noor and Hope diamonds are said to have originated from the mines near Golconda.',
      history: 'The fort was originally built by the Kakatiyas in the 13th century and later expanded by the Qutb Shahi dynasty. It served as the capital of the Qutb Shahi kingdom until it was moved to Hyderabad in 1590.',
      folklore: 'Legend has it that the fort has a secret underground tunnel that leads to the Charminar. The acoustic system of the fort is so advanced that a hand clap at the entrance can be heard at the highest point of the fort.',
      rituals: 'The fort is now a popular tourist destination. Light and sound shows are held in the evenings that narrate the history of the fort and the Qutb Shahi dynasty.',
      destinationId: destinations[1].id,
    },
  });

  // Create Festivals
  await prisma.festival.upsert({
    where: { id: 'fest-1' },
    update: {},
    create: {
      id: 'fest-1',
      name: 'Bonalu',
      description: 'Bonalu is a traditional Telangana festival where people offer food to the Mother Goddess. It is celebrated during the months of July and August.',
      date: new Date(new Date().getFullYear(), 6, 15), // July 15
      location: 'Hyderabad, Secunderabad',
      significance: 'Bonalu is a thanksgiving festival to the Mother Goddess for fulfilling vows. It is celebrated with great enthusiasm and involves colorful processions.',
      dos: 'Participate respectfully in the celebrations. Follow local customs and traditions. Dress modestly when visiting temples.',
      donts: 'Do not disrespect the rituals or interfere with the processions. Avoid taking photographs without permission during religious ceremonies.',
    },
  });

  await prisma.festival.upsert({
    where: { id: 'fest-2' },
    update: {},
    create: {
      id: 'fest-2',
      name: 'Bathukamma',
      description: 'Bathukamma is a colorful flower festival celebrated by women in Telangana. It is a nine-day festival that falls during Navratri.',
      date: new Date(new Date().getFullYear(), 9, 1), // October 1
      location: 'Throughout Telangana',
      significance: 'Bathukamma symbolizes the cultural identity of Telangana. Women prepare beautiful flower stacks and sing folk songs while celebrating nature and the goddess Gauri.',
      dos: 'Participate in the flower stacking. Learn about the traditional songs and dances. Respect the cultural significance of the festival.',
      donts: 'Do not pluck flowers from protected areas. Avoid disrupting the traditional ceremonies.',
    },
  });

  await prisma.festival.upsert({
    where: { id: 'fest-3' },
    update: {},
    create: {
      id: 'fest-3',
      name: 'Sammakka Saralamma Jatara',
      description: 'One of the largest tribal festivals in India, celebrated once every two years in Medaram. Millions of devotees participate in this festival.',
      date: new Date(new Date().getFullYear() + 1, 1, 1), // February next year
      location: 'Medaram, Warangal',
      significance: 'This festival honors the tribal goddesses Sammakka and Saralamma, who are believed to protect the tribals. It is a symbol of tribal unity and cultural heritage.',
      dos: 'Respect the tribal customs and traditions. Follow the instructions of local authorities. Maintain cleanliness and hygiene.',
      donts: 'Do not disturb the tribal rituals. Avoid bringing plastic or non-biodegradable items. Do not harm the forest ecosystem.',
    },
  });

  console.log('Database seeded successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
