import prisma from '../prisma/client.js';

export const getStoriesByDestination = async (req, res) => {
  try {
    const { destinationId } = req.params;

    const stories = await prisma.story.findMany({
      where: { destinationId },
      include: {
        destination: {
          select: {
            id: true,
            name: true,
            latitude: true,
            longitude: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ stories });
  } catch (error) {
    console.error('Get stories error:', error);
    res.status(500).json({ error: 'Failed to fetch stories' });
  }
};

export const getStoryById = async (req, res) => {
  try {
    const { id } = req.params;

    const story = await prisma.story.findUnique({
      where: { id },
      include: {
        destination: true,
      },
    });

    if (!story) {
      return res.status(404).json({ error: 'Story not found' });
    }

    res.json({ story });
  } catch (error) {
    console.error('Get story error:', error);
    res.status(500).json({ error: 'Failed to fetch story' });
  }
};

export const createStory = async (req, res) => {
  try {
    const { title, content, folklore, rituals, history, imageUrl, destinationId } = req.body;

    const story = await prisma.story.create({
      data: {
        title,
        content,
        folklore,
        rituals,
        history,
        imageUrl,
        destinationId,
      },
      include: {
        destination: true,
      },
    });

    res.status(201).json({ story });
  } catch (error) {
    console.error('Create story error:', error);
    res.status(500).json({ error: 'Failed to create story' });
  }
};
