import prisma from '../prisma/client.js';

export const getUserItineraries = async (req, res) => {
  try {
    const itineraries = await prisma.itinerary.findMany({
      where: { userId: req.user.userId },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ itineraries });
  } catch (error) {
    console.error('Get itineraries error:', error);
    res.status(500).json({ error: 'Failed to fetch itineraries' });
  }
};

export const getItineraryById = async (req, res) => {
  try {
    const { id } = req.params;

    const itinerary = await prisma.itinerary.findUnique({
      where: { id },
    });

    if (!itinerary) {
      return res.status(404).json({ error: 'Itinerary not found' });
    }

    // Check if user owns the itinerary
    if (itinerary.userId !== req.user.userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json({ itinerary });
  } catch (error) {
    console.error('Get itinerary error:', error);
    res.status(500).json({ error: 'Failed to fetch itinerary' });
  }
};

export const createItinerary = async (req, res) => {
  try {
    const { name, description, destinations, preferences } = req.body;

    const itinerary = await prisma.itinerary.create({
      data: {
        name,
        description,
        destinations: destinations || [],
        preferences: preferences || {},
        userId: req.user.userId,
      },
    });

    res.status(201).json({ itinerary });
  } catch (error) {
    console.error('Create itinerary error:', error);
    res.status(500).json({ error: 'Failed to create itinerary' });
  }
};

export const updateItinerary = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, destinations, preferences } = req.body;

    // Check if itinerary exists and user owns it
    const existingItinerary = await prisma.itinerary.findUnique({
      where: { id },
    });

    if (!existingItinerary) {
      return res.status(404).json({ error: 'Itinerary not found' });
    }

    if (existingItinerary.userId !== req.user.userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Access denied' });
    }

    const itinerary = await prisma.itinerary.update({
      where: { id },
      data: {
        name,
        description,
        destinations,
        preferences,
      },
    });

    res.json({ itinerary });
  } catch (error) {
    console.error('Update itinerary error:', error);
    res.status(500).json({ error: 'Failed to update itinerary' });
  }
};

export const deleteItinerary = async (req, res) => {
  try {
    const { id } = req.params;

    const existingItinerary = await prisma.itinerary.findUnique({
      where: { id },
    });

    if (!existingItinerary) {
      return res.status(404).json({ error: 'Itinerary not found' });
    }

    if (existingItinerary.userId !== req.user.userId && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Access denied' });
    }

    await prisma.itinerary.delete({
      where: { id },
    });

    res.json({ message: 'Itinerary deleted successfully' });
  } catch (error) {
    console.error('Delete itinerary error:', error);
    res.status(500).json({ error: 'Failed to delete itinerary' });
  }
};

// Helper function to calculate distance between two points
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export const generateItinerary = async (req, res) => {
  try {
    const { preferences, days = 3, locations } = req.body;

    // Fetch all destinations
    const destinations = await prisma.destination.findMany({
      include: {
        category: true,
        stories: {
          take: 1,
        },
      },
    });

    // Filter based on preferences
    let filtered = destinations;
    
    // Filter by categories
    if (preferences?.categories?.length > 0) {
      filtered = destinations.filter(d => 
        preferences.categories.includes(d.category.name)
      );
    }

    // Include/exclude hidden trails based on preferences (default: include if not specified)
    const includeHiddenTrails = preferences?.includeHiddenTrails !== false;
    if (!includeHiddenTrails) {
      filtered = filtered.filter(d => !d.isHiddenTrail);
    }

    if (filtered.length === 0) {
      return res.status(400).json({ 
        error: 'No destinations match your preferences. Please try different selections.' 
      });
    }

    // Enhanced selection algorithm
    let selected = [];
    const numDestinations = Math.min(days * 2, filtered.length); // 2 destinations per day on average
    
    // If starting location provided, prioritize nearby destinations
    if (locations?.latitude && locations?.longitude) {
      // Sort by distance from starting point
      filtered.forEach(dest => {
        dest.distance = calculateDistance(
          locations.latitude,
          locations.longitude,
          dest.latitude,
          dest.longitude
        );
      });
      filtered.sort((a, b) => a.distance - b.distance);
    }

    // Select destinations with diversity (different categories)
    const selectedCategories = new Set();
    for (let dest of filtered) {
      if (selected.length >= numDestinations) break;
      
      // Ensure diversity: prefer destinations from different categories
      if (!selectedCategories.has(dest.category.name) || Math.random() > 0.3) {
        selected.push(dest);
        selectedCategories.add(dest.category.name);
      }
    }

    // If we don't have enough, fill with remaining destinations
    if (selected.length < numDestinations) {
      const remaining = filtered.filter(d => !selected.includes(d));
      selected = [...selected, ...remaining.slice(0, numDestinations - selected.length)];
    }

    // Distribute destinations across days
    const destinationsByDay = [];
    const destinationsPerDay = Math.ceil(selected.length / days);
    
    for (let day = 0; day < days; day++) {
      const dayDestinations = selected.slice(
        day * destinationsPerDay,
        (day + 1) * destinationsPerDay
      );
      if (dayDestinations.length > 0) {
        destinationsByDay.push({
          day: day + 1,
          destinations: dayDestinations.map(d => ({
            id: d.id,
            name: d.name,
            latitude: d.latitude,
            longitude: d.longitude,
            category: d.category.name,
            description: d.description,
          })),
        });
      }
    }

    // Generate itinerary name based on preferences
    const categoryNames = preferences?.categories?.join(', ') || 'Diverse';
    const itineraryName = `${categoryNames} Experience - ${days} Day${days > 1 ? 's' : ''}`;
    const description = `AI-generated itinerary exploring ${categoryNames.toLowerCase()} destinations across Telangana over ${days} days.`;

    const itinerary = await prisma.itinerary.create({
      data: {
        name: itineraryName,
        description,
        destinations: {
          days: destinationsByDay,
          totalDestinations: selected.length,
        },
        preferences: preferences || {},
        userId: req.user.userId,
      },
    });

    // Update user preferences if provided
    if (preferences) {
      await prisma.user.update({
        where: { id: req.user.userId },
        data: {
          preferences: preferences,
        },
      });
    }

    res.status(201).json({ itinerary });
  } catch (error) {
    console.error('Generate itinerary error:', error);
    res.status(500).json({ error: 'Failed to generate itinerary' });
  }
};
