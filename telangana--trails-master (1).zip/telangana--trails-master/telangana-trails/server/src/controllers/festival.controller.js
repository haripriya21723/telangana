import prisma from '../prisma/client.js';

export const getAllFestivals = async (req, res) => {
  try {
    const { month, year, location } = req.query;
    
    const where = {};
    if (month) {
      where.date = {
        gte: new Date(parseInt(year) || new Date().getFullYear(), parseInt(month) - 1, 1),
        lt: new Date(parseInt(year) || new Date().getFullYear(), parseInt(month), 1),
      };
    }
    if (location) {
      where.location = { contains: location };
    }

    const festivals = await prisma.festival.findMany({
      where,
      orderBy: { date: 'asc' },
    });

    res.json({ festivals });
  } catch (error) {
    console.error('Get festivals error:', error);
    res.status(500).json({ error: 'Failed to fetch festivals' });
  }
};

export const getUpcomingFestivals = async (req, res) => {
  try {
    const festivals = await prisma.festival.findMany({
      where: {
        date: {
          gte: new Date(),
        },
      },
      orderBy: { date: 'asc' },
      take: 10,
    });

    res.json({ festivals });
  } catch (error) {
    console.error('Get upcoming festivals error:', error);
    res.status(500).json({ error: 'Failed to fetch upcoming festivals' });
  }
};

export const getFestivalById = async (req, res) => {
  try {
    const { id } = req.params;

    const festival = await prisma.festival.findUnique({
      where: { id },
    });

    if (!festival) {
      return res.status(404).json({ error: 'Festival not found' });
    }

    res.json({ festival });
  } catch (error) {
    console.error('Get festival error:', error);
    res.status(500).json({ error: 'Failed to fetch festival' });
  }
};

export const createFestival = async (req, res) => {
  try {
    const { name, description, date, location, significance, dos, donts, imageUrl } = req.body;

    const festival = await prisma.festival.create({
      data: {
        name,
        description,
        date: new Date(date),
        location,
        significance,
        dos,
        donts,
        imageUrl,
      },
    });

    res.status(201).json({ festival });
  } catch (error) {
    console.error('Create festival error:', error);
    res.status(500).json({ error: 'Failed to create festival' });
  }
};
