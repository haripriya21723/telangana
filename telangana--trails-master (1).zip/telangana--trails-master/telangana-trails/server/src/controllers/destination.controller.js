import prisma from '../prisma/client.js';

export const getAllDestinations = async (req, res) => {
  try {
    const { category, search, hiddenTrails } = req.query;
    
    const where = {};
    if (category) {
      where.category = { name: category };
    }
    if (search) {
      // SQLite doesn't support case-insensitive search directly, so we use contains
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (hiddenTrails === 'true') {
      where.isHiddenTrail = true;
    }

    const destinations = await prisma.destination.findMany({
      where,
      include: {
        category: true,
        stories: {
          take: 1,
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    res.json({ destinations });
  } catch (error) {
    console.error('Get destinations error:', error);
    res.status(500).json({ error: 'Failed to fetch destinations' });
  }
};

export const getDestinationById = async (req, res) => {
  try {
    const { id } = req.params;

    const destination = await prisma.destination.findUnique({
      where: { id },
      include: {
        category: true,
        stories: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!destination) {
      return res.status(404).json({ error: 'Destination not found' });
    }

    res.json({ destination });
  } catch (error) {
    console.error('Get destination error:', error);
    res.status(500).json({ error: 'Failed to fetch destination' });
  }
};

export const getNearbyDestinations = async (req, res) => {
  try {
    const { lat, lng, radius = 50 } = req.query; // radius in km

    if (!lat || !lng) {
      return res.status(400).json({ error: 'Latitude and longitude required' });
    }

    const destinations = await prisma.destination.findMany({
      include: {
        category: true,
      },
    });

    // Simple distance calculation (Haversine formula would be better for production)
    const nearby = destinations.filter(dest => {
      const distance = calculateDistance(
        parseFloat(lat),
        parseFloat(lng),
        dest.latitude,
        dest.longitude
      );
      return distance <= parseFloat(radius);
    });

    res.json({ destinations: nearby });
  } catch (error) {
    console.error('Get nearby destinations error:', error);
    res.status(500).json({ error: 'Failed to fetch nearby destinations' });
  }
};

function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export const createDestination = async (req, res) => {
  try {
    const { name, description, latitude, longitude, imageUrl, categoryId } = req.body;

    const destination = await prisma.destination.create({
      data: {
        name,
        description,
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        imageUrl,
        categoryId,
      },
      include: {
        category: true,
      },
    });

    res.status(201).json({ destination });
  } catch (error) {
    console.error('Create destination error:', error);
    res.status(500).json({ error: 'Failed to create destination' });
  }
};
