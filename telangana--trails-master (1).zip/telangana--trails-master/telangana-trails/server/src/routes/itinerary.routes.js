import express from 'express';
import {
  getUserItineraries,
  getItineraryById,
  createItinerary,
  updateItinerary,
  deleteItinerary,
  generateItinerary,
} from '../controllers/itinerary.controller.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = express.Router();

// All itinerary routes require authentication
router.use(authenticateToken);

router.get('/', getUserItineraries);
router.post('/generate', generateItinerary);
router.get('/:id', getItineraryById);
router.post('/', createItinerary);
router.put('/:id', updateItinerary);
router.delete('/:id', deleteItinerary);

export default router;
