import express from 'express';
import {
  getStoriesByDestination,
  getStoryById,
  createStory,
} from '../controllers/story.controller.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.middleware.js';

const router = express.Router();

router.get('/destination/:destinationId', getStoriesByDestination);
router.get('/:id', getStoryById);
router.post('/', authenticateToken, requireAdmin, createStory);

export default router;
