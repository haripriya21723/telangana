import express from 'express';
import {
  getAllDestinations,
  getDestinationById,
  getNearbyDestinations,
  createDestination,
} from '../controllers/destination.controller.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.middleware.js';

const router = express.Router();

router.get('/', getAllDestinations);
router.get('/nearby', getNearbyDestinations);
router.get('/:id', getDestinationById);
router.post('/', authenticateToken, requireAdmin, createDestination);

export default router;
