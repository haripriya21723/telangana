import express from 'express';
import {
  getAllFestivals,
  getUpcomingFestivals,
  getFestivalById,
  createFestival,
} from '../controllers/festival.controller.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.middleware.js';

const router = express.Router();

router.get('/', getAllFestivals);
router.get('/upcoming', getUpcomingFestivals);
router.get('/:id', getFestivalById);
router.post('/', authenticateToken, requireAdmin, createFestival);

export default router;
