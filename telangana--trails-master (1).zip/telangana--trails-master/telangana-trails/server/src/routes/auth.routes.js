import express from 'express';
import { register, login, getProfile, updatePreferences } from '../controllers/auth.controller.js';
import { validate, registerValidation, loginValidation } from '../utils/validation.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = express.Router();

router.post('/register', validate(registerValidation), register);
router.post('/login', validate(loginValidation), login);
router.get('/profile', authenticateToken, getProfile);
router.put('/preferences', authenticateToken, updatePreferences);

export default router;
