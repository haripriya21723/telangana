import express from 'express';
import prisma from '../db/prisma.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// All admin routes require authentication and admin role
router.use(authenticateToken);
router.use(requireAdmin);

// Get all users
router.get('/users', async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        createdAt: true,
        _count: {
          select: {
            activities: true,
            reviews: true,
            itineraries: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    res.json({ users });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Analytics
router.get('/analytics', async (req, res) => {
  try {
    const totalUsers = await prisma.user.count();
    const totalTrails = await prisma.trail.count();
    const totalFestivals = await prisma.festival.count();
    const totalReviews = await prisma.review.count();
    const totalActivities = await prisma.userActivity.count();

    // Popular trails
    const popularTrails = await prisma.trail.findMany({
      include: {
        _count: {
          select: {
            activities: true,
            reviews: true
          }
        },
        reviews: {
          select: {
            rating: true
          }
        }
      },
      orderBy: {
        activities: {
          _count: 'desc'
        }
      },
      take: 10
    });

    const trailsWithStats = popularTrails.map(trail => {
      const ratings = trail.reviews.map(r => r.rating);
      const avgRating = ratings.length > 0
        ? ratings.reduce((a, b) => a + b, 0) / ratings.length
        : 0;

      return {
        id: trail.id,
        title: trail.title,
        category: trail.category,
        district: trail.district,
        visits: trail._count.activities,
        reviews: trail._count.reviews,
        averageRating: avgRating
      };
    });

    // Category distribution
    const categoryStats = await prisma.trail.groupBy({
      by: ['category'],
      _count: {
        id: true
      }
    });

    res.json({
      overview: {
        totalUsers,
        totalTrails,
        totalFestivals,
        totalReviews,
        totalActivities
      },
      popularTrails: trailsWithStats,
      categoryDistribution: categoryStats
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create trail
router.post('/trails', async (req, res) => {
  try {
    const {
      title,
      category,
      district,
      description,
      history,
      legends,
      rituals,
      images,
      videos,
      latitude,
      longitude,
      isPopular,
      isHiddenGem
    } = req.body;

    if (!title || !category || !district || !description) {
      return res.status(400).json({ error: 'Title, category, district, and description are required' });
    }

    const trail = await prisma.trail.create({
      data: {
        title,
        category,
        district,
        description,
        history: history || null,
        legends: legends || null,
        rituals: rituals || null,
        images: JSON.stringify(images || []),
        videos: videos ? JSON.stringify(videos) : null,
        latitude: latitude || null,
        longitude: longitude || null,
        isPopular: isPopular || false,
        isHiddenGem: isHiddenGem || false
      }
    });

    res.status(201).json({
      trail: {
        ...trail,
        images: JSON.parse(trail.images || '[]'),
        videos: trail.videos ? JSON.parse(trail.videos) : []
      }
    });
  } catch (error) {
    console.error('Error creating trail:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update trail
router.put('/trails/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = { ...req.body };

    if (updateData.images) {
      updateData.images = JSON.stringify(updateData.images);
    }
    if (updateData.videos) {
      updateData.videos = JSON.stringify(updateData.videos);
    }

    const trail = await prisma.trail.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json({
      trail: {
        ...trail,
        images: JSON.parse(trail.images || '[]'),
        videos: trail.videos ? JSON.parse(trail.videos) : []
      }
    });
  } catch (error) {
    console.error('Error updating trail:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete trail
router.delete('/trails/:id', async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.trail.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: 'Trail deleted successfully' });
  } catch (error) {
    console.error('Error deleting trail:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create festival
router.post('/festivals', async (req, res) => {
  try {
    const {
      name,
      startDate,
      endDate,
      description,
      participationTips,
      culturalSignificance,
      images,
      trailId
    } = req.body;

    if (!name || !startDate || !endDate || !description) {
      return res.status(400).json({ error: 'Name, startDate, endDate, and description are required' });
    }

    const festival = await prisma.festival.create({
      data: {
        name,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        description,
        participationTips: participationTips || null,
        culturalSignificance: culturalSignificance || null,
        images: images ? JSON.stringify(images) : null,
        trailId: trailId ? parseInt(trailId) : null
      }
    });

    res.status(201).json({
      festival: {
        ...festival,
        images: festival.images ? JSON.parse(festival.images) : []
      }
    });
  } catch (error) {
    console.error('Error creating festival:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update festival
router.put('/festivals/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = { ...req.body };

    if (updateData.startDate) updateData.startDate = new Date(updateData.startDate);
    if (updateData.endDate) updateData.endDate = new Date(updateData.endDate);
    if (updateData.images) updateData.images = JSON.stringify(updateData.images);

    const festival = await prisma.festival.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json({
      festival: {
        ...festival,
        images: festival.images ? JSON.parse(festival.images) : []
      }
    });
  } catch (error) {
    console.error('Error updating festival:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete festival
router.delete('/festivals/:id', async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.festival.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: 'Festival deleted successfully' });
  } catch (error) {
    console.error('Error deleting festival:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create story
router.post('/stories', async (req, res) => {
  try {
    const {
      trailId,
      title,
      content,
      type,
      mediaUrls,
      audioUrl,
      videoUrl
    } = req.body;

    if (!trailId || !title || !content || !type) {
      return res.status(400).json({ error: 'TrailId, title, content, and type are required' });
    }

    const story = await prisma.story.create({
      data: {
        trailId: parseInt(trailId),
        title,
        content,
        type,
        mediaUrls: mediaUrls ? JSON.stringify(mediaUrls) : null,
        audioUrl: audioUrl || null,
        videoUrl: videoUrl || null
      }
    });

    res.status(201).json({
      story: {
        ...story,
        mediaUrls: story.mediaUrls ? JSON.parse(story.mediaUrls) : []
      }
    });
  } catch (error) {
    console.error('Error creating story:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update story
router.put('/stories/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = { ...req.body };

    if (updateData.mediaUrls) {
      updateData.mediaUrls = JSON.stringify(updateData.mediaUrls);
    }

    const story = await prisma.story.update({
      where: { id: parseInt(id) },
      data: updateData
    });

    res.json({
      story: {
        ...story,
        mediaUrls: story.mediaUrls ? JSON.parse(story.mediaUrls) : []
      }
    });
  } catch (error) {
    console.error('Error updating story:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete story
router.delete('/stories/:id', async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.story.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: 'Story deleted successfully' });
  } catch (error) {
    console.error('Error deleting story:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get user activities
router.get('/activities', async (req, res) => {
  try {
    const activities = await prisma.userActivity.findMany({
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true
          }
        },
        trail: {
          select: {
            title: true,
            category: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: 100
    });

    res.json({ activities });
  } catch (error) {
    console.error('Error fetching activities:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get user reviews for moderation
router.get('/reviews', async (req, res) => {
  try {
    const reviews = await prisma.review.findMany({
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true,
            email: true
          }
        },
        trail: {
          select: {
            title: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    const formattedReviews = reviews.map(review => ({
      ...review,
      photos: review.photos ? JSON.parse(review.photos) : []
    }));

    res.json({ reviews: formattedReviews });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
