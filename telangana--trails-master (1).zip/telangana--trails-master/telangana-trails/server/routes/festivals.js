import express from 'express';
import prisma from '../db/prisma.js';

const router = express.Router();

// Get all festivals
router.get('/', async (req, res) => {
  try {
    const { upcoming, trailId } = req.query;

    const where = {};

    if (upcoming === 'true') {
      where.startDate = { gte: new Date() };
    }

    if (trailId) {
      where.trailId = parseInt(trailId);
    }

    const festivals = await prisma.festival.findMany({
      where,
      include: {
        trail: {
          select: {
            id: true,
            title: true,
            district: true
          }
        }
      },
      orderBy: {
        startDate: 'asc'
      }
    });

    const formattedFestivals = festivals.map(festival => ({
      ...festival,
      images: festival.images ? JSON.parse(festival.images) : []
    }));

    res.json({ festivals: formattedFestivals });
  } catch (error) {
    console.error('Error fetching festivals:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single festival
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const festival = await prisma.festival.findUnique({
      where: { id: parseInt(id) },
      include: {
        trail: true
      }
    });

    if (!festival) {
      return res.status(404).json({ error: 'Festival not found' });
    }

    const formattedFestival = {
      ...festival,
      images: festival.images ? JSON.parse(festival.images) : []
    };

    res.json({ festival: formattedFestival });
  } catch (error) {
    console.error('Error fetching festival:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
