import express from 'express';
import prisma from '../db/prisma.js';

const router = express.Router();

// Get all stories
router.get('/', async (req, res) => {
  try {
    const { trailId, type } = req.query;

    const where = {};

    if (trailId) where.trailId = parseInt(trailId);
    if (type) where.type = type;

    const stories = await prisma.story.findMany({
      where,
      include: {
        trail: {
          select: {
            id: true,
            title: true,
            district: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    const formattedStories = stories.map(story => ({
      ...story,
      mediaUrls: story.mediaUrls ? JSON.parse(story.mediaUrls) : []
    }));

    res.json({ stories: formattedStories });
  } catch (error) {
    console.error('Error fetching stories:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single story
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const story = await prisma.story.findUnique({
      where: { id: parseInt(id) },
      include: {
        trail: true
      }
    });

    if (!story) {
      return res.status(404).json({ error: 'Story not found' });
    }

    const formattedStory = {
      ...story,
      mediaUrls: story.mediaUrls ? JSON.parse(story.mediaUrls) : []
    };

    res.json({ story: formattedStory });
  } catch (error) {
    console.error('Error fetching story:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
