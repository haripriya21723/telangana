import express from 'express';
import prisma from '../db/prisma.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get all trails with filters
router.get('/', async (req, res) => {
  try {
    const { category, district, search, popular, hiddenGem } = req.query;

    const where = {};

    if (category) where.category = category;
    if (district) where.district = district;
    if (popular === 'true') where.isPopular = true;
    if (hiddenGem === 'true') where.isHiddenGem = true;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { district: { contains: search, mode: 'insensitive' } }
      ];
    }

    const trails = await prisma.trail.findMany({
      where,
      include: {
        festivals: {
          where: {
            startDate: { gte: new Date() }
          },
          take: 3
        },
        reviews: {
          select: {
            rating: true
          }
        },
        _count: {
          select: {
            activities: true,
            reviews: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    // Calculate average rating
    const trailsWithRating = trails.map(trail => {
      const ratings = trail.reviews.map(r => r.rating);
      const avgRating = ratings.length > 0
        ? ratings.reduce((a, b) => a + b, 0) / ratings.length
        : 0;

      const { reviews, ...trailWithoutReviews } = trail;
      return {
        ...trailWithoutReviews,
        images: JSON.parse(trail.images || '[]'),
        videos: trail.videos ? JSON.parse(trail.videos) : [],
        averageRating: avgRating,
        totalReviews: trail._count.reviews,
        totalVisits: trail._count.activities
      };
    });

    res.json({ trails: trailsWithRating });
  } catch (error) {
    console.error('Error fetching trails:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single trail by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const trail = await prisma.trail.findUnique({
      where: { id: parseInt(id) },
      include: {
        festivals: true,
        stories: {
          orderBy: {
            createdAt: 'desc'
          }
        },
        reviews: {
          include: {
            user: {
              select: {
                firstName: true,
                lastName: true
              }
            }
          },
          orderBy: {
            createdAt: 'desc'
          }
        },
        _count: {
          select: {
            activities: true,
            reviews: true
          }
        }
      }
    });

    if (!trail) {
      return res.status(404).json({ error: 'Trail not found' });
    }

    // Calculate average rating
    const ratings = trail.reviews.map(r => r.rating);
    const avgRating = ratings.length > 0
      ? ratings.reduce((a, b) => a + b, 0) / ratings.length
      : 0;

    const formattedTrail = {
      ...trail,
      images: JSON.parse(trail.images || '[]'),
      videos: trail.videos ? JSON.parse(trail.videos) : [],
      festivals: trail.festivals.map(f => ({
        ...f,
        images: f.images ? JSON.parse(f.images) : []
      })),
      stories: trail.stories.map(s => ({
        ...s,
        mediaUrls: s.mediaUrls ? JSON.parse(s.mediaUrls) : []
      })),
      reviews: trail.reviews.map(r => ({
        ...r,
        photos: r.photos ? JSON.parse(r.photos) : []
      })),
      averageRating: avgRating,
      totalReviews: trail._count.reviews,
      totalVisits: trail._count.activities
    };

    res.json({ trail: formattedTrail });
  } catch (error) {
    console.error('Error fetching trail:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Track user activity (visited/bookmarked)
router.post('/:id/activity', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { action } = req.body; // 'visited' or 'bookmarked'

    if (!['visited', 'bookmarked'].includes(action)) {
      return res.status(400).json({ error: 'Invalid action' });
    }

    const activity = await prisma.userActivity.create({
      data: {
        userId: req.user.id,
        trailId: parseInt(id),
        action
      }
    });

    res.json({ message: 'Activity recorded', activity });
  } catch (error) {
    console.error('Error recording activity:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
