import express from 'express';
import prisma from '../db/prisma.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Get reviews for a trail
router.get('/trail/:trailId', async (req, res) => {
  try {
    const { trailId } = req.params;

    const reviews = await prisma.review.findMany({
      where: { trailId: parseInt(trailId) },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    const formattedReviews = reviews.map(review => ({
      ...review,
      photos: review.photos ? JSON.parse(review.photos) : []
    }));

    res.json({ reviews: formattedReviews });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create review
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { trailId, rating, comment, photos } = req.body;

    if (!trailId || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Valid trailId and rating (1-5) are required' });
    }

    // Check if trail exists
    const trail = await prisma.trail.findUnique({
      where: { id: parseInt(trailId) }
    });

    if (!trail) {
      return res.status(404).json({ error: 'Trail not found' });
    }

    const review = await prisma.review.create({
      data: {
        userId: req.user.id,
        trailId: parseInt(trailId),
        rating,
        comment: comment || null,
        photos: photos ? JSON.stringify(photos) : null
      },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true
          }
        }
      }
    });

    // Record activity
    await prisma.userActivity.create({
      data: {
        userId: req.user.id,
        trailId: parseInt(trailId),
        action: 'reviewed'
      }
    });

    const formattedReview = {
      ...review,
      photos: review.photos ? JSON.parse(review.photos) : []
    };

    res.status(201).json({ review: formattedReview });
  } catch (error) {
    console.error('Error creating review:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update review
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, comment, photos } = req.body;

    const review = await prisma.review.findUnique({
      where: { id: parseInt(id) }
    });

    if (!review) {
      return res.status(404).json({ error: 'Review not found' });
    }

    if (review.userId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const updatedReview = await prisma.review.update({
      where: { id: parseInt(id) },
      data: {
        rating: rating || review.rating,
        comment: comment !== undefined ? comment : review.comment,
        photos: photos ? JSON.stringify(photos) : review.photos
      },
      include: {
        user: {
          select: {
            firstName: true,
            lastName: true
          }
        }
      }
    });

    const formattedReview = {
      ...updatedReview,
      photos: updatedReview.photos ? JSON.parse(updatedReview.photos) : []
    };

    res.json({ review: formattedReview });
  } catch (error) {
    console.error('Error updating review:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete review
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const review = await prisma.review.findUnique({
      where: { id: parseInt(id) }
    });

    if (!review) {
      return res.status(404).json({ error: 'Review not found' });
    }

    if (review.userId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    await prisma.review.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: 'Review deleted successfully' });
  } catch (error) {
    console.error('Error deleting review:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
