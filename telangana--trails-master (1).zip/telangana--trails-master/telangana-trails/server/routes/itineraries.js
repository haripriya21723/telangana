import express from 'express';
import prisma from '../db/prisma.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Generate AI-powered itinerary
router.post('/generate', authenticateToken, async (req, res) => {
  try {
    const { duration, interests, startDate, endDate } = req.body;

    if (!duration || !interests || !Array.isArray(interests)) {
      return res.status(400).json({ error: 'Duration and interests array are required' });
    }

    // Simple AI algorithm: filter trails by interests and popularity
    const where = {
      OR: interests.map(interest => ({
        category: { contains: interest, mode: 'insensitive' }
      }))
    };

    const allTrails = await prisma.trail.findMany({
      where,
      include: {
        reviews: {
          select: {
            rating: true
          }
        },
        _count: {
          select: {
            activities: true
          }
        }
      }
    });

    // Score trails based on rating and popularity
    const scoredTrails = allTrails.map(trail => {
      const ratings = trail.reviews.map(r => r.rating);
      const avgRating = ratings.length > 0
        ? ratings.reduce((a, b) => a + b, 0) / ratings.length
        : 0;
      
      const score = (avgRating * 2) + (trail._count.activities * 0.1) + (trail.isPopular ? 1 : 0);
      return { ...trail, score };
    });

    // Sort by score and select top trails
    scoredTrails.sort((a, b) => b.score - a.score);
    const selectedTrails = scoredTrails.slice(0, duration * 2); // 2 trails per day

    // Distribute trails across days
    const itineraryTrails = [];
    selectedTrails.forEach((trail, index) => {
      itineraryTrails.push({
        trailId: trail.id,
        dayNumber: Math.floor(index / 2) + 1,
        orderInDay: (index % 2) + 1
      });
    });

    // Create itinerary
    const itinerary = await prisma.itinerary.create({
      data: {
        userId: req.user.id,
        title: `${duration}-Day Telangana Cultural Journey`,
        duration,
        interests: JSON.stringify(interests),
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        isAIGenerated: true,
        trails: {
          create: itineraryTrails
        }
      },
      include: {
        trails: {
          include: {
            trail: {
              select: {
                id: true,
                title: true,
                category: true,
                district: true,
                description: true,
                images: true
              }
            }
          }
        }
      }
    });

    // Format itinerary
    const formattedItinerary = {
      ...itinerary,
      interests: JSON.parse(itinerary.interests),
      trails: itinerary.trails.map(it => ({
        ...it.trail,
        images: JSON.parse(it.trail.images || '[]'),
        dayNumber: it.dayNumber,
        orderInDay: it.orderInDay,
        notes: it.notes
      }))
    };

    res.json({ itinerary: formattedItinerary });
  } catch (error) {
    console.error('Error generating itinerary:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get user itineraries
router.get('/my-itineraries', authenticateToken, async (req, res) => {
  try {
    const itineraries = await prisma.itinerary.findMany({
      where: { userId: req.user.id },
      include: {
        trails: {
          include: {
            trail: {
              select: {
                id: true,
                title: true,
                district: true
              }
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    const formattedItineraries = itineraries.map(itinerary => ({
      ...itinerary,
      interests: JSON.parse(itinerary.interests || '[]')
    }));

    res.json({ itineraries: formattedItineraries });
  } catch (error) {
    console.error('Error fetching itineraries:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single itinerary
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const itinerary = await prisma.itinerary.findUnique({
      where: { id: parseInt(id) },
      include: {
        trails: {
          include: {
            trail: true
          },
          orderBy: [
            { dayNumber: 'asc' },
            { orderInDay: 'asc' }
          ]
        }
      }
    });

    if (!itinerary) {
      return res.status(404).json({ error: 'Itinerary not found' });
    }

    // Check if user owns this itinerary or is admin
    if (itinerary.userId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const formattedItinerary = {
      ...itinerary,
      interests: JSON.parse(itinerary.interests || '[]'),
      trails: itinerary.trails.map(it => ({
        ...it.trail,
        images: JSON.parse(it.trail.images || '[]'),
        videos: it.trail.videos ? JSON.parse(it.trail.videos) : [],
        dayNumber: it.dayNumber,
        orderInDay: it.orderInDay,
        notes: it.notes
      }))
    };

    res.json({ itinerary: formattedItinerary });
  } catch (error) {
    console.error('Error fetching itinerary:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
